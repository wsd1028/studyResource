<template>
    <div>
        <img class="headerimg" src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1574092344265&di=49a900cb7bc07eace37f97a7a303a7d8&imgtype=0&src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01bcfd5b1be1c3a8012034f7fd5c8a.png%402o.png" alt="">
    
  <van-field class="mo"
    v-model="loginUser.username"
    required
    clearable
    label="用户名"
    right-icon="question-o"
    placeholder="请输入用户名"
    @click-right-icon="$toast('你的用户名')"
  />

  <van-field
  class="mo"
    v-model="loginUser.password"
    type="password"
    label="密码"
    placeholder="请输入密码"
    required
  />

  <van-row>
  <van-col span="20" offset="2" >
<van-button class="sub" type="info" @click="login">登录</van-button>
  </van-col>
  
</van-row>

    </div>
</template>

<script>
export default {
    data(){
        return{
            loginUser:{
                username:'',
                password:''
            }
           
        }
    },
    methods:{
      login(){
        
            this.$http.post('/center/spa/login',this.$qs.stringify(this.loginUser))
            .then(result=>{
                    if(result.code=='0'){
                    this.$store.commit('settoken',result.data)
                    window.localStorage.setItem('token',result.data)
                   // 判断路由是否带参，带参就去到重定向参数地址，否则就去首页
                    if(this.$route.query.redirect){
                         this.$router.replace({path:this.$route.query.redirect})
                    }else{
                         this.$router.replace({path:'/main/home'})
                    }
                }else{
                     alert(result.message)
                }
            }).catch(error=>{
                alert(error)
            })
             
           
      }
    }
}
</script>

<style lang="stylus" scoped>
    .headerimg
        height  150px
        width  100%
    .sub
        width 100%   
    .mo
        margin-top 20px
        margin-bottom 20px
</style>


