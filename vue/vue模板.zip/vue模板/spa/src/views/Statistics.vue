<template>
   <van-row>
  <van-col span="12">敬请期待</van-col>
</van-row>
</template>
<script>
export default {
    
}
</script>