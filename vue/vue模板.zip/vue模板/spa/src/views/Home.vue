<template>
<van-pull-refresh v-model="isLoading" @refresh="onRefresh">
    <div>
        <van-cell class="project title"    title="当前项目"   value="选择项目" size="large" @click="switchProject" is-link></van-cell>
    <van-panel  
    key="0"   :title="project.projectName" class="pan-title">
     <van-cell-group>
    <van-cell title="项目地址" icon="location-o" :value="project.address"/>
    <van-cell title="所属辖区" icon="like-o" :value="project.areaName"/>
    <van-cell title="开工时间" icon="underway-o" :value="project.startDate"/>
    <van-cell title="竣工时间" icon="underway-o" :value="project.endDate"/>
</van-cell-group>
 <div  class="cell">
  </div>
</van-panel>
<van-grid :border="true" :column-num="2" :gutter="10">
  <van-grid-item text="视频">
    <van-image :src="require('../assets/image/视频.png')" @click="$router.push({path:'/main/video'})" />
    <div class="ff">视频监控</div>
  </van-grid-item>
  <van-grid-item text="扬尘">
    <van-image :src="require('../assets/image/扬尘.png')" @click="$router.push({path:'/main/dust'})" />
    <div class="ff">扬尘管理</div>
  </van-grid-item>
</van-grid>
    </div>
</van-pull-refresh>
</template>
<script>
import MySwipe from '../components/MySwipe'
import {mapGetters} from 'vuex'
export default {
    
  data() {
    return {
      isLoading: false
    }
  },
    computed:{
    ...mapGetters({
        project:'getProject'
     })
    },

    components:{
        MySwipe,
       
    },
    mounted(){
        this.getDefaultProject()
    },
    methods:{
            onRefresh() {
      setTimeout(() => {
        this.$toast('刷新成功');
        this.isLoading = false;
        this.count++;
      }, 500);
    },
 
        switchProject(){
             this.$parent.$router.push({path:'/main/project'})
        },
       async getDefaultProject(){
         const resp=await  this.$http.post('/center/spa/data/project/default')
                if(resp.code==0){
                    this.$store.commit('setProject',resp.data)
                     window.localStorage.setItem('project',this.$qs.stringify(resp.data))
                    this.getChildTokenAndUid()   
                     }
             
            
        },
        getChildTokenAndUid(){
            this.$http.post('/center/spa/data/project/business/token',this.$qs.stringify({projectId:this.project.projectId}))
            .then(resp=>{
                if(resp.code==0){
                    this.$store.commit('setChildToken',resp.data.token)
                    this.$store.commit('setUid',resp.data.uid)
                     window.localStorage.setItem('childToken',this.$qs.stringify(resp.data.token))
                      window.localStorage.setItem('uid',this.$qs.stringify(resp.data.uid))
                }
            })
        }
    }
}
</script>

<style lang="stylus">
    .my-swipe
        height: 30%;
    .van-row
        width 99%
    .project
        background-image: linear-gradient(-90deg, #29bdd9 0%, #276ace 100%) 
        
    
    .van-cell__label
        color: #181883;
    .ff
        font-size 14px
    .title>.van-cell__title
        position relative
        left 38%
        font-weight 500
        font-size 16px
    .title>.van-cell__value
        font-weight 500
        color #0c456c   
    .title>.van-cell__right-icon
        color #0c456c   
    .van-panel__header>.van-cell__title
        font-weight 500
        text-align center
    .van-image
        width 40px   
    .cell
        background #f5f5f5
        height 10px          
</style>