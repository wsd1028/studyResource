<template>
   <div>
    <Title titleName="视频监控" ></Title> 
    <div v-for="item in chanelList" >
        <div v-if="item.channels.length>0" class="channel" >
        <VideoBase v-for="(channel,index) in item.channels" :videoSrc="channel.hlsHd" :key="index"></VideoBase>
        </div>

    </div>
    
</div>
</template>
<script>
import Title from '../components/Title'
import VideoBase from '../components/VideoBase'
import {mapGetters} from 'vuex'
export default {

    data(){
        return{
            chanelList:[]
        }
    },
     computed:{
     ...mapGetters({
        project:'getProject'
    
     }),
     ...mapGetters({
        token:'getChildToken'
     }),
     ...mapGetters({
        uid:'getUid'
     }),
      url(){
        return 'http://'+this.project.businessHost.domainName+'/'+this.project.businessHost.webContext+'/app/module/video/channel/list'
      }
    },
     components:{
        Title,
        VideoBase
    },
    mounted(){
        this.getChanelList()
    },
    methods:{

        getChanelList(){
            this.$http.post(this.url,this.$qs.stringify({
                uid:this.uid,
                projectId:this.project.projectId,
                token:this.token
            })).then(resp=>{
                if(resp.code==0){
                    this.chanelList=resp.data
                }
            })

        }
    }
}
</script>
<style lang="stylus" scoped>
    .channel
        margin-bottom 15px

   
</style>