<template>
    <div class="bk">
  <Title titleName="切换工程" ></Title>
 <Area :areaList="areaList" ></Area>
<van-dropdown-menu active-color="bule">
  <van-dropdown-item v-model="searchData.state" :options="stateList" />
  <van-dropdown-item v-model="searchData.building" :options="buildingList" />
</van-dropdown-menu>
<van-dropdown-menu active-color="bule">
  <van-dropdown-item v-model="searchData.att" :options="attList" />
  <van-dropdown-item v-model="searchData.dustNoise" :options="dustNoiseList" />
  <van-dropdown-item v-model="searchData.hoist" :options="hoistList" />
  <van-dropdown-item v-model="searchData.tower" :options="towerList" />
</van-dropdown-menu>

<van-search
  v-model="searchData.search"
  placeholder="项目名模糊查询"
  show-action
  shape="round"
  @search="onSearch"
>
  <van-button slot="action" @click="onSearch" round type="info" size="small"
  
  >搜索</van-button>
</van-search>
<div  class="cell">
  </div>
<van-list
  v-model="loading"
  :finished="finished"
  finished-text="没有更多了"
  @load="onLoad"
>
  <div v-for="(item,index) in list"  @click="selectedProject(item)">
 <van-panel  
    :key="index" :title="item.projectName" >
     <van-cell-group>
    <van-cell title="项目地址" icon="location-o" :value="item.address"/>
    <van-cell title="所属辖区" icon="like-o" :value="item.areaName"/>
    <van-cell title="开始时间" icon="underway-o" :value="item.startDate"/>
    <van-cell title="结束时间" icon="underway-o" :value="item.endDate"/>
</van-cell-group>

 
</van-panel>
    <div  class="cell">
  </div>

  </div>
</van-list>

    </div>
</template>
<script>
import Area from '../components/Area'
import Title from '../components/Title'
import { Bus } from '../bus'
export default {
    components:{
        Area,
        Title
    },
     data() {
    return {
      list: [],
      areaList:{},
      loading: false,
      finished: false,
      searchData:{
          page:0,
          size:10,
          search:'',
          areaCode:'',
          state:0,
          building:null,
          att:null,
          dustNoise:null,
          hoist:null,
          tower:null
      },
       stateList: [
                {
                    value: 0,
                    text: '项目状态'
                },
                {
                    value: 1,
                    text: '筹备'
                },
                {
                    value: 2,
                    text: '立项'
                },
                {
                    value: 3,
                    text: '在建'
                },
                {
                    value: 4,
                    text: '完工'
                },
                {
                    value: 6,
                    text: '竣工'
                }
            ],
            buildingList: [
                {
                    value: null,
                    text: '是否停工'
                },
                {
                    value: true,
                    text: '未停工'
                },
                {
                    value: false,
                    text: '停工'
                }
            ],
               attList: [
                {
                    value: null,
                    text: '考勤机'
                },
                {
                    value: true,
                    text: '已安装'
                },
                {
                    value: false,
                    text: '未安装'
                }
            ],
            dustNoiseList: [
                {
                    value: null,
                    text: '扬尘噪声'
                },
                {
                    value: true,
                    text: '已安装'
                },
                {
                    value: false,
                    text: '未安装'
                }
            ],
            hoistList: [
                {
                    value: null,
                    text: '升降机'
                },
                {
                    value: true,
                    text: '已安装'
                },
                {
                    value: false,
                    text: '未安装'
                }
            ],
            towerList: [
                {
                    value: null,
                    text: '塔机'
                },
                {
                    value: true,
                    text: '已安装'
                },
                {
                    value: false,
                    text: '未安装'
                }
            ],
    };
  },
mounted(){
        this.getArea();
        Bus.$on('sendCode',code=>this.searchData.areaCode=code)
},
  methods: {
    async  selectedProject(project){
         const resp=await  this.$http.get('/center/spa/data/project/switch',{params:{'projectId':project.id}})
               if(resp.code==0){
                this.$store.commit('setProject',project)
                this.getChildTokenAndUid(project)
                this.$router.replace({path:'/main/home'})
               }
          
         
         
      },
       getChildTokenAndUid(project){
            this.$http.post('/center/spa/data/project/business/token',this.$qs.stringify({projectId:project.projectId}))
            .then(resp=>{
                if(resp.code==0){
                    this.$store.commit('setChildToken',resp.data.token)
                    this.$store.commit('setUid',resp.data.uid)
                }
            })
        },
    onLoad() {
      // 异步更新数据
      setTimeout(() => {
      
     this.select();
       
      }, 500);
    },
    onSearch(){
        this.searchData.page=0
        this.finished = false;
        this.list=[]
        this.select()
    },

    select(){
     this.$http.post('/center/spa/data/project/list',this.$qs.stringify(this.searchData)).
         then(resp=>{

                  for (let i = 0; i < resp.data.rows.length; i++) {
                      this.list.push(resp.data.rows[i]);

                    }
                   // 加载状态结束
               this.loading = false;
            
               this.searchData.page=this.searchData.page+1;
             if(this.list.length==resp.data.total){
                 // 数据全部加载完成
               this.finished = true;
             }
               });
    },

    getArea(){
        this.$http.get('/center/spa/data/area/list').
            then(resp=>{
                this.areaList=resp.data

                 })
    },
    

  }
}
</script>

<style lang="stylus" scoped>
    .cell
        background #f5f5f5
        height 20px
   
</style>