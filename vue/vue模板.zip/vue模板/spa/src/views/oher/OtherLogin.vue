<template>
  <div>跳转中</div>
</template>
<script>
export default {
    
    mounted(){
        let token=this.$route.params.token
        this.$store.commit('settoken',token)
        window.localStorage.setItem('token',token)
        this.$router.replace({path:'/main/home'})
    }
}
</script>