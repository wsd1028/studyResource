<template>
    <div>

        <van-cell-group >
    <van-cell title="退出" @click="exit">
  <van-icon
    slot="right-icon"
    name="arrow"
    style="line-height: inherit;"
  />
</van-cell>
</van-cell-group>
   
    </div>
</template>
<script>
export default {
    methods:{
        exit(){
            this.$store.commit('settoken','')
            window.localStorage.setItem('token','') 
            this.$router.replace({path:'/login'})
        }
    }
}
</script>