<template>
<div>
    <Title titleName="扬尘统计" ></Title> 
 <iframe :src="url" width="100%" height="100%" frameborder="0" scrolling="auto"></iframe>

</div>
   
</template>
<script>
import Title from '../components/Title'
import {mapGetters} from 'vuex'
export default {
    computed:{
    ...mapGetters({
        project:'getProject'
    
     }),
     ...mapGetters({
        token:'getChildToken'
     }),
     ...mapGetters({
        uid:'getUid'
     }),
      url(){
        return 'http://'+this.project.businessHost.domainName+'/'+this.project.businessHost.webContext+'/app/device/dustNoise/index?token='+this.token+'&uid='+this.uid+'&projectId='+this.project.projectId    
      }
    },
    components:{
        Title
    },
 
}
</script>