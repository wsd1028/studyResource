<template>
    <div>
        <router-view class="Router"></router-view>
        <!-- <van-tabbar v-model="active">
  <van-tabbar-item icon="home-o" to="/main/home">主页</van-tabbar-item>
  <van-tabbar-item icon="bar-chart-o" to="/main/statistics">统计</van-tabbar-item>
  <van-tabbar-item icon="friends-o" to="/main/mine">我的</van-tabbar-item>
</van-tabbar> -->
    </div>
</template>
<script>
export default {
    data(){
        return {
            active:0
        }
    }
}
</script>
<style lang="stylus">
    .Router
        position absolute
        width  100%
        transition all 0.8s ease
        height: 100%;
        
    #app
        text-align -webkit-auto;
     

</style>