import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

let store=new Vuex.Store({
  state: {
    token:'',
    project:{},
    childToken:'',
    uid:''
  },
  mutations: {
    //设置vuex的token
    settoken(state,token){
      state.token=token
    },
    setProject(state,project){
      state.project=project
    },
    setChildToken(state,childToken){
        state.childToken=childToken
    },
    setUid(state,uid){
      state.uid=uid
    }
  },
  actions: {

  },
  //相当于我们vue 计算属性
  getters:{
    getProject(state){
        return state.project
    },
    getToken(state){
      return state.token
    },
    getChildToken(state){
      return state.childToken
    },
    getUid(state){
      return state.uid
    }
      
  }
})

export default store
