import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)
export default new Router({
  mode: 'history',
  base:process.env.NODE_ENV === "production" ? "/spa/" : "/",
  routes: [
    {
      path: '/',
      name: 'login',
      redirect: '/login'
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('./views/Login.vue')
    },
    {
      path: '/other/login/:token',
      name: 'otherLogin',
      component: () => import('./views/oher/OtherLogin.vue')
    },
    {
      path:'/main',
      name:'main',
      component: ()=> import('./views/Main.vue'),
      meta:{
        requireAuth:true,
      },
      redirect:'/main/home',
      children:[
        {
          path:'/main/home',
          name:'home',
          component: ()=> import('./views/Home.vue'),
          meta:{
            requireAuth:true,
          },
        },
        {
          path:'/main/statistics',
          name:'statistics',
          component: ()=> import('./views/Statistics.vue'),
          meta:{
            requireAuth:true,
          },
        },
        {
          path:'/main/mine',
          name:'mine',
          component: ()=> import('./views/Mine.vue'),
          meta:{
            requireAuth:true,
          },
          
        },
        {
          path:'/main/project',
          name:'project',
          component: ()=> import('./views/Project.vue'),
          meta:{
            requireAuth:true,
          },
          
        },
        {
          path:'/main/dust',
          name:'dust',
          component: ()=> import('./views/Dust.vue'),
          meta:{
            requireAuth:true,
          },
          
        },
        {
          path:'/main/video',
          name:'video',
          component: ()=> import('./views/Video.vue'),
          meta:{
            requireAuth:true,
          },
          
        },
      ]
    }
  ]
})
