<template>
    <van-nav-bar
    class="title"
  :title="titleName"
  left-text="返回"
  left-arrow
  @click-left="onClickLeft"
/>
</template>
<script>
export default {
    props:{
        titleName:{
            type:String,
            default:''
        }
    },
      methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
  
  }
}
</script>

<style lang="stylus" scoped>
    .title
       background-image: linear-gradient(-90deg, #29bdd9 0%, #276ace 100%)    
    .van-nav-bar__text
        color #ffffff
    .van-nav-bar .van-icon  
        color #ffffff   
</style>
