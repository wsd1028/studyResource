<template>
<van-swipe :autoplay="3000" indicator-color="white">
  <van-swipe-item v-for="(mage, index) in images" :key="index"><img :src="mage.img" /></van-swipe-item>
</van-swipe>
</template>
<script>
export default {
     data() {
    return {
      images: [
         { img: require("../assets/image/lunbo2.jpg")},
        { img: require("../assets/image/lunbo1.jpg")},
        { img: require("../assets/image/lunbo3.jpg")},
      ]
    }
  }
}
</script>


<style lang="stylus">
  
  img 
    width:auto;
    height:auto;
    max-width:100%;
    max-height:100%;
</style>