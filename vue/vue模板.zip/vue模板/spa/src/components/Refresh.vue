<template>
    <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
</van-pull-refresh>
</template>
<script>
export default {
     data() {
    return {
      isLoading: false
    }
  },

  methods: {
    onRefresh() {
      setTimeout(() => {
        this.$toast('刷新成功')
        this.isLoading = false
      }, 500);
    }
  }
}
</script>