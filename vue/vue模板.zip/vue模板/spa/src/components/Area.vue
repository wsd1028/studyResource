<template>
    <div class="aa">
        <van-field
  readonly
  clickable
  label="地区选择"
  :value="value"
  placeholder="选择项目所在地区"
  @click="showPicker = true"
/>

<van-popup v-model="showPicker" position="bottom">
  <van-area :area-list="areaList" :columns-placeholder="['请选择', '请选择', '请选择']" @confirm="onConfirm"/>
</van-popup>
    </div>
</template>
<script>
import { Bus } from '../bus'
export default {
    props:{
        areaList:{
            type:Object,
           default: () => ({})
        }
    },
    data() {
    return {
        showPicker:false,
        value:'',
        code:''
    }
  },
  methods: {
        onConfirm(value){
            if(value[0]&&value[0].code!=''){
             this.code=value[0].code
             this.value=value[0].name
            }
             if(value[1]&&value[1].code!=''){
                 this.code=value[1].code
                 this.value=value[1].name
            }
            if(value[2]&&value[2].code!=''){
                this.code=value[2].code
                this.value=value[2].name
            }
            Bus.$emit('sendCode', this.code)
            this.showPicker=false
        }
  }
}
</script>
<style lang="stylus" scoped>
   
   
</style>