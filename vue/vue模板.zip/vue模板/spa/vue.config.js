module.exports = {
  publicPath: process.env.NODE_ENV === "production" ? "/spa/" : "/",
  configureWebpack:{
      devServer:{
        port:8855,
        proxy: {
          //中心
          '/center': {
              target: process.env.VUE_APP_CENTER,
              ws: true,
              changeOrigin: true,
              pathRewrite: {
                '^/center': '',
              }
            
          },
          //德阳
          '/deyang': {
            target:  process.env.VUE_APP_DEYANG,
            ws: true,
            changeOrigin: true,
            pathRewrite: {
              '^/deyang': '',
            }
          
        },
        //宜宾
        '/yibing': {
          target:  process.env.VUE_APP_YIBING,
          ws: true,
          changeOrigin: true,
          pathRewrite: {
            '^/yibing': '',
          }
        
      },
      //眉山
      '/meishan': {
        target:  process.env.VUE_APP_MEISHAN,
        changeOrigin: true,
        ws: true
      
    }
      },
     
      },
      devtool: 'source-map'

  },
  css: {
    loaderOptions: {
      stylus: {
        'resolve url': true,
        'import': [
          './src/theme'
        ]
      }
    }
  },
  // pluginOptions: {
  //   'cube-ui': {
  //     postCompile: true,
  //     theme: true
  //   }
  // }
}
