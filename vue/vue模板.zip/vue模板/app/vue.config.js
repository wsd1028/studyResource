module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/carp-web/' : '/',
  configureWebpack: {
    devServer: {
      port: 8855,
      proxy: {
        //中心
        '/carp': {
          target: 'http://192.168.31.53:80',
          ws: true,
          changeOrigin: true,
          pathRewrite: {
            '^/carp': ''
          }
        }
      }
    }
  }
}
