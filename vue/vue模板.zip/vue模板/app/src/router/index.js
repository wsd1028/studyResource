import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    //登录页
    path: '/',
    name: 'login',
    redirect: '/login'
  },
  {
    //登录页
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/Login.vue')
  },
  //项目详情
  {
    path: '/projectDetail',
    name: 'projectDetail',
    component: () => import('@/views/home/ProjectDetail.vue')
  },
  //曝光台
  {
    path: '/exposure',
    name: 'exposure',
    component: () => import('@/views/home/Exposure.vue')
  },
  //曝光台详情
  {
    path: '/exposureDetail',
    name: 'exposureDetail',
    component: () => import('@/views/home/ExposureDetail.vue')
  }, //今日告警
  {
    path: '/todayWarn',
    name: 'todayWarn',
    component: () => import('@/views/home/TodayWarn.vue')
  },
  //关于我们
  {
    path: '/main/aboutUs',
    name: 'aboutUs',
    component: () => import('@/views/mine/AboutUs.vue')
  },
  //个人信息
  {
    path: '/main/mineMsg',
    name: 'mineMsg',
    component: () => import('@/views/mine/MineMsg.vue')
  },
  //修改密码
  {
    path: '/main/password',
    name: 'password',
    component: () => import('@/views/mine/Password.vue')
  },
  //用户反馈
  {
    path: '/main/feedback',
    name: 'feedback',
    component: () => import('@/views/mine/Feedback.vue')
  },
  //协议与说明
  {
    path: '/main/protocol',
    name: 'protocol',
    component: () => import('@/views/mine/Protocol.vue')
  },
  //版本更新记录
  {
    path: '/main/versionHistory',
    name: 'versionHistory',
    component: () => import('@/views/mine/VersionHistory.vue')
  },
  //设置
  {
    path: '/main/setting',
    name: 'setting',
    component: () => import('@/views/mine/Setting.vue')
  },
  {
    //底部菜单栏
    path: '/main',
    name: 'main',
    component: () => import('@/views/main/Main.vue'),
    children: [
      {
        //首页  没有对接接口
        path: '/main/home',
        name: 'home',
        component: () => import('@/views/home/Home.vue')
      },
      {
        //我的  没有对接接口
        path: '/main/mine',
        name: 'mine',
        component: () => import('@/views/mine/Mine.vue')
      },
      {
        //合作台  没有对接接口
        path: '/main/work',
        name: 'work',
        component: () => import('@/views/work/Work.vue')
      },
      {
        //发起的联单
        path: '/main/projectForm',
        name: 'projectForm',
        component: () => import('@/views/form/ProjectForm.vue')
      },
      {
        //创建联单
        path: '/main/createForm',
        name: 'createForm',
        component: () => import('@/views/form/CreateForm.vue')
      },
      {
        //车牌识别
        path: '/main/licensePlate',
        name: 'licensePlate',
        component: () => import('@/views/form/LicensePlate.vue')
      },
      {
        //联单点检
        path: '/main/formDetail',
        name: 'formDetail',
        component: () => import('@/views/form/FormDetail.vue')
      },
      {
        //联单点检(详情/消纳员) checkYes方法需要从cook拿字段
        path: '/main/formDetailGiven',
        name: 'formDetailGiven',
        component: () => import('@/views/form/FormDetailGiven.vue')
      },
      //工期管理
      {
        path: '/main/projectTimeUpdate',
        name: 'projectTimeUpdate',
        component: () => import('@/views/form/ProjectTimeUpdate.vue')
      }
    ]
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.NODE_ENV === 'production' ? '/carp-web/' : '/',
  routes
})

export default router
