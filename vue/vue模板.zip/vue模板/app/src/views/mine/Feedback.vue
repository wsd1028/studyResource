<template>
  <div class="Feedback">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="用户反馈">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="boxItem">
      <p class="text">图片</p>
      <div class="itemContent">
        <div style="display:flex;flexWrap:wrap;width:100%">
          <van-image :key="index" :src="item" height="80" style="margin:5px;flexShrink:0" v-for="(item, index) in hasUploadImg" width="80" />
          <van-uploader :accept="'image/*'" :after-read="afterRead" multiple style="margin:5px;flexShrink:0" v-model="fileList" />
        </div>
      </div>
    </div>
    <div class="boxItem">
      <p class="text">问题</p>
      <div class="itemContent">
        <van-field placeholder="请输入具体问题" type="textarea" />
      </div>
    </div>
    <div class="boxItem">
      <p class="text">联系方式</p>
      <div class="itemContent">
        <van-field label="联系电话" placeholder="请输入联系电话" type="text" />
        <van-field label="邮箱" placeholder="请输入邮箱" type="text" />
      </div>
    </div>
    <van-button block style="marginTop:30px" type="info">保存</van-button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      //图片上传列表
      fileList: [],
      //图片以及上传列表
      hasUploadImg: []
    }
  },
  mounted() {},
  components: {},
  methods: {
    //文件选中之后调用
    async afterRead(file) {
      let imgList = [file.content]
      //给上传中的文件添加上传表示
      this.fileList[0].message = '上传中...'
      this.fileList[0].status = 'uploading'
      let resp = await this.$http.post('/carp/business/a/q/upload/uploadImgs', JSON.stringify(imgList), { headers: { 'Content-Type': 'application/json' } })
      if (resp.code == 0) {
        this.$dialog.alert({
          message: '上传成功',
          confirmButtonColor: 'green'
        })
        this.hasUploadImg.push(resp.data[0])
      } else {
        this.$dialog.alert({
          message: '上传失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
      this.fileList = []
    }
  }
}
</script>

<style lang="less" scoped>
.Feedback {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  box-sizing: border-box;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    padding-left: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .boxItem {
    margin-top: 30px;
    p {
      color: #999;
      margin-bottom: 10px;
      margin-left: 16px;
    }
    .itemContent {
      background-color: #fff;
    }
  }
}
</style>
