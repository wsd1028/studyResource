<template>
  <div class="MineMsg">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="个人信息">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div style="marginTop:20px">
      <van-field disabled label="账号" value="text" />
      <van-field disabled label="组织机构" value="text" />
      <van-field disabled label="姓名" value="text" />
      <van-field disabled label="身份号" value="text" />
    </div>
    <div class="update" style="marginTop:20px">
      <p class="text">可编辑信息</p>
      <van-field label="区县" placeholder="请输入区县" value="text" />
      <van-field label="科室" placeholder="请输入科室" value="text" />
      <van-field label="职务" placeholder="请输入职务" value="text" />
    </div>
    <van-button block style="marginTop:30px" type="info">保存</van-button>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },
  mounted() {},
  components: {},
  methods: {}
}
</script>

<style lang="less" scoped>
.MineMsg {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    margin-bottom: 20px;
    padding-left: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .update {
    p {
      color: #999;
      margin-bottom: 10px;
      margin-left: 16px;
    }
  }
}
</style>
