<template>
  <div class="Password">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="修改密码">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="update" style="marginTop:20px">
      <van-field label="原密码" placeholder="请输入原密码" type="text" v-model="oldPassword" />
      <van-field label="新密码" placeholder="请输入新密码" type="password" v-model="newPassword" />
      <van-field label="确认密码" placeholder="请再次输入新密码" type="password" v-model="newPassword2" />
    </div>
    <van-button :disabled="!oldPassword || !newPassword || !newPassword2" block style="marginTop:30px" type="info">保存</van-button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      oldPassword: '',
      newPassword: '',
      newPassword2: ''
    }
  },
  mounted() {},
  components: {},
  methods: {}
}
</script>

<style lang="less" scoped>
.Password {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    margin-bottom: 20px;
    padding-left: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .update {
    p {
      color: #999;
      margin-bottom: 10px;
      margin-left: 16px;
    }
  }
}
</style>
