<template>
  <div class="Home">
    <div class="head">
      <HomeTitle titleName="扬尘治理"></HomeTitle>
      <div>
        <div class="cell-box">
          <div class="top">
            <div class="msgItem">
              <span>
                <van-icon class-prefix="iconfont" class="myIcon" color="#4284f3" name="shujia" size="20" />
              </span>
              <span @click="goSkip('projectDetail')" class="text" style="fontWeight:800;color:#333" v-text="project.name"></span>
            </div>
            <div class="msgItem">
              <van-icon class="myIcon" color="#6c6c6c" name="location" size="18" />
              <span class="text" v-text="project.address"></span>
            </div>
            <div style="display:flex;width:100%;marginTop:30px">
              <div class="chartItems" style="marginRight:10px">
                <span style="color:#fc7403">PM2.5</span>
                <div class="chartItem">
                  <div class="chart" id="chartPM2"></div>
                  <span style="color:#fc7403">81</span>
                </div>
              </div>
              <div class="chartItems" style="marginLeft:10px">
                <span style="color:#f42037">PM10</span>
                <div class="chartItem">
                  <div class="chart" id="chartPM10"></div>
                  <span style="color:#f42037">25</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style="height:90px"></div>
      <van-notice-bar :text="noticeText" color="#538dc3" speed="50">
        <template #right-icon>
          <div @click="goSkip('exposure')" class="exposureIcon">
            <span class="text">更多</span>
            <van-icon name="arrow" />
          </div>
        </template>
        <template #left-icon>
          <div>
            <span class="exposureText">曝光台</span>
          </div>
        </template>
      </van-notice-bar>
    </div>
    <div class="box">
      <div style="textAlign:left;lineHeight:40px">
        <span class="title2">今日待办</span>
        <van-divider></van-divider>
      </div>
      <div class="allIconBox">
        <div @click="goSkip('todayWarn', { active: 'dust' })" class="tac">
          <div class="iconBox" style="color:#ee4634">8</div>
          <span class="text">扬尘告警</span>
        </div>
        <div @click="goSkip('todayWarn', { active: 'directories' })" class="tac">
          <div class="iconBox" style="color:#ee4634">15</div>
          <span class="text">非名录车告警</span>
        </div>
        <div class="tac">
          <div class="iconBox" style="color:#333">335</div>
          <span class="text">每日巡检</span>
        </div>
        <div class="tac">
          <div class="iconBox">8</div>
          <span class="text">指派点检</span>
        </div>
        <div class="tac">
          <div class="iconBox">51</div>
          <span class="text">问题上报</span>
        </div>
        <div class="tac"></div>
      </div>
    </div>
    <div class="box" style="paddingTop:0">
      <van-cell is-link style="textAlign:left" to="/main/licensePlate" value="更多">
        <template #title>
          <span class="title2">车辆识别</span>
        </template>
      </van-cell>
      <van-divider></van-divider>
      <div class="activeBtn">
        <span :class="activeBtn === 3 ? 'active' : ''" @click="handelActive(3)">全部</span>
        <span :class="activeBtn === 1 ? 'active' : ''" @click="handelActive(1)">已建</span>
        <span :class="activeBtn === 2 ? 'active' : ''" @click="handelActive(2)">新建</span>
      </div>
    </div>
    <div class="box lincenseBox">
      <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
        <van-swipe-cell :key="index" v-for="(item, index) in list">
          <van-row class="item">
            <van-col span="6" style="height:85px">
              <van-image :src="item.carPhoto" fit="cover" height="100%" style="width:100%;height:100%" width="100%" />
            </van-col>
            <van-col span="1"></van-col>
            <van-col span="17">
              <div class="top">
                <p>
                  <span v-text="item.license"></span>
                  <span class="carTag0" v-if="item.carState">名录车</span>
                  <span class="carTag1" v-if="!item.carState">非名录车</span>
                </p>
                <p class="carCreat">
                  <span @click="handelCreate(item)" class="carCreat0" v-if="!item.occupancy">新建</span>
                  <span class="carCreat1" v-if="item.occupancy">已建</span>
                </p>
              </div>
              <div class="bottom">
                <p>
                  运输企业:
                  <span v-text="item.transportCompanyName"></span>
                </p>
                <p>
                  排放企业:
                  <span v-text="item.projectCompanyName"></span>
                </p>
                <p>
                  创建时间:
                  <span v-text="item.createDate"></span>
                </p>
              </div>
            </van-col>
          </van-row>
        </van-swipe-cell>
      </van-list>
    </div>
  </div>
</template>

<script>
import HomeTitle from '../../components/HomeTitle.vue'
import { Bus } from '../../bus'
export default {
  data() {
    return {
      noticeText: '昨天某某工地某某司机胡乱行驶，不遵守行驶规则，乱闯红灯，我们将对他做出500元罚款',
      project: {
        name: '',
        address: ''
      },
      activeBtn: 3,
      list: [],
      loading: false,
      finished: false,
      searchData: {
        license: '',
        limit: 10,
        page: 1,
        projectId: '',
        occupancy: ''
      }
    }
  },
  mounted() {
    this.searchData.projectId = this.$store.state.user.project.projectId
    this.getProject()
    this.drawPictorialBar({
      id: 'chartPM2',
      max: 100,
      value: 85,
      color: '#fc7403'
    })
    this.drawPictorialBar({
      id: 'chartPM10',
      max: 100,
      value: 25,
      color: '#f24037'
    })
  },
  components: {
    HomeTitle
  },
  methods: {
    //跳转路由
    goSkip(name, params) {
      this.$router.push({
        name,
        params
      })
    },
    //跳转联单点检界面
    handelCreate(item) {
      this.$router.push({
        name: 'formDetail',
        params: {
          createDate: item.createDate,
          id: item.id,
          projectId: this.searchData.projectId
        }
      })
    },
    //查询数据
    async select() {
      let resp = await this.$http.get('/carp/business/a/q/license/record/current/page', {
        params: this.searchData
      })
      if (resp.code == 0) {
        if (this.searchData.page == 1) {
          this.list = []
        }
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取车辆识别失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //点击按钮
    handelActive(val) {
      if (this.activeBtn !== val) {
        this.activeBtn = val
        if (this.activeBtn == 3) {
          this.searchData.occupancy = ''
        }
        if (this.activeBtn == 1) {
          this.searchData.occupancy = 1
        }
        if (this.activeBtn == 2) {
          this.searchData.occupancy = 0
        }
        this.searchData.page = 1
        this.select()
      }
    },
    //绘制echart bar 图
    drawPictorialBar(data) {
      let { id, max, value, color } = data
      let myChart = this.$echarts.init(document.getElementById(id))
      let option = {
        tooltip: {
          show: false
        },
        grid: {
          top: 0,
          left: 0,
          right: 0,
          bottom: 0
        },
        xAxis: {
          type: 'value',
          axisLabel: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          splitArea: {
            show: false
          }
        },
        yAxis: {
          type: 'category',
          axisLabel: {
            show: false
          },
          data: [],
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            type: 'pictorialBar',
            symbol: 'roundRect',
            symbolRepeat: 'fixed',
            symbolSize: [4, 16],
            symbolMargin: 2,
            symbolBoundingData: max,
            barWidth: '50%',
            itemStyle: {
              normal: {
                color: '#e8e8e8'
              }
            },
            label: {
              show: false
            },
            data: [max],
            animation: false,
            z: 1
          },
          {
            name: 'lalal',
            type: 'pictorialBar',
            symbol: 'roundRect',
            symbolRepeat: true,
            symbolSize: [4, 16],
            symbolMargin: 2,
            symbolBoundingData: max,
            barWidth: '50%',
            label: {
              show: false
            },
            data: [value],
            itemStyle: {
              normal: {
                color: color
              }
            },
            z: 2
          }
        ]
      }
      myChart.setOption(option, true)
    },
    getProject() {
      this.$http.get('/carp/business/k/s/project/' + this.searchData.projectId).then(resp => {
        if (resp.code == 0) {
          this.project = resp.data
        }
      })
    }
  }
}
</script>
<style lang="less" scoped>
.Home {
  padding-bottom: 50px;
  height: auto;
  background-color: #f9f9f9;
  * {
    box-sizing: border-box;
  }
  .van-divider {
    margin: 0;
  }
  p {
    margin: 0;
  }
  span {
    display: inline-block;
  }
  .head {
    height: 200px;
    margin-bottom: 100px;
  }
  .van-notice-bar {
    background-color: #fff;
  }
  .main {
    background: #f9f9f9;
  }
  .exposureIcon {
    padding-left: 10px;
  }
  .exposureText {
    font-style: italic;
    color: #3d87f0;
    font-weight: 800;
    padding-right: 10px;
  }
  .project-name {
    font-weight: 800;
  }
  .cell-box {
    padding: 20px;
    padding-bottom: 0;
    background-color: #4284f3;
    position: relative;
    height: 140px;
    .top {
      border-radius: 8px;
      background-color: #fff;
      padding: 20px;
      padding-top: 4px;
      position: absolute;
      width: 93%;
      margin: auto;
      top: 30px;
      left: 0;
      bottom: -80px;
      right: 0;
      box-shadow: 0 0 7px #e5e5e5;
      .msgItem {
        font-size: 18px;
        color: #656565;
        display: flex;
        margin-top: 16px;
        align-items: flex-start;
        text-align: left;
        .text {
          margin-left: 10px;
        }
      }

      .myIcon {
        font-weight: 800;
      }
    }
  }
  .chartItems {
    width: 50%;
    color: #5c5c5c;
    font-size: 16px;
    text-align: left;
    .chartItem {
      display: flex;
      align-items: center;
      width: 100%;
      .chart {
        flex-grow: 1;
        height: 50px;
      }
      span {
        width: 30px;
        flex-shrink: 0;
        margin-left: 5px;
      }
    }
  }
  .box {
    padding: 20px;
    margin-bottom: 20px;
    background-color: #fff;
    .van-cell {
      padding: 10px 0;
    }
    .title2 {
      font-weight: 800;
      color: #333;
      font-size: 16px;
    }
    .allIconBox {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      .tac {
        width: 33%;
        flex-shrink: 0;
        margin-top: 20px;
        .iconBox {
          font-size: 24px;
          color: #3a84f2;
        }
      }
      .text {
        color: #999;
        font-size: 16px;
        margin-top: 10px;
        display: inline-block;
        width: 100%;
      }
    }
    .dateBox {
      display: flex;
      justify-content: center;
      align-items: center;
      #chartPie,
      #chartPie1 {
        width: 80px;
        height: 80px;
        flex-shrink: 0;
        div {
          width: 100%;
        }
      }
      .item {
        flex-shrink: 0;
        .date {
          width: 100%;
          color: #999;
          font-weight: 800;
        }
        .text,
        sup {
          color: #9a9a9a;
        }
      }
    }
  }
  .activeBtn {
    text-align: left;
    margin-top: 20px;
    span {
      padding: 0 20px;
      border-radius: 14px;
      color: #999;
      line-height: 28px;
      text-align: center;
    }
    .active {
      background-color: #4186f4;
      color: #fff;
    }
  }
  .lincenseBox {
    background-color: #f9f9f9;
    padding: 0;
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 15px;
      padding-left: 20px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          span {
            padding: 0 10px;
            border-radius: 14px;
            color: #fff;
            line-height: 28px;
            text-align: center;
          }
          .carCreat0 {
            background-color: #4186f4;
          }
          .carCreat1 {
            background-color: #ccc;
          }
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
        }
      }
    }
  }
}
</style>
