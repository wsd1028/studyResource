<template>
  <div class="exposure">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="曝光台">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <article>
      <h2>某燃气有限公司未对施工区域进行有效隔离案</h2>
      <div class="date">
        <p>2020-04-25</p>
        <p>来源:宜宾新闻办公室</p>
      </div>
      <van-image :src="require('../../assets/image/car.png')" fit="cover" height="200px" style="margin:20px 0" width="100%" />
      <div class="msgItem">
        <h3>案情回顾</h3>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus eius placeat culpa labore odio impedit quasi, unde commodi. Similique magni esse,
          soluta dignissimos voluptatum sed sunt. Officia velit et sequi!
        </p>
      </div>
      <div class="msgItem">
        <h3>违反条规</h3>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus eius placeat culpa labore odio impedit quasi, unde commodi. Similique magni esse,
          soluta dignissimos voluptatum sed sunt. Officia velit et sequi!
        </p>
      </div>
      <div class="msgItem">
        <h3>处罚决定</h3>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus eius placeat culpa labore odio impedit quasi, unde commodi. Similique magni esse,
          soluta dignissimos voluptatum sed sunt. Officia velit et sequi!
        </p>
      </div>
    </article>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mainData: {}
    }
  },
  mounted() {},
  components: {},
  methods: {}
}
</script>

<style lang="less" scoped>
.exposure {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  box-sizing: border-box;
  padding-bottom: 40px;
  p,
  h2 {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    padding-left: 0;
    padding-bottom: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  article {
    background-color: #fff;
    padding: 10px;
    margin-top: 10px;
    .date {
      justify-content: space-between;
      display: flex;
      color: #989898;
      font-size: 14px;
      margin-top: 10px;
    }
    .msgItem {
      h3 {
        text-align: center;
        color: #353535;
      }
      p {
        text-indent: 20px;
        color: #676767;
      }
    }
  }
}
</style>
