<template>
  <div class="TodayWarn">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="今日告警">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <van-tabs color="#4683f1" swipeable v-model="active">
      <van-tab name="dust" title="扬尘告警">
        <div class="all">
          <div class="dustItem">
            <div class="top">
              <van-icon class-prefix="iconfont" color="#4683f1" name="yangchen" size="24" />
              <span>PM10浓度：</span>
              <span style="color:#ff0c15">95.31</span>
              <span>ug/m³</span>
            </div>
            <p style="margin:10px 0">PM10国控值:24ug/m³</p>
            <p>告警时间:2020-04-25 10:25:36</p>
          </div>
        </div>
      </van-tab>
      <van-tab name="directories" title="非名录告警">
        <div class="all">
          <van-row class="item">
            <van-col span="6" style="height:85px">
              <van-image :src="require('../../assets/image/car.png')" fit="cover" height="100%" style="width:100%;height:100%" width="100%" />
            </van-col>
            <van-col span="1"></van-col>
            <van-col span="17">
              <div class="top">
                <p>
                  <van-icon class-prefix="iconfont" color="#4683f1" name="che" size="20" />
                  <span>川A123456</span>
                  <span class="carTag1">非名录车</span>
                </p>
              </div>
              <div class="bottom">
                <p>
                  当前项目:
                  <span>宜宾扬尘项目</span>
                </p>
                <p>
                  创建时间:
                  <span>2020-2-6</span>
                </p>
              </div>
            </van-col>
          </van-row>
        </div>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
export default {
  data() {
    return {
      active: 'dust',
      mainData: {}
    }
  },
  mounted() {
    this.active = this.$route.params.active
  },
  components: {},
  methods: {}
}
</script>

<style lang="less">
.TodayWarn {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  box-sizing: border-box;
  padding-bottom: 40px;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    padding-left: 0;
    padding-bottom: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .van-tab--active {
    color: #4683f1 !important;
  }
  .all {
    padding: 20px;
    background-color: #f9f9f9;
    .dustItem {
      background-color: #fff;
      padding: 5px 10px;
      .top {
        line-height: 24px;
        i {
          display: inline-block;
          margin-right: 5px;
          vertical-align: middle;
        }
        span {
          color: #333;
          font-weight: bold;
        }
      }
      p {
        color: #9c9c9c;
      }
    }
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 5px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        i {
          display: inline-block;
          margin-right: 5px;
        }
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          span {
            padding: 0 10px;
            border-radius: 14px;
            color: #fff;
            line-height: 28px;
            text-align: center;
          }
          .carCreat0 {
            background-color: #4186f4;
          }
          .carCreat1 {
            background-color: #ccc;
          }
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
          margin-top: 10px;
        }
      }
    }
  }
}
</style>
