<template>
  <div class="exposure">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="曝光台">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <section>
      <van-row @click="handelItem" class="item">
        <van-col span="6" style="height:85px">
          <van-image :src="require('../../assets/image/car.png')" fit="cover" height="100%" style="width:100%;height:100%" width="100%" />
        </van-col>
        <van-col span="1"></van-col>
        <van-col class="itemRight" span="17">
          <p class="name">某燃气有限公司未对施工区域进行有效隔离案</p>
          <div class="date">
            <p>2020-04-25</p>
            <p>宜宾新闻办公室</p>
          </div>
        </van-col>
      </van-row>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mainData: {}
    }
  },
  mounted() {},
  components: {},
  methods: {
    //跳转到曝光台详情
    handelItem() {
      this.$router.push({
        path: '/exposureDetail'
      })
    }
  }
}
</script>

<style lang="less" scoped>
.exposure {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  box-sizing: border-box;
  padding-bottom: 40px;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    padding-left: 0;
    padding-bottom: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  section {
    .item {
      background-color: #fff;
      margin-top: 10px;
      padding: 10px;
      .itemRight {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 85px;
        .name {
          font-weight: 800;
          color: #333;
          font-size: 18px;
        }
        .date {
          justify-content: space-between;
          display: flex;
          color: #989898;
          font-size: 14px;
        }
      }
    }
  }
}
</style>
