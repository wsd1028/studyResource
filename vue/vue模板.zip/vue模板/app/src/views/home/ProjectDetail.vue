<template>
  <div class="ProjectDetail">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="项目详情">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <section>
      <div class="top">
        <van-image :src="require('../../assets/image/car.png')" height="200px" width="100%" />
        <div class="msgItem">
          <span>
            <van-icon class-prefix="iconfont" class="myIcon" color="#4284f3" name="shujia" size="20" />
          </span>
          <span class="text" style="fontWeight:800;color:#333" v-text="mainData.name"></span>
        </div>
        <div class="msgItem">
          <van-icon class="myIcon" color="#6c6c6c" name="location" size="18" />
          <span class="text" v-text="mainData.address"></span>
        </div>
      </div>
      <div class="boxItem0">
        <div>
          <p class="label">当前工期</p>
          <p class="value">暂无</p>
        </div>
        <div>
          <p class="label">工程面积</p>
          <p class="value">暂无</p>
        </div>
        <div>
          <p class="label">工程造价</p>
          <p class="value">{{ mainData.totalCost }}万元</p>
        </div>
      </div>
      <div class="boxItem">
        <p class="text">项目概况</p>
        <div class="itemContent">
          <van-field label="施工时间" type="text" v-model="mainData.startDate" />
          <van-field label="竣工时间" type="text" v-model="mainData.completeDate" />
          <van-field label="建设单位" type="text" v-model="mainData.constructUnit" />
          <van-field label="勘察单位" type="text" />
          <van-field label="设计单位" type="text" v-model="mainData.designUnit" />
          <van-field label="监理单位" type="text" />
          <van-field label="施工单位" type="text" v-model="mainData.buildUnit" />
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mainData: {}
    }
  },
  mounted() {
    this.getMainData()
  },
  components: {},
  methods: {
    //文件选中之后调用
    async getMainData() {
      //获取项目信息,type==30,60
      let resp = await this.$http.get('/carp/business/k/s/project/' + this.$store.state.user.project.projectId)
      if (resp.code == 0) {
        this.mainData = resp.data
      } else {
        this.$dialog.alert({
          message: '获取项目信息失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.ProjectDetail {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  box-sizing: border-box;
  padding-bottom: 40px;
  p {
    margin: 0;
    padding: 0;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    background-color: #fff;
    padding: 10px 20px;
    padding-left: 0;
    padding-bottom: 0;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  section {
    .top {
      padding: 20px;
      .msgItem {
        font-size: 18px;
        color: #656565;
        display: flex;
        margin-top: 16px;
        align-items: flex-start;
        text-align: left;
        .text {
          margin-left: 10px;
        }
      }
    }
    .boxItem0 {
      background-color: #fff;
      padding: 20px;
      display: flex;
      justify-content: space-between;
      .label {
        color: #999;
      }
      .value {
        color: #4087f6;
        font-weight: 800;
        font-size: 18px;
      }
    }
    .boxItem {
      margin-top: 30px;
      .itemContent {
        background-color: #fff;
      }
      p {
        color: #999;
        margin-bottom: 10px;
        margin-left: 16px;
      }
      .itemContent {
        background-color: #fff;
      }
    }
  }
}
</style>
