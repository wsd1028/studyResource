<template>
  <div class="main">
    <div class="head">
      <HomeTitle titleName="扬尘治理"></HomeTitle>
      <div>
        <div class="cell-box">
          <div class="top">
            <div class="msgItem">
              <span>
                <van-icon class-prefix="iconfont" class="myIcon" color="#4284f3" name="shujia" size="20" />
              </span>
              <span class="text" style="fontWeight:800;color:#333" v-text="project.name"></span>
            </div>
            <div class="msgItem">
              <van-icon class="myIcon" color="#6c6c6c" name="location" size="18" />
              <span class="text" v-text="project.address"></span>
            </div>
            <div style="display:flex;width:100%;marginTop:30px">
              <div class="chartItems" style="marginRight:10px">
                <span style="color:#fc7403">PM2.5</span>
                <div class="chartItem">
                  <div class="chart" id="chartPM2"></div>
                  <span style="color:#fc7403">81</span>
                </div>
              </div>
              <div class="chartItems" style="marginLeft:10px">
                <span style="color:#f42037">PM10</span>
                <div class="chartItem">
                  <div class="chart" id="chartPM10"></div>
                  <span style="color:#f42037">25</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style="height:90px"></div>
      <van-notice-bar :text="noticeText" color="#538dc3" left-icon="//img.yzcdn.cn/public_files/2017/8/10/6af5b7168eed548100d9041f07b7c616.png" speed="50" />
      <div class="bot">
        <div class="to">
          <van-row>
            <van-col class="to-left" offset="3" span="5">今日联单</van-col>
            <van-col @click="$router.push({ path: '/main/licensePlate' })" class="to-right" offset="7" span="6">
              <van-icon name="add" size="15px" />创建联单
            </van-col>
          </van-row>
        </div>
        <van-pull-refresh @refresh="onRefresh" v-model="loading">
          <van-list :finished="finished" @load="onLoad" finished-text="没有更多了" v-model="loading">
            <van-card :key="index" :thumb="require('../../assets/image/car.png')" @click="handelForm(item)" v-for="(item, index) in list">
              <div slot="title" style="height:35px;font-size:15px;font-weight:800">
                <van-row>
                  <van-col span="12" v-text="item.licenseNumber"></van-col>
                  <van-col span="6">
                    <van-tag plain round type="success">名录车</van-tag>
                  </van-col>
                  <van-col span="6">
                    <van-tag plain round type="primary">状态</van-tag>
                  </van-col>
                </van-row>
              </div>
              <div slot="tags">
                <van-row>
                  <van-col span="12">运输企业:</van-col>
                  <van-col span="12" v-text="item.companyName"></van-col>
                </van-row>
                <van-row>
                  <van-col span="12">排放企业:</van-col>
                  <van-col span="12" v-text="project.name"></van-col>
                </van-row>
                <van-row>
                  <van-col span="12">创建时间:</van-col>
                  <van-col span="12" v-text="item.createDate"></van-col>
                </van-row>
              </div>
            </van-card>
          </van-list>
        </van-pull-refresh>
      </div>
    </div>
  </div>
</template>

<script>
import HomeTitle from '../../components/HomeTitle.vue'
import { Bus } from '../../bus'
export default {
  data() {
    return {
      noticeText: '昨天某某工地某某司机胡乱行驶，不遵守行驶规则，乱闯红灯，我们将对他做出500元罚款',
      paramsData: {},
      project: {
        name: '',
        address: ''
      },
      loading: false,
      finished: false,
      list: [],
      searchData: {
        page: 1,
        limit: 10,
        plateNo: '',
        projectId: ''
      }
    }
  },
  mounted() {
    this.searchData.projectId = this.$store.state.user.project.projectId
    this.paramsData = this.$route.params
    this.getProject()
    this.drawPictorialBar({
      id: 'chartPM2',
      max: 100,
      value: 85,
      color: '#fc7403'
    })
    this.drawPictorialBar({
      id: 'chartPM10',
      max: 100,
      value: 25,
      color: '#f24037'
    })
    Bus.$on('searchValue', value => {
      this.searchData.plateNo = value
      this.list = []
      this.searchData.page = 1
      this.select()
    })
  },
  components: {
    HomeTitle
  },
  methods: {
    //绘制echart bar图
    drawPictorialBar(data) {
      let { id, max, value, color } = data
      let myChart = this.$echarts.init(document.getElementById(id))
      let option = {
        tooltip: {
          show: false
        },
        grid: {
          top: 0,
          left: 0,
          right: 0,
          bottom: 0
        },
        xAxis: {
          type: 'value',
          axisLabel: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          splitArea: {
            show: false
          }
        },
        yAxis: {
          type: 'category',
          axisLabel: {
            show: false
          },
          data: [],
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            type: 'pictorialBar',
            symbol: 'roundRect',
            symbolRepeat: 'fixed',
            symbolSize: [4, 16],
            symbolMargin: 2,
            symbolBoundingData: max,
            barWidth: '50%',
            itemStyle: {
              normal: {
                color: '#e8e8e8'
              }
            },
            label: {
              show: false
            },
            data: [max],
            animation: false,
            z: 1
          },
          {
            name: 'lalal',
            type: 'pictorialBar',
            symbol: 'roundRect',
            symbolRepeat: true,
            symbolSize: [4, 16],
            symbolMargin: 2,
            symbolBoundingData: max,
            barWidth: '50%',
            label: {
              show: false
            },
            data: [value],
            itemStyle: {
              normal: {
                color: color
              }
            },
            z: 2
          }
        ]
      }
      myChart.setOption(option, true)
    },
    //点击联单
    handelForm(item) {
      //判断是否从工作台-待办进入该界面
      if (this.paramsData.type == 'wait') {
        //判断账号权限是否为消纳员
        if (this.$store.state.user.type === 60) {
          //消纳员
          this.$router.push({
            name: 'formDetailGiven',
            params: {
              ...item
            }
          })
        }
      }
    },
    getSearchValue(value) {
      this.query = value
    },
    //得到项目详情
    getProject() {
      this.$http.get('/carp/business/k/s/project/123').then(resp => {
        if (resp.code == 0) {
          this.project = resp.data
        }
      })
    },
    //刷新界面
    onRefresh() {
      setTimeout(() => {
        this.list = []
        this.searchData.page = 1
        this.isLoading = false
        this.select()
      }, 1000)
    },
    //初始加载数列表据
    onLoad() {
      // 异步更新数据
      setTimeout(() => {
        this.select()
      }, 500)
    },
    //查询列表数据
    select() {
      this.$http
        .get('/carp/business/a/q/electronic/workflow/project', {
          params: this.searchData
        })
        .then(resp => {
          this.list = this.list.concat(resp.data.records)
          // 加载状态结束
          this.loading = false
          this.searchData.page = this.searchData.page + 1
          if (this.list.length == resp.data.total) {
            // 数据全部加载完成
            this.finished = true
          }
        })
    }
  }
}
</script>
<style lang="less" scoped>
* {
  box-sizing: border-box;
}
span {
  display: inline-block;
}
.head {
  height: 200px;
}
.gr {
  width: 89%;
  margin: auto;
  height: 237px;
  margin-top: 10px;
  border-radius: 10px;
  background: #ffffff;
}
.van-notice-bar {
  background-color: #d8e9f7b8;
}
.main {
  background: #f9f9f9;
}

.project-name {
  font-weight: 800;
}
.cell-box {
  padding: 20px;
  padding-bottom: 0;
  background-color: #4284f3;
  position: relative;
  height: 140px;
  .top {
    border-radius: 8px;
    background-color: #fff;
    padding: 20px;
    padding-top: 4px;
    position: absolute;
    width: 93%;
    margin: auto;
    top: 30px;
    left: 0;
    bottom: -80px;
    right: 0;
    box-shadow: 0 0 7px #e5e5e5;
    .msgItem {
      font-size: 18px;
      color: #656565;
      display: flex;
      margin-top: 16px;
      align-items: flex-start;
      text-align: left;
      .text {
        margin-left: 10px;
      }
    }

    .myIcon {
      font-weight: 800;
    }
  }
}
.chartItems {
  width: 50%;
  color: #5c5c5c;
  font-size: 16px;
  text-align: left;
  .chartItem {
    display: flex;
    align-items: center;
    width: 100%;
    .chart {
      flex-grow: 1;
      height: 50px;
    }
    span {
      width: 30px;
      flex-shrink: 0;
      margin-left: 5px;
    }
  }
}
.to {
  margin-top: 20px;
}
.to-left {
  color: #333333;
  font-weight: 800;
  font-size: 18px;
}
.to-right {
  color: #999999;
  font-weight: 800;
  font-size: 18px;
}
.van-card {
  background-color: #e8e6e630;
  font-size: 14px;
}
.van-card__title {
  background: #74a8d8;
}
</style>
