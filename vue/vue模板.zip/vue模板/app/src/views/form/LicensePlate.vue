<template>
  <div>
    <div class="head">
      <Title titleName="车牌识别"></Title>
      <van-icon @click="goCreatForm" class="plusIcon" name="plus" />
    </div>
    <van-pull-refresh @refresh="onRefresh" v-model="loading">
      <van-search @search="search" input-align="center" placeholder="请输入搜索关键词" v-model="searchData.license" />
      <van-list :finished="finished" @load="onLoad" finished-text="没有更多了" v-model="loading">
        <van-swipe-cell :async-close="true" :key="index" :right-width="100" v-for="(item, index) in list">
          <van-cell-group>
            <van-row class="lincense-box">
              <van-col span="17">
                <van-row>
                  <van-col class="l1" span="16" v-text="item.license">川QF12545</van-col>
                  <van-col class="l2" span="8">
                    <van-tag :type="item.occupancy ? 'danger' : 'success'" mark size="medium">{{ item.occupancy | tagFilter }}</van-tag>
                  </van-col>
                </van-row>
                <van-row>
                  <van-col class="l3" span="21" v-text="item.createDate"></van-col>
                </van-row>
                <van-row>
                  <van-col class="l4" offset="2" span="18">
                    <van-button @click="create(item)" block round size="mini" type="info" v-if="!item.occupancy">新建联单</van-button>
                    <van-button @click="create(item)" block disabled round size="mini" type="info" v-if="item.occupancy">新建联单</van-button>
                  </van-col>
                </van-row>
              </van-col>
              <van-col span="6">
                <van-image :src="require('../../assets/image/car.png')" fit="cover" height="100%" width="100%" />
              </van-col>
            </van-row>
          </van-cell-group>

          <van-button @click="onClose(index, item)" class="van-swipe-cell__right" slot="right" style="width: 90px" type="danger">删除</van-button>
        </van-swipe-cell>
      </van-list>
    </van-pull-refresh>
  </div>
</template>

<script>
import Title from '../../components/Title'
import { Dialog } from 'vant'
export default {
  components: {
    Title
  },
  data() {
    return {
      list: [],
      loading: false,
      finished: false,
      searchData: {
        license: '',
        limit: 10,
        page: 1,
        projectId: ''
      }
    }
  },
  methods: {
    //搜索
    search() {
      this.list = []
      this.searchData.page = 1
      this.select()
    },
    onLoad() {
      // 异步更新数据
      setTimeout(() => {
        this.select()
      }, 500)
    },
    //刷新界面
    onRefresh() {
      setTimeout(() => {
        this.list = []
        this.searchData.page = 1
        this.isLoading = false
        this.select()
      }, 1000)
    },
    //查询数据
    select() {
      this.$http
        .get('/carp/business/a/q/license/record/current/page', {
          params: this.searchData
        })
        .then(resp => {
          this.list = this.list.concat(resp.data.records)
          // 加载状态结束
          this.loading = false
          this.searchData.page = this.searchData.page + 1
          if (this.list.length == resp.data.total) {
            // 数据全部加载完成
            this.finished = true
          }
        })
    },
    //跳转联单点检界面
    create(item) {
      this.$router.push({
        name: 'formDetail',
        params: {
          createDate: item.createDate,
          id: item.id,
          projectId: this.searchData.projectId
        }
      })
    },
    //跳转创建联单界面
    goCreatForm() {
      this.$router.push({
        name: 'createForm',
        params: {
          license: ''
        }
      })
    },
    // 点击删除
    onClose(index, item) {
      Dialog.confirm({
        title: '提示',
        message: '确认删除此条记录？'
      })
        .then(() => {
          this.list.splice(index, 1)
          alert('删除成功')
        })
        .catch(() => {})
    }
  },
  filters: {
    // 是否可用
    tagFilter(flag) {
      if (flag) {
        return '不可用'
      } else {
        return '可用'
      }
    }
  },
  mounted() {
    this.searchData.projectId = this.$store.state.user.project.projectId
  }
}
</script>

<style lang="less" scoped>
.head {
  position: relative;
  .plusIcon {
    position: absolute;
    right: 20px;
    z-index: 999;
    top: 6px;
    font-size: 29px;
    color: #fff;
  }
}
.van-row {
  margin-top: 20px;
}
.lincense-box {
  background-color: #e8e6e630;
  height: 142px;
  .van-col {
    height: 100%;
  }
  text-align: left;
  text-indent: 10px;
  .van-tag {
    text-align: center;
    text-indent: 0px;
  }
  .l1 {
    font-weight: 800;
  }
  .l3 {
    color: #9a9898;
  }
}
</style>
