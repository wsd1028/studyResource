<template>
  <div class="ProjectTimeUpdate">
    <van-popup position="bottom" v-model="showArea">
      <van-area :area-list="areaList" @cancel="chooseAreaNo" @confirm="chooseArea" />
    </van-popup>
    <van-dialog class="myDia" show-cancel-button v-model="mapDia">
      <div class="searchMap">
        <van-field label="详细地址" placeholder="请输入详细地址" v-model="mapConfig.keyword" />
        <van-field disabled label="当前选中地址" v-model="chooseAddress" />
      </div>
      <baidu-map :center="mapConfig.center" :scroll-wheel-zoom="true" :zoom="mapConfig.zoom" class="bm-view">
        <bm-view class="map"></bm-view>
        <bm-local-search :auto-viewport="true" :keyword="mapConfig.keyword" :location="mapConfig.location" @searchcomplete="searchcomplete"></bm-local-search>
      </baidu-map>
    </van-dialog>
    <Title titleName="工期管理"></Title>
    <section>
      <div class="top">
        <p class="title" v-text="mainData.name"></p>
        <div class="box">
          <span class="label">当前施工阶段</span>
          <p class="value" v-text="mainData.phaseName"></p>
        </div>
        <div class="updateMsg">
          <span class="idot"></span>
          <span>施工阶段</span>
          <span v-text="mainData.startDate"></span>
          <span>成功变更为</span>
          <span v-text="mainData.phaseName"></span>
        </div>
        <div class="change">
          <div class="changeItem">
            <div :style="{ width: isCangeArea ? '100%' : '' }" class="left">
              <p class="label">工地位置</p>
              <p class="value" style="width:200px" v-if="!isCangeArea" v-text="mainData.address"></p>
              <van-cell-group style="marginBottom:10px" v-if="isCangeArea">
                <van-field disabled label="地区" required v-model="chooseAddress">
                  <template #button>
                    <van-button @click="showAreaDia" size="small" type="primary">选择区域</van-button>
                  </template>
                </van-field>
                <van-field label="详细地址" required v-model="chooseAddressDetail" />
              </van-cell-group>
            </div>
            <van-button @click="showMap" round style="width:90px">
              <span v-text="isCangeArea ? '确认' : '更改'"></span>
            </van-button>
          </div>
          <div class="changeItem">
            <div class="left">
              <p class="label">占地面积</p>
              <p class="value">
                <span v-if="!changeArea" v-text="mainData.projectArea"></span>
                <van-cell-group v-else>
                  <van-field placeholder="请输入占地面积" v-model="mainData.projectArea" />
                </van-cell-group>
                <span class="label">平方米</span>
              </p>
            </div>
            <van-button @click="changeArea = !changeArea" round style="width:90px;flexShrink:0">
              <span v-text="changeArea ? '确认' : '更改'"></span>
            </van-button>
          </div>
        </div>
      </div>
      <div class="middle">
        <p class="title">施工阶段变更</p>
        <div>
          <span
            :key="index"
            :style="{ background: item.choose ? '#e3eafc' : '#f4f4f4', color: item.choose ? '#1d9ef3' : '#999' }"
            @click="handelStage(item, index)"
            class="myTag"
            v-for="(item, index) in stageList"
            v-text="item.name"
          ></span>
        </div>
      </div>
      <div class="bottom">
        <van-button @click="update" block type="info">提交变更</van-button>
      </div>
    </section>
  </div>
</template>

<script>
import Title from '../../components/Title'
import areaList from '../../assets/js/areaList.js'

export default {
  data() {
    return {
      //是否修改占地面积
      changeArea: false,
      //地图弹框
      mapDia: false,
      //地址联动选择器
      showArea: false,
      // 是否处于地址修改状态
      isCangeArea: false,
      //详细地址
      chooseAddressDetail: '',
      //选中的区域
      chooseAddress: '',
      //地址对象
      areaList: {},
      dictList: [],
      //地图配置
      mapConfig: {
        zoom: 15,
        center: {},
        position: {},
        loaction: '',
        keyword: ''
      },
      stageList: [],
      mainData: {}
    }
  },
  components: {
    Title
  },
  mounted() {
    this.areaList = areaList
    this.getMainData()
  },
  methods: {
    //得到页面详细数据
    async getMainData() {
      let url = '/carp/business/a/q/duration/form/projectid/' + this.$store.state.user.project.projectId
      var resp = await this.$http.get(url)
      if (resp.code == 0) {
        this.dictList = JSON.parse(JSON.stringify(resp.data.dictList))
        for (let i = 0; i < resp.data.dictList.length; i++) {
          if (resp.data.phaseName == resp.data.dictList[i].name) {
            resp.data.dictList[i].choose = true
          } else {
            resp.data.dictList[i].choose = false
          }
        }
        this.mainData = resp.data
        this.stageList = resp.data.dictList
        this.mapConfig.keyword = resp.data.address
        this.chooseAddressDetail = resp.data.address
      } else {
        this.$dialog.alert({
          message: '获取信息失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    async update() {
      let that = this
      let phaseName = ''
      for (let i = 0; i < this.stageList.length; i++) {
        if (this.stageList[i].choose) {
          phaseName = this.stageList[i].name
        }
      }
      let updateData = {
        address: that.mainData.address,
        phaseName: phaseName,
        projectArea: that.mainData.projectArea,
        projectId: this.$store.state.user.project.projectId,
        startDate: this.$moment().format('YYYY-MM-DD hh:mm:ss')
      }
      let bool = true
      //验证必填项
      for (let key in updateData) {
        if (!updateData[key]) {
          bool = false
        }
      }
      //必填项是否验证成功
      if (bool) {
        let url = '/carp/business/a/q/duration/form/increase'
        let resp = await this.$http.post(url, updateData)
        if (resp.code == 0) {
          this.$dialog.alert({
            message: '创建成功',
            confirmButtonColor: 'green'
          })
          this.$router.push({
            name: 'work',
            params: {}
          })
        } else {
          this.$dialog.alert({
            message: '创建失敗:' + resp.message,
            confirmButtonColor: 'red'
          })
        }
      } else {
        this.$dialog.alert({
          message: '信息不完整',
          confirmButtonColor: 'red'
        })
      }
    },
    showAreaDia() {
      this.showArea = !this.showArea
    },
    //地址选择点击确认
    chooseArea(area) {
      let bool = true
      this.isCangeArea = true
      if (!area[0]) {
        this.$toast('请选择省')
        bool = false
      }
      if (!area[1]) {
        this.$toast('请选择市')
        bool = false
      }
      if (!area[2]) {
        this.$toast('请选择区')
        bool = false
      }
      if (bool) {
        let chooseAddress = ''
        for (let i = 0; i < area.length; i++) {
          chooseAddress += area[i].name
        }
        this.chooseAddress = chooseAddress
        this.showArea = false
      }
    },
    //地址选择点击取消
    chooseAreaNo() {
      this.showArea = false
      this.chooseAddress = ''
    },
    //显示地图弹窗
    showMap() {
      // this.mapDia = true
      if (this.isCangeArea) {
        if (!this.chooseAddressDetail) {
          this.$toast('请输入详细地址')
          return
        }
        this.mainData.address = this.chooseAddress + this.chooseAddressDetail
      }
      this.isCangeArea = !this.isCangeArea
    },
    //点击地图
    getPoint(e) {
      let geocoder = new BMap.Geocoder() //创建地址解析器的实例
      geocoder.getLocation(e.point, rs => {
        //地址描述
      })
    },
    searchcomplete(e) {},
    //地图初始化时,定位当前位置
    onBaiduMapReady(e) {
      const that = this
      this.BMap = e.BMap
      if (this.BMap) {
        const geolocation = new this.BMap.Geolocation()
        geolocation.getCurrentPosition(res => {
          const { lng, lat } = res.point
          const { province, city, district, street, street_number } = res.address
        })
      }
    },
    //点击施工阶段
    handelStage(item, index) {
      //将选中状态取反
      this.stageList[index].choose = !this.stageList[index].choose
      //将其他施工阶段选中状态设为否
      for (let i = 0; i < this.stageList.length; i++) {
        if (this.stageList[i].id != item.id) this.stageList[i].choose = false
      }
    }
  }
}
</script>

<style lang="less">
.ProjectTimeUpdate {
  text-align: left;
  height: auto !important;
  * {
    box-sizing: border-box;
  }
  p {
    margin: 0;
  }
  span {
    display: inline-block;
  }
  .myDia {
    padding: 0 4px;
    .bm-view > div {
      overflow: auto;
      height: 200px;
    }
    .bm-view {
      width: 100%;
      .searchMap {
        margin-top: 4px;
        .van-cell {
          padding: 2px 0;
        }
      }
    }
  }

  section {
    padding: 0 20px;
    .title {
      font-weight: 800;
      color: #000;
      text-align: left;
      margin: 10px 0;
    }
    .top {
      .box {
        background-color: #1d9ef3;
        padding: 20px;
        padding-bottom: 40px;
        border-top-left-radius: 6px;
        border-top-right-radius: 6px;
        .label {
          color: #e5e5e5;
        }
        .value {
          color: #fff;
          text-align: center;
          font-size: 20px;
          font-weight: 700;
          margin-top: 10px;
        }
      }
      .updateMsg {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        margin-top: 10px;
        .idot {
          width: 4px;
          height: 4px;
          background-color: #349cfa;
          display: block;
          margin-right: 4px;
        }
        span {
          flex-shrink: 0;
          font-size: 10px;
        }
      }
      .change {
        .changeItem {
          margin-top: 20px;
          margin-left: 5px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          .left {
            flex-grow: 1;
            overflow: hidden;
            .label {
              font-weight: 800;
              color: #000;
            }
            .value {
              color: #999;
              width: 100%;
              margin-left: 8px;
              margin-top: 8px;
              text-overflow: ellipsis;
              white-space: nowrap;
              overflow: hidden;
            }
          }
        }
      }
    }
    .middle {
      margin-top: 20px;
      .myTag {
        text-align: center;
        line-height: 40px;
        font-size: 18px;
        margin: 4px 5px;
        border-radius: 4px;
        display: inline-block;
        color: #fff;
        width: 30%;
      }
    }
    .bottom {
      margin-top: 20px;
    }
  }
}
</style>
