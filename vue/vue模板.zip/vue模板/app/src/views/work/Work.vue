<template>
  <div class="Work">
    <header>
      <p class="title">工作台</p>
      <span>
        <van-icon class-prefix="iconfont" name="ccgl-yundanpicisaomiao-5" size="20px" style="position:relative;marginRight:20px" />
        <van-icon class-prefix="iconfont" info="99+" name="note" size="20px" style="position:relative" />
      </span>
    </header>
    <div class="box">
      <div style="padding:0 50px">
        <van-divider>
          <span class="title2">宜宾市扬尘治理平台</span>
        </van-divider>
      </div>
      <div class="allIconBox">
        <div @click="goSkip('projectForm', { type: 'wait' })" class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="blue" name="daiban" />
          </div>
          <span class="text">待办</span>
        </div>
        <div @click="goSkip('projectForm', { type: 'start' })" class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="orange" name="faqi" />
          </div>
          <span class="text">发起</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="green" name="chuli" />
          </div>
          <span class="text">已处理</span>
        </div>
      </div>
    </div>
    <div class="box">
      <div style="padding:0 50px">
        <van-divider>
          <span class="title2">智慧工地管理</span>
        </van-divider>
      </div>
      <div class="allIconBox">
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="yellow" name="yangchen" />
          </div>
          <span class="text">扬尘噪音</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="red" name="yichang" />
          </div>
          <span class="text">异常周报</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="violet" name="shipin" />
          </div>
          <span class="text">视频监控</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="skyblue" name="guanjianrenyuandaogang" />
          </div>
          <span class="text">关键人员</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="orange" name="maozi" />
          </div>
          <span class="text">实名制管理</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="green" name="zhianbu" />
          </div>
          <span class="text">质安检查</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="violet" name="taji" />
          </div>
          <span class="text">塔机监控</span>
        </div>
        <div class="tac">
          <div class="iconBox">
            <van-icon class-prefix="iconfont" class="yellow2" name="shengjiangji" />
          </div>
          <span class="text">升降机监控</span>
        </div>
        <div class="tac">
          <div @click="goSkip('projectTimeUpdate', {})" class="iconBox" v-if="$store.state.user.type === 3">
            <div class="iconBox">
              <van-icon class-prefix="iconfont" class="blue" name="xiangmugongqi" />
            </div>
            <span class="text">工期管理</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },
  mounted() {},
  components: {},
  methods: {
    //跳转页面
    goSkip(name, parmas) {
      this.$router.push({
        name: name,
        params: parmas
      })
    }
  }
}
</script>

<style lang="less" scoped>
* {
  box-sizing: border-box;
}
.Work {
  background-color: #f9f9f9;
  height: auto;
  padding-bottom: 50px;
}

span {
  display: inline-block;
}
header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  margin-bottom: 20px;
  background-color: #fff;
}
p {
  margin: 0;
  padding: 0;
}
.title {
  font-weight: 800;
  color: #333;
  font-size: 20px;
}
.title2 {
  font-weight: 800;
  color: #333;
  font-size: 16px;
}
.van-divider {
  border-color: #e1e9ee;
}
.van-divider::after,
.van-divider::before {
  border-width: 4px 0 0;
  width: 50px;
}
.box {
  padding: 20px;
  margin-bottom: 20px;
  background-color: #fff;

  .allIconBox {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    .tac {
      width: 33%;
      flex-shrink: 0;
      margin-top: 30px;
    }
    .iconBox {
      i {
        color: #fff;
        font-weight: 800;
        font-size: 24px;
        width: 50px;
        height: 50px;
        border-radius: 100%;
        line-height: 50px;
        text-align: center;
        display: inline-block;
      }
    }
    .text {
      color: #343434;
      font-size: 18px;
      margin-top: 20px;
      display: inline-block;
      width: 100%;
    }
  }
}

.blue {
  background-color: #349cfa;
}
.orange {
  background-color: #ff7201;
}
.green {
  background-color: #19c363;
}
.yellow {
  background-color: #fc9900;
}
.yellow2 {
  background-color: #ff9700;
}
.red {
  background-color: #fe0100;
}
.violet {
  background-color: #b801fc;
}
.skyblue {
  background-color: #329df4;
}
</style>
