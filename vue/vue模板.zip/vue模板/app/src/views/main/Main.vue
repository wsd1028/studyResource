<template>
  <div>
    <router-view class="Router"></router-view>
    <van-tabbar v-model="active">
      <van-tabbar-item icon="wap-home" to="/main/home">首页</van-tabbar-item>
      <van-tabbar-item icon="cluster " to="/main/work">工作台</van-tabbar-item>
      <van-tabbar-item icon="map-marked" to="/main/mine">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>
<script>
export default {
  data() {
    return {
      active: 0
    }
  }
}
</script>
<style lang="less" scoped>
.Router {
  position: absolute;
  width: 100%;
  transition: all 0.8s ease;
  // height: 100%;
  padding-bottom: 50px;
}

#app {
  text-align: -webkit-auto;
}
</style>
