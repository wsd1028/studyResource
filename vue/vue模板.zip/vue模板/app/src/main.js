import Vue from 'vue'
import App from './App.vue'
import store from './store'
import router from './router'
import Vant from 'vant'
import 'vant/lib/index.css'
import axios from '@/axios'
import qs from 'qs'
import moment from 'moment'
import echarts from 'echarts'
import { Dialog } from 'vant'
import BaiduMap from 'vue-baidu-map'
import './assets/iconfont/iconfont.css'

Vue.use(BaiduMap, {
  ak: 'Y7mhfb6uz11mbrtjhC7kePvWKNmk9BaY'
})
Vue.use(Vant)
Vue.prototype.$dialog = Dialog
Vue.prototype.$http = axios
Vue.prototype.$moment = moment
Vue.prototype.$echarts = echarts
Vue.config.productionTip = false

Vue.prototype.$qs = qs

require('./mock/mock.js')

router.beforeEach((to, from, next) => {
  let token = ''
  store.commit('fulshHomeUrl')
  // // 防止刷新后vuex里丢失token
  token = store.state.user.token
  // // 防止刷新后vuex里丢失user
  if (JSON.stringify(store.state.user.user) == '{}') {
    store.commit('getUser')
  }
  if (!token) {
    store.commit('getToken')
    token = store.state.user.token
  }
  // // 过滤登录页，防止死循环
  if (!token && to.name !== 'login') {
    next({ name: 'login' })
  } else {
    next()
  }
  // next()
})
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
