<!--
  普通增删改查组件
  @prop formConfig: 表单配置文件
  @prop addUrl: 添加请求地址
  @prop delUrl: 删除请求地址
  @prop editUrl: 编辑请求地址
  @prop searchUrl: 搜索请求地址
-->
<template>
  <div class="manage">
    <!-- 表单弹窗 -->
    <el-dialog class="dialog" :visible.sync="form.show" top="4vh" :lock-scroll="true" :title="form.type === 'add' ? '添加条目' : '更新条目'">
      <!-- 表单 -->
      <el-form class="form" :model="form.data" status-icon :rules="form.rules" ref="ruleForm" label-width="160px">
        <el-form-item v-for="(item, key) in form.label" :key="key" :label="item.label" :prop="key" v-show="item.show === undefined ? true : item.show">
          <!-- 数字类型 -->
          <el-input
            v-if="item.type === 'number'"
            v-model.number="form.data[key]"
            :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
          ></el-input>
          <!-- 下拉框类型 -->
          <el-select
            v-else-if="item.type === 'select'"
            v-model="form.data[key]"
            :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
          >
            <el-option v-for="item in item.item" :key="item.code" :label="item.label" :value="item.code"></el-option>
          </el-select>
          <!-- 单选框 -->
          <el-radio-group
            v-else-if="item.type === 'radio'"
            v-model="form.data[key]"
            :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
          >
            <el-radio v-for="(item, key) in item.item" :key="key" :label="item.code">{{ item.label }}</el-radio>
          </el-radio-group>
          <!-- 日期类型 -->
          <el-date-picker
            v-else-if="item.type == 'date'"
            v-model="form.data[key]"
            type="datetime"
            format="yyyy-MM-dd HH:mm:ss"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="请输入日期"
            :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
          ></el-date-picker>
          <!-- 下拉搜索框 -->
          <el-select
            v-else-if="item.type == 'search'"
            v-model="form.data[key]"
            filterable
            remote
            :placeholder="item.placeholder"
            :remote-method="item.search"
            :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
          >
            <el-option v-for="_item in item.item" :key="_item.code" :label="_item.label" :value="_item.code"></el-option>
          </el-select>
          <!-- 图片上传 -->
          <el-upload
            v-else-if="item.type == 'uploadImg'"
            :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
            class="avatar-uploader"
            :action="item.url"
            :show-file-list="false"
            :on-success="item.success"
            :before-upload="item.before"
          >
            <img v-if="form.data[key]" :src="form.data[key]" class="avatar" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
          <!-- 选择地址 -->
          <div class="map" v-else-if="item.type == 'map'">
            <el-input
              v-model="form.data[key]"
              :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"
              placeholder="请输入地址来直接查找相关位置"
            ></el-input>
            <!-- 给地图加点击事件getLocation，点击地图获取位置相关的信息，经纬度啥的 -->
            <!-- scroll-wheel-zoom：是否可以用鼠标滚轮控制地图缩放，zoom是视图比例 -->
            <baidu-map
              class="map-baidu"
              :scroll-wheel-zoom="true"
              :center="item.location"
              @click="getLocation($event, item.getLocation)"
              v-if="form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset)"
            >
              <bm-view class="map-baidu-view"></bm-view>
              <bm-local-search :keyword="form.data[key]" :auto-viewport="true" style="display: none"></bm-local-search>
            </baidu-map>
          </div>
          <!-- 文本输入框 -->
          <el-input v-else v-model="form.data[key]" :disabled="!(form.type == 'add' || (item.allowReset === undefined ? true : item.allowReset))"></el-input>
        </el-form-item>
      </el-form>
      <!-- 提交按钮 -->
      <div slot="footer" class="dialog-footer">
        <el-button @click="form.show = false">取 消</el-button>
        <el-button
          @click="
            form.show = false
            submit()
          "
          type="primary"
          >提 交</el-button
        >
      </div>
    </el-dialog>
    <!-- 表单end -->
    <!-- 控制器 -->
    <div class="control">
      <div class="add">
        <el-button
          type="primary"
          @click="
            form.type = 'add'
            formInit()
            form.show = true
          "
          >+新增</el-button
        >
      </div>
      <div class="search">
        <el-input v-model="select.keyword" placeholder="请输入关键字"></el-input>
        <el-button type="primary" @click="getList(1)">搜索</el-button>
      </div>
    </div>
    <!-- 控制器end -->
    <!-- 表格 -->
    <common-table
      v-loading="loading"
      :tableData="tableData"
      :tableLabel="tableLabel"
      :config="tableConfig"
      :allowEdit="allowEdit"
      @edit="showEditForm"
      @del="del"
      @changePage="getList"
    ></common-table>
    <!-- 表格end -->
  </div>
</template>
<script>
import commonTable from './CommonTable'
export default {
  data() {
    return {
      // 加载
      loading: false,
      // 表格配置
      tableConfig: { page: 1, limit: 10, total: 1 },
      // 表格内容
      tableData: [],
      // 表格列信息
      tableLabel: [],
      // 搜索参数
      select: {
        keyword: '' //关键字
      },
      // 表单信息
      form: Object.assign(this.formConfig, {
        rules: {}
      })
    }
  },
  props: {
    formConfig: Object,
    allowEdit: {
      type: Boolean,
      default: true
    },
    addUrl: {
      type: String,
      default: null
    },
    delUrl: {
      type: String,
      default: null
    },
    editUrl: {
      type: String,
      default: null
    },
    searchUrl: String
  },
  methods: {
    /* *
     * 添加条目
     * * */
    add() {
      // 发送请求
      this.$http.post(this.addUrl, this.form.data).then(({ code, message, data }) => {
        console.log('添加请求\n请求参数:', this.form.data, '\n响应参数:', {
          code,
          message,
          data
        })
        if (code === 0) {
          this.tableData.push(this.form.data)
        }
        this.$message(message)
      })
    },

    /* *
     * 删除表格内容
     * * */
    del({ id }) {
      this.$confirm('此操作将删除该条数据, 是否继续?', '警告', {
        confirmButtonText: '删除',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.$http.delete(`${this.delUrl}/${id}`).then(({ code, message }) => {
            if (code === 0) this.getList()
            this.$message(message)
            console.log('删除请求\n请求参数: ', { id }, '\n响应结果: ', {
              code,
              message
            })
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },

    /* *
     * 修改表格内容
     * * */
    // 显示修改表单
    showEditForm(row) {
      this.formInit()
      this.form.show = true
      this.form.type = 'edit'
      Object.keys(this.form.data).forEach(key => {
        this.form.data[key] = row[key]
      })
      // 保存原有数据
      this.form.originData = {}
      this.form.originData = row
    },
    // 修改提交
    edit() {
      // 请求参数
      const params = Object.assign(this.form.originData, this.form.data)
      this.$http.put(this.editUrl, params).then(({ code, message }) => {
        if (code === 0) this.getList()
        this.$message(message)
        console.log('修改请求\n请求参数: ', params, '\n响应结果: ', {
          code,
          message
        })
      })
    },

    /* *
     * 表单提交
     * * */
    submit() {
      // 验证输入内容是否全都正确
      this.$refs['ruleForm'].validate(valid => {
        // 内容正确,提交
        if (valid) {
          if (this.form.type === 'add') this.add()
          else if (this.form.type === 'edit') this.edit()
        }
        // 内容格式错误
        else {
          console.log('提交驳回,内容格式不正确')
          return false
        }
      })
    },

    /* *
     * 请求表格内容
     * @param page: 页数
     * @param limit: 内容长度
     * * */
    getList(page = this.tableConfig.page) {
      // 打开加载动画
      this.loading = true
      this.$http
        .get(this.searchUrl, {
          params: {
            limit: this.tableConfig.limit,
            page: page,
            name: this.select.keyword,
            projectId: this.select.keyword,
            companyId: this.select.keyword
          }
        })
        .then(({ code, data }) => {
          if (code !== 0) {
            console.log('表格内容请求失败')
            return
          }
          // 刷新表格数据
          this.tableData = data.records || data
          // 获取表格当前索引号
          this.tableConfig.page = data.current
          // 获取表格页数
          this.tableConfig.total = data.total

          // 关闭加载动画
          this.loading = false
        })
    },

    /* *
     * 初始化表单
     * * */
    formInit() {
      Object.keys(this.form.label).forEach(key => {
        if (this.form.label[key].default) {
          this.form.data[key] = this.form.label[key].default
        } else {
          this.form.label[key].default
        }
      })
    },

    /* *
     * 初始化表格信息
     * * */
    tableInit() {
      this.tableLabel = Object.keys(this.form.label).map(key => ({
        prop: key,
        label: this.form.label[key].label,
        width: this.form.label[key].width || 100,
        type: this.form.label[key].colType ? this.form.label[key].colType : '',
        show: this.form.label[key].colShow ? this.form.label[key].colType : true
      }))
    },

    /* *
     * 设置表单验证规则
     * * */
    setRules() {
      /* *
       * 表单验证方法
       * * */
      var validator = ({ field }, value, callback) => {
        // 获取当前项的规则对象
        let rule = this.form.label[field].rule
        // 若未配置规则,则直接通过验证
        value += ''
        if (!rule || value.search(rule.regExp) !== -1) {
          callback()
        } else {
          callback(new Error(rule.message))
        }
      }

      /* *
       * 装载验证
       * * */
      Object.keys(this.form.label).forEach(key => {
        this.form.rules[key] = [{ validator, trigger: 'blur' }]
      })
    },

    /**
     * 获取地图信息
     **/
    getLocation({ point }, callback) {
      /* 创建地址解析器的实例 */
      const geoCoder = new BMap.Geocoder()
      /* 利用坐标获取地址的详细信息 */
      geoCoder.getLocation(point, res => {
        callback.call(this, res)
      })
    }
  },
  created() {
    // 表单初始化
    this.formInit()
    // 设置表单验证规则
    this.setRules()
    // 初始化表格列信息
    this.tableInit()
    // 请求表格内容
    this.getList(1)
  },
  components: {
    commonTable
  }
}
</script>
<style lang="less" scoped>
@import '~@/assets/less/common';

.manage {
  @flex-column();

  // 控制头
  .control {
    display: flex;
    justify-content: space-between;

    .search {
      display: flex;

      & > * {
        margin-left: 10px;
      }
    }
  }

  /* *
  * 表单
  * */
  .dialog {
    .map-baidu {
      height: 300px;

      .map-baidu-view {
        margin-top: 10px;
        width: 100%;
        height: 100%;
        flex: 1;
      }
    }
  }

  // 分页器
  .pagination {
    display: flex;
    justify-content: center;
  }

  // 上传图片
  .avatar-uploader {
    .avatar-uploader-icon {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;

      &:hover {
        color: #409eff;
        border-color: #409eff;
      }
    }

    .avatar {
      width: 178px;
      height: 178px;
      display: block;
    }
  }
}
</style>
<style lang="less">
@import '~@/assets/less/common';
</style>
