<template>
  <div class="header-bg">
    <i class="el-icon-s-fold" @click="collapseMenu"></i>
    <h3>智慧工地扬尘监测系统</h3>
    <div class="r-content">
      <el-dropdown trigger="click" size="mini">
        <span class="el-dropdown-link"><img :src="userImg" class="user"/></span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>个人中心</el-dropdown-item>
          <el-dropdown-item @click.native="logOut">退出</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <div style="clear: both;"></div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState({
      current: state => state.tab.currentMenu
    })
  },
  data() {
    return {
      userImg: require('../assets/images/user.png'),
      open: true
    }
  },
  methods: {
    collapseMenu() {
      this.$store.commit('collapseMenu')
    },
    logOut() {
      this.$store.commit('clearToken')
      this.$store.commit('clearMenu')
      location.reload()
    }
  }
}
</script>

<style lang="less">
.el-header {
  padding: 0px !important;
}
.header-bg {
  background-color: #4e97d9;
  padding: 5px !important;
  color: #ffffff;
  font-weight: bolder;
  font-size: 20px;
  i {
    float: left;
    padding: 19px;

    cursor: pointer;
    font-size: 26px;
  }
  h3 {
    padding-left: 20px;
    line-height: 20px;
    float: left;
    width: calc(100% -98px);
  }
}

.r-content {
  display: flex;
  width: 40px;
  height: 40px;
  float: right;
  margin: 10px 10px 0px 0px;
  .user {
    width: 40px;
    height: 40px;
    border-radius: 50%;
  }
}
</style>
