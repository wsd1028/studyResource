<template>
  <el-form :inline="inline" :model="form" ref="commonForm" :rules="rules" label-width="100px">
    <el-form-item v-for="item in formLabel" :key="item.model" :label="item.label" :prop="item.model">
      <!-- 常规文本框 -->
      <el-input v-model="form[item.model]" :placeholder="'请输入' + item.label" v-if="!item.type"></el-input>
      <!-- 密码框 -->
      <el-input v-model="form[item.model]" :placeholder="'请输入' + item.label" v-if="item.type === 'password'" show-password></el-input>
      <!-- 下拉选择框 -->
      <el-select v-model="form[item.model]" placeholder="请选择" v-if="item.type === 'select'">
        <el-option v-for="item in item.opts" :key="item.value" :label="item.label" :value="item.value"></el-option>
      </el-select>
      <!-- switch开关 -->
      <el-switch v-model="form[item.model]" v-if="item.type === 'switch'"></el-switch>
      <!-- 日历选择器 -->
      <el-date-picker
        v-model="form[item.model]"
        type="date"
        placeholder="选择日期"
        v-if="item.type === 'date'"
        format="yyyy 年 MM 月 dd 日"
        value-format="yyyy-MM-dd"
      >
      </el-date-picker>
      <!-- 单选框 -->
      <el-radio-group v-model="form[item.model]" v-if="item.type === 'radio'">
        <el-radio v-for="item in item.opts" :key="item.value" :label="item.label" :value="item.value"></el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item>
      <slot></slot>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  props: {
    inline: Boolean,
    form: Object,
    formLabel: Array,
    rules: Object
  }
}
</script>

<style lang="less" scoped></style>
