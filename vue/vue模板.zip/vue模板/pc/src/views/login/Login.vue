<template>
  <div style="padding: 20px" class="login">
    <el-form :model="form" label-width="120">
      <el-form-item label="用户名">
        <el-input v-model="form.username"></el-input>
      </el-form-item>
      <el-form-item label="密码">
        <el-input v-model="form.password" type="password"></el-input>
      </el-form-item>
      <el-form-item align="center">
        <el-button type="primary" @click.enter="login" @keyup.enter.native="login" class="btnlogin">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      form: {
        username: '',
        password: ''
      }
    }
  },
  //创建成功后来定义江畔事件//
  created() {
    document.onkeydown = e => {
      if (window.event === undefined) {
        var key = e.keyCode
      } else {
        // eslint-disable-next-line no-redeclare
        var key = window.event.keyCode
      }
      if (key === 13) {
        this.login()
      }
    }
  },
  //离开页面后，阻止回车事件
  destroyed() {
    document.onkeydown = undefined
  },
  methods: {
    login() {
      this.$http.post('api/permission/getMenu', this.form).then(res => {
        if (res.code === 0) {
          this.$store.commit('clearMenu')
          this.$store.commit('setMenu', res.data.menu)
          this.$store.commit('setToken', res.data.token)
          this.$store.commit('addMenu', this.$router)
          this.$router.push({ name: 'home' })
        } else {
          this.$message.warning(res.data.message)
        }
      })
    }
  }
}
</script>
<style lang="less" scoped>
.el-form {
  width: 50%;
  margin: auto;
  padding: 120px;
  height: 450px;
  background-color: #fff;
}

.login {
  background: url('../../assets/images/background.png');
  height: 97%;
}

.el-form {
  background: none;
  width: 33%;
  border: 2px solid #83beda52;
  border-radius: 10px;
}

.el-form-item {
  margin-bottom: 90px;
}

.btnlogin {
  width: 80%;
  height: 50px;
}
</style>
