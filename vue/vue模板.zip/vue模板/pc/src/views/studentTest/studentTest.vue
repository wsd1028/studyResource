<template>
  <el-main>
    <el-dialog :title="operateType === 'add' ? '新增用户' : '更新用户'" :visible.sync="isShow">
      <common-form :formLabel="operateFormLabel" ref="cf" :form="operateForm" :rules="rules"></common-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="isShow = false">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </div>
    </el-dialog>
    <el-row :gutter="20" style="margin-bottom: 15px;">
      <el-col :span="6"> <el-button type="primary" @click="addUser">+ 新增</el-button></el-col>
      <el-col :span="6" :offset="10"><el-input v-model="searchFrom.keyword" placeholder="根据名字模糊搜索"></el-input></el-col>
      <el-col :span="1"> <el-button type="primary" @click="getList(1)">搜索</el-button></el-col>
    </el-row>

    <common-table :tableData="tableData" :tableLabel="tableLabel" :config="config" @changePage="getList" @edit="editUser" @del="delUser"></common-table>
  </el-main>
</template>

<script>
import CommonForm from '../../components/CommonForm'
import CommonTable from '../../components/CommonTable'
export default {
  components: {
    CommonForm,
    CommonTable
  },
  data() {
    return {
      //弹出框状态 add为增加 edit为修改
      operateType: 'add',
      //弹出框是否显示
      isShow: false,
      //table数据
      tableData: [],
      //表头
      tableLabel: [
        {
          prop: 'id',
          label: 'id',
          width: 300
        },
        {
          prop: 'name',
          label: '姓名',
          width: 300
        },
        {
          prop: 'age',
          label: '年龄',
          width: 300
        }
      ],
      //表单验证
      rules: {
        name: [
          { required: true, message: '请输入名字', trigger: 'blur' },
          { min: 2, max: 5, message: '长度在 2 到 5 个字符', trigger: 'blur' }
        ],
        age: [
          {
            required: true,
            message: '请输入年龄',
            trigger: 'blur'
          },
          {
            validator(rule, value, callback) {
              if (/^([0-9]|[0-9]{2}|100)$/.test(value) == false) {
                callback(new Error('请输入正确的年龄'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ]
      },
      //分页数据
      config: {
        page: 1,
        pageIndex: 10,
        total: 30,
        loading: false
      },
      //修改或者增加的对象 如果是修改 需要把修改的当前行赋值给他
      operateForm: {
        id: '',
        name: '',
        age: ''
      },
      //弹出框的提示数据
      operateFormLabel: [
        {
          model: 'name',
          label: '姓名'
        },
        {
          model: 'age',
          label: '年龄'
        },
        {
          model: 'sex',
          label: '性别'
        }
      ],
      //查询条件
      searchFrom: {
        keyword: ''
      }
    }
  },
  methods: {
    getList(pageIndex) {
      //当前页
      console.log(pageIndex)
      this.config.loading = true
      let obj = Object.assign(this.config, this.searchFrom)
      this.$http
        .get('/carp/permission/student/list', {
          params: obj
        })
        .then(res => {
          console.log(res.data)
          this.tableData = res.data.records
          this.config.total = res.data.total
          this.config.loading = false
        })
    },

    editUser(row) {
      console.log(row)
      this.operateType = 'edit'
      this.isShow = true
      this.operateForm = row
    },
    addUser() {
      this.operateType = 'add'
      this.isShow = true
      this.operateForm = {}
    },
    //修改或者增加的弹出框事件
    confirm() {
      let confirm = false
      this.$refs['cf'].$refs['commonForm'].validate(valid => {
        confirm = valid
      })
      if (!confirm) {
        console.log('验证不通过')
        return
      }
      if (this.operateType === 'edit') {
        this.$http.post('/carp/permission/student/edit', this.operateForm).then(res => {
          console.log(res.data)
          if (res.code == 0) {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          } else {
            this.$message({
              type: 'success',
              message: '修改失败!'
            })
          }
          this.isShow = false
          this.getList(1)
        })
      } else {
        this.$http.post('/carp/permission/student/save', this.operateForm).then(res => {
          if (res.code == 0) {
            this.$message({
              type: 'success',
              message: '添加成功!'
            })
          } else {
            this.$message({
              type: 'success',
              message: '添加失败!'
            })
          }
          this.isShow = false
          this.getList(1)
        })
      }
    },
    delUser(row) {
      this.$confirm('此操作将永久删除, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          let id = row.id
          this.$http.delete('/carp/permission/student/del/' + id).then(res => {
            if (res.code == 0) {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
            } else {
              this.$message({
                type: 'success',
                message: '删除失败!'
              })
            }
            this.getList(1)
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    }
  },
  created() {
    this.getList(1)
  }
}
</script>

<style lang="less" scoped></style>
