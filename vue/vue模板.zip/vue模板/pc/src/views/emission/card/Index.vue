<template>
  <common-table-control
    :formConfig="form"
    :allowEdit="false"
    :addUrl="addUrl"
    :delUrl="delUrl"
    :editUrl="editUrl"
    :searchUrl="searchUrl"
  ></common-table-control>
</template>
<script>
import commonTableControl from '../../../components/CommonTableControl'
export default {
  name: 'transport',
  data() {
    return {
      // 表单配置
      form: {
        // 显示
        show: false,
        // 操作格式
        type: 'add',
        // 表单数据
        data: {
          name: '',
          buildUnit: '',
          constructionUnit: '',
          emissionPermitStartDate: '',
          emissionPermitEndDate: '',
          garbageStationId: '',
          issueDate: '',
          issueUnit: '',
          projectId: '',
          projectName: '',
          totalDischarge: '',
          transportCompany: ''
        },
        // 表格标题
        label: {
          accessoryId: {
            label: '附件',
            type: 'uploadImg',
            colType: 'download',
            width: 160,
            url: '/carp/business/a/q/upload/upload',
            before: file => {
              const isJPG = file.type === 'image/jpeg'
              const isLt2M = file.size / 1024 / 1024 < 2
              if (!isJPG) {
                this.$message.error('上传头像图片只能是 JPG 格式!')
              }
              if (!isLt2M) {
                this.$message.error('上传头像图片大小不能超过 2MB!')
              }
              return isJPG && isLt2M
            },
            success: ({ code, data }) => {
              if (!code === 4002) {
                this.form.data.accessoryId = null
                this.$message.err('图片上传失败')
              } else {
                this.form.data.accessoryId = data
                this.$message('图片上传成功')
              }
            },
            allowReset: false
          },
          buildUnit: {
            label: '建设单位',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.buildUnit.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          constructionUnit: {
            label: '施工单位',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.constructionUnit.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          transportCompany: {
            label: '运输企业',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.transportCompany.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          issueUnit: {
            label: '发证单位',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.issueUnit.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          // 项目ID
          projectId: {
            label: '项目名称',
            type: 'search',
            placeholder: '搜索项目名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/project/list', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.projectId.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          projectName: {
            label: '项目名称',
            type: 'string',
            show: false,
            allowReset: false
          },
          garbageStationId: {
            label: '消纳站信息Id',
            type: 'number',
            show: false,
            allowReset: true
          },
          emissionPermitStartDate: {
            label: '排放证开始时间',
            type: 'date',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          emissionPermitEndDate: {
            label: '排放证结束时间',
            type: 'date',
            width: 160,
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          issueDate: {
            label: '发证时间',
            type: 'date',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          totalDischarge: {
            label: '排放总量',
            type: 'string',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          }
        }
      },
      addUrl: '/carp/business/a/q/discharge/permit',
      delUrl: '/carp/business/a/q/discharge/permit',
      editUrl: '/carp/business/a/q/discharge/permit',
      searchUrl: '/carp/business/a/q/discharge/permit/list'
    }
  },
  watch: {
    'form.data.projectId': {
      handler: function(val) {
        this.debounce(() => {
          this.form.label.projectId.item.every(item => {
            if (item.code === val) {
              // 获取项目名称
              this.form.data.projectName = item.label
              // 获取消纳站ID
              this.$http.get(`/carp/business/a/q/garbage/station/list/project/${item.code}`).then(({ code, data }) => {
                if (code === 0) {
                  let id = '1'
                  if (data[0]) {
                    id = data[0].id
                  }
                  this.form.data.garbageStationId = id
                } else {
                  this.form.data.garbageStationId = '1'
                }
              })
            } else {
              return true
            }
          })
        }, 1000)()
      }
    }
  },
  components: {
    commonTableControl
  }
}
</script>
