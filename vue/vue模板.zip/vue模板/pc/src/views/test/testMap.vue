<template>
  <div class="manage">
    <Map></Map>
  </div>
</template>
<script>
import Map from '../../components/Map'
export default {
  components: {
    Map
  }
}
</script>

<style lang="less" scoped></style>
