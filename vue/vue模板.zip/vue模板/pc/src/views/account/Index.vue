<template>
  <common-table-control :formConfig="form" :addUrl="addUrl" :delUrl="delUrl" :searchUrl="searchUrl"></common-table-control>
</template>

<script>
import commonTableControl from '../../components/CommonTableControl'
export default {
  data() {
    return {
      // 表单配置
      form: {
        // 显示
        show: false,
        // 操作格式
        type: 'add',
        // 表单数据
        data: {
          companyName: null,
          companyId: null,
          projectName: null,
          projectId: null,
          garbageName: null,
          garbageId: null,
          productionDate: null,
          expiryDate: null,
          licensePlate: null,
          licensePlateId: null
        },
        // 表格标题
        label: {
          companyName: {
            label: '运输公司名称',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.companyName.item = result
                })
            },
            allowReset: false
          },
          companyId: {
            label: '运输公司id',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.companyId.item = result
                })
            },
            allowReset: false
          },
          projectName: {
            label: '排放源',
            type: 'search',
            placeholder: '搜索项目名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/project/list', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.projectName.item = result
                })
            },
            allowReset: false
          },
          projectId: {
            label: '排放源id',
            type: 'search',
            placeholder: '搜索项目名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/project/list', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.projectId.item = result
                })
            },
            allowReset: false
          },
          garbageName: {
            label: '消纳站名字',
            type: 'string',
            allowReset: false,
            rule: {
              regExp: /^([\u4e00-\u9fa5]|[a-z]){1,20}$/gi,
              message: '20位以内的汉字或英文'
            }
          },
          garbageId: {
            label: '消纳站id',
            type: 'string',
            allowReset: false,
            rule: {
              regExp: /^([\u4e00-\u9fa5]|[a-z]){1,20}$/gi,
              message: '20位以内的汉字或英文'
            }
          },
          productionDate: {
            label: '准行时间',
            type: 'date',
            allowReset: false
          },
          expiryDate: {
            label: '有效期',
            type: 'date',
            allowReset: false
          },
          licensePlate: {
            label: '车牌',
            type: 'string',
            allowReset: false
          }
        }
      },
      // 增删改api
      addUrl: '/a/q/transport/certificate/insert',
      delUrl: '/a/q/transport/certificate/',
      searchUrl: '/carp/business/a/q/transport/certificate/project'
    }
  },
  components: {
    commonTableControl
  }
}
</script>
