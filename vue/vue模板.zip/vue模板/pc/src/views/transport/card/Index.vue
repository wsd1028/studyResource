<template>
  <common-table-control :formConfig="form" :addUrl="addUrl" :delUrl="delUrl" :searchUrl="searchUrl"></common-table-control>
</template>
<script>
import commonTableControl from '../../../components/CommonTableControl'
export default {
  data() {
    return {
      // 表单配置
      form: {
        // 显示
        show: false,
        // 操作格式
        type: 'add',
        // 表单数据
        data: {
          companyName: null,
          companyId: null,
          projectName: null,
          projectId: null,
          garbageName: null,
          garbageId: null,
          productionDate: null,
          expiryDate: null,
          licensePlate: null
        },
        // 表格标题
        label: {
          companyName: {
            label: '运输公司名称',
            type: 'string',
            default: '测试公司1',
            show: false,
            allowReset: false
          },
          // 运输公司ID
          companyId: {
            label: '运输公司名称',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.companyId.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          projectName: {
            label: '排放源',
            type: 'string',
            default: '1252413725971869698',
            show: false,
            allowReset: false
          },
          // 项目ID
          projectId: {
            label: '排放源',
            type: 'search',
            placeholder: '搜索项目名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/project/list', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.projectId.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          garbageName: {
            label: '消纳站名称',
            type: 'string',
            default: '北京市朝阳区垃圾粪便渣土消纳管理站',
            show: false,
            allowReset: false
          },
          garbageId: {
            label: '消纳站id',
            type: 'string',
            default: 1,
            show: false,
            allowReset: false
          },
          productionDate: {
            label: '准行时间',
            type: 'date',
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          expiryDate: {
            label: '有效期',
            type: 'date',
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          licensePlate: {
            label: '车牌',
            type: 'string',
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          }
        }
      },
      // 增删改api
      addUrl: '/carp/business/a/q/transport/certificate/insert',
      delUrl: '/carp/business/a/q/transport/certificate/',
      searchUrl: '/carp/business/a/q/transport/certificate/project'
    }
  },
  watch: {
    'form.data.companyId': {
      handler: function(val) {
        this.debounce(() => {
          this.form.label.companyId.item.every(item => {
            if (item.code === val) {
              // 获取公司名称
              this.form.data.companyName = item.label
              return false
            } else {
              return true
            }
          })
        }, 1000)()
      }
    },
    'form.data.projectId': {
      handler: function(val) {
        this.debounce(() => {
          this.form.label.projectId.item.every(item => {
            if (item.code === val) {
              // 获取项目名称
              this.form.data.projectName = item.label
              // 获取消纳站ID
              this.$http.get(`/carp/business/a/q/garbage/station/list/project/${item.code}`).then(({ code, data }) => {
                if (code === 0) {
                  let id = this.form.label.garbageId.default
                  let name = this.form.label.garbageName.default
                  if (data[0]) {
                    id = data[0].id
                    name = data[0].name
                  }
                  this.form.data.garbageName = name
                  this.form.data.garbageId = id
                }
              })
            } else {
              return true
            }
          })
        }, 1000)()
      }
    }
  },
  components: {
    commonTableControl
  }
}
</script>
