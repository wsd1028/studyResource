<template>
  <el-container>
    <el-header height="auto"><common-header></common-header></el-header>
    <el-container>
      <el-aside width="auto"><common-aside></common-aside></el-aside>
      <el-main> <common-tab></common-tab><router-view /></el-main>
    </el-container>
  </el-container>
</template>

<script>
import CommonHeader from '../components/CommonHeader.vue'
import CommonAside from '../components/CommonAside'
import CommonTab from '../components/CommonTab'
export default {
  components: {
    CommonHeader,
    CommonAside,
    CommonTab
  }
}
</script>

<style lang="less" scoped>
.el-header {
  background-color: #333;
}
.el-main {
  height: 100%;
  padding: 0;
  overflow: hidden;
}
.el-container {
  height: 100%;
}
</style>
