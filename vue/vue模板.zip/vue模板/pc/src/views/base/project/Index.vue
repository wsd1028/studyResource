<template>
  <common-table-control :formConfig="form" :addUrl="addUrl" :delUrl="delUrl" :editUrl="editUrl" :searchUrl="searchUrl"></common-table-control>
</template>
<script>
import commonTableControl from '../../../components/CommonTableControl'
export default {
  data() {
    return {
      // 表单配置
      form: {
        // 显示
        show: false,
        // 操作格式
        type: 'add',
        // 表单数据
        data: {
          address: '',
          dictCode: '',
          adminAreaId: null,
          areaId: null,
          buildUnit: '',
          companyId: null,
          startDate: '',
          completeDate: '',
          constructUnit: '',
          creator: '',
          designUnit: '',
          latitude: null,
          longitude: null,
          manager: '',
          managerPhone: '',
          name: '',
          state: null,
          totalCost: null
        },
        // 表格标题
        label: {
          name: {
            label: '项目名称',
            type: 'string',
            allowReset: false,
            rule: {
              regExp: /^.{1,100}$/gi,
              message: '20位以内的汉字英文或数字'
            }
          },
          address: {
            label: '项目地址',
            type: 'map',
            allowReset: false,
            location: '宜宾市',
            getLocation(res) {
              this.form.data.address = res.address
              this.form.data.longitude = res.point.lng
              this.form.data.latitude = res.point.lat
            },
            rule: {
              regExp: /^.{2,100}$/,
              message: '2-30位的汉字英文或数字'
            }
          },
          latitude: {
            label: '纬度',
            type: 'number',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          longitude: {
            label: '经度',
            type: 'number',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          areaId: {
            label: '地区码',
            type: 'number',
            allowReset: true,
            default: 5115,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          dictCode: {
            label: '项目类型',
            type: 'select',
            item: [],
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          state: {
            label: '项目状态',
            type: 'select',
            item: [
              {
                code: 1,
                label: '筹备'
              },
              {
                code: 2,
                label: '立项'
              },
              {
                code: 3,
                label: '在建'
              },
              {
                code: 4,
                label: '完工'
              },
              {
                code: 6,
                label: '竣工'
              }
            ],
            allowReset: true
          },
          creator: {
            label: '项目创建者',
            type: 'string',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          manager: {
            label: '项目经理',
            type: 'string',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          managerPhone: {
            label: '项目经理电话',
            type: 'string',
            width: 160,
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          designUnit: {
            label: '设计单位',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.designUnit.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          constructUnit: {
            label: '建设单位',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.constructUnit.item = result
                })
            },
            allowReset: false,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          buildUnit: {
            label: '施工单位',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.name,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.buildUnit.item = result
                })
            },
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          totalCost: {
            label: '工程总造价',
            type: 'number',
            allowReset: true
          },
          // 项目所属公司ID
          companyId: {
            label: '项目所属公司',
            type: 'search',
            placeholder: '搜索公司名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/company/page', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.name
                    }))
                  } else result = []
                  this.form.label.companyId.item = result
                })
            },
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          adminAreaId: {
            label: '项目所属行政地区',
            type: 'search',
            placeholder: '搜索地区名称',
            item: [],
            search: query => {
              this.$http
                .get('/carp/business/a/q/area/leading', {
                  params: {
                    page: 1,
                    limit: 6,
                    name: query
                  }
                })
                .then(({ code, data }) => {
                  let result = []
                  if (code === 0) {
                    result = data.records.map(item => ({
                      code: item.id,
                      label: item.fullName
                    }))
                  } else result = []
                  this.form.label.adminAreaId.item = result
                })
            },
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          startDate: {
            label: '开工时间',
            type: 'date',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          },
          completeDate: {
            label: '完工时间',
            type: 'date',
            allowReset: true,
            rule: {
              regExp: /./g,
              message: '不能为空'
            }
          }
        }
      },
      // 增删改api
      addUrl: '/carp/business/a/q/project',
      delUrl: '/carp/business/a/q/project',
      editUrl: '/carp/business/a/q/project',
      searchUrl: '/carp/business/a/q/project/list'
    }
  },
  methods: {
    /* *
     * 获取工地类型
     * * */
    getProjectType() {
      this.$http.get('/carp/business/a/q/dict/category/project_type').then(({ code, data }) => {
        if (code !== 0) {
          console.log('请求工地类型失败')
          return
        }
        this.form.label.dictCode.item = data.map(item => {
          return {
            code: item.code,
            label: item.name
          }
        })
      })
    }
  },
  created() {
    // 获取企业类型
    this.getProjectType()
  },
  components: {
    commonTableControl
  }
}
</script>
