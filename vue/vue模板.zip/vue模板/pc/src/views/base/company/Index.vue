<template>
  <common-table-control :formConfig="form" :addUrl="addUrl" :delUrl="delUrl" :editUrl="editUrl" :searchUrl="searchUrl"></common-table-control>
</template>
<script>
import commonTableControl from '../../../components/CommonTableControl'
export default {
  data() {
    return {
      // 表单配置
      form: {
        // 显示
        show: false,
        // 操作格式
        type: 'add',
        // 表单数据
        data: {
          name: '',
          legalPerson: '',
          legalPhone: '',
          address: '',
          phone: '',
          type: '',
          visible: ''
        },
        // 表格标题
        label: {
          name: {
            label: '企业名称',
            type: 'string',
            allowReset: false,
            rule: {
              regExp: /^([\u4e00-\u9fa5]|[a-z]){1,100}$/gi,
              message: '100位以内的汉字或英文'
            }
          },
          legalPerson: {
            label: '企业法人',
            type: 'string',
            allowReset: true,
            rule: {
              regExp: /^[\u4e00-\u9fa5]{2,4}$/gi,
              message: '请输入正确的姓名'
            }
          },
          legalPhone: {
            label: '法人电话',
            type: 'string',
            allowReset: true,
            rule: {
              regExp: /^((\d{3}-\d{8}|\d{4}-\d{7})|(^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$))$/g,
              message: '请输入国内有效手机或电话号码'
            }
          },
          address: {
            label: '企业地址',
            type: 'map',
            allowReset: false,
            location: '宜宾市',
            getLocation(res) {
              this.form.data.address = res.address
            },
            rule: {
              regExp: /^.{2,100}$/,
              message: '2-100位的汉字英文或数字'
            }
          },
          phone: {
            label: '企业联系电话',
            type: 'string',
            width: 160,
            allowReset: true,
            rule: {
              regExp: /^((\d{3}-\d{8}|\d{4}-\d{7})|(^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$))$/g,
              message: '请输入国内有效手机或电话号码'
            }
          },
          type: {
            label: '公司类型',
            type: 'select',
            item: {},
            allowReset: true
          },
          visible: {
            label: '可见状态',
            type: 'radio',
            item: [
              {
                code: true,
                label: '可见'
              },
              {
                code: false,
                label: '隐藏'
              }
            ],
            allowReset: true
          }
        }
      },
      addUrl: '/carp/business/a/q/company',
      delUrl: '/carp/business/a/q/company',
      editUrl: '/carp/business/a/q/company',
      searchUrl: '/carp/business/a/q/company/page'
    }
  },
  methods: {
    /* *
     * 获取企业类型添加到表单配置中
     * * */
    getCompanyType() {
      this.$http.get('/carp/business/a/q/dict/category/company_type').then(({ code, data }) => {
        if (code !== 0) {
          console.log('请求企业类型失败')
          return
        }
        this.form.label.type.item = data.map(item => ({
          code: item.code,
          label: item.name
        }))
      })
    }
  },
  created() {
    // 获取企业类型
    this.getCompanyType()
  },
  components: {
    commonTableControl
  }
}
</script>
