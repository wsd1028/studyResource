<template>
  <common-table-control :formConfig="form" :addUrl="addUrl" :delUrl="delUrl" :editUrl="editUrl" :searchUrl="searchUrl"></common-table-control>
</template>
<script>
import commonTableControl from '../../../components/CommonTableControl'
export default {
  name: 'transport',
  data() {
    return {
      // 表单配置
      form: {
        // 显示
        show: false,
        // 操作格式
        type: 'add',
        // 表单数据
        data: {
          name: null,
          fullName: null,
          pinyin: null,
          address: null,
          level: null,
          code: null,
          parentId: null,
          createDate: null,
          modifyDate: null
        },
        // 表格标题
        label: {
          name: {
            label: '地区名称',
            allowReset: false,
            type: 'map',
            location: '宜宾市',
            getLocation(res) {
              this.form.data.name = this.form.data.fullName = res.address
              this.$http
                .get('/carp/business/a/q/area/leading?limit=10&page=1&name=宜宾县', {
                  params: {
                    limit: 1,
                    page: 1,
                    name: res.addressComponents.district
                  }
                })
                .then(({ code, data }) => {
                  if (code === 0 || data.records[0]) {
                    let parentId = data.records[0].parentId
                    if (parentId) {
                      this.from.data.parentId = parentId
                    }
                  }
                })
            },
            rule: {
              regExp: /^([\u4e00-\u9fa5]|\w){2,30}$/,
              message: '2-30位的汉字英文或数字'
            }
          },
          fullName: {
            label: '完整地区名称',
            type: 'string',
            rule: {
              regExp: /^([\u4e00-\u9fa5]|\w){2,30}$/,
              message: '2-30位的汉字英文或数字'
            }
          },
          pinyin: {
            label: '地区名称首字母简拼',
            type: 'string',
            rule: {
              regExp: /^.{6,30}$/,
              message: '6-30位的拼音字母'
            }
          },
          address: {
            label: '详细地址',
            type: 'string',
            rule: {
              regExp: /^([\u4e00-\u9fa5]|\w){2,30}$/,
              message: '2-30位的汉字英文或数字'
            }
          },
          level: {
            label: '省市排序',
            type: 'select',
            item: [
              {
                code: 1,
                label: '省'
              },
              {
                code: 2,
                label: '市'
              },
              {
                code: 3,
                label: '区'
              },
              {
                code: 4,
                label: '镇'
              }
            ],
            rule: {
              regExp: /^\w$/,
              message: '不能为空'
            }
          },
          code: {
            label: '地区码',
            type: 'string',
            default: 5115,
            show: false,
            rule: {
              regExp: /^\d{2,10}$/,
              message: '2-10位的数字'
            }
          },
          parentId: {
            label: '上级地区ID',
            type: 'number',
            default: 207360,
            show: false,
            rule: {
              regExp: /^\d{2,10}$/,
              message: '2-10位的数字'
            }
          },
          createDate: {
            label: '创建时间',
            type: 'date',
            allowReset: false,
            rule: {
              regExp: /\d{4}(-\d{1,2}){2}\s(\d{1,2}(:|$)){3}/g,
              message: '请输入正确的日期格式'
            }
          },
          modifyDate: {
            label: '修改时间',
            type: 'date',
            rule: {
              regExp: /\d{4}(-\d{1,2}){2}\s(\d{1,2}(:|$)){3}/g,
              message: '请输入正确的日期格式'
            }
          }
        }
      },
      addUrl: '/carp/business/a/q/area/leading/increase',
      delUrl: '/carp/business/a/q/area/leading',
      editUrl: '/carp/business/a/q/area/leading',
      searchUrl: '/carp/business/a/q/area/leading'
    }
  },
  components: {
    commonTableControl
  }
}
</script>
