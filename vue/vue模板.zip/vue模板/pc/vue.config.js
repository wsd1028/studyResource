module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/myvue/' : '/',

  devServer: {
    port: 3333,
    open: true,
    proxy: {
      //中心
      '/carp': {
        target: 'http://192.168.31.53',
        ws: true,
        changeOrigin: true,
        pathRewrite: {
          '^/carp': ''
        }
      }
    }
  },
  pluginOptions: {
    'style-resources-loader': {
      preProcessor: 'less',
      patterns: []
    }
  }
}
