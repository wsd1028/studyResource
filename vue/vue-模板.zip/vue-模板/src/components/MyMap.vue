<template>
  <div class="MyMap">
    <van-field center clearable label="地址" label-width="40" left-icon="search" placeholder="请输入搜索地址" v-model="mapConfig.keyword"></van-field>
    <van-field
      center
      class
      disabled
      label="选中地址"
      label-width="70"
      left-icon="location"
      placeholder="当前选中地址"
      v-if="!position.lng"
      v-model="mapConfig.chooseAddress"
    >
      <template #button>
        <van-button @click="handelAddressYes" size="small" type="primary">确认</van-button>
      </template>
    </van-field>
    <baidu-map
      :center="mapConfig.center"
      :dragging="mapConfig.dragging"
      :scroll-wheel-zoom="true"
      :style="{ height: position.lng ? '200px' : '' }"
      :zoom="mapConfig.zoom"
      @click="getPoint"
      @ready="onBaiduMapReady"
      @touchend="mapTouchend"
      @touchmove="mapTouchmove"
      class="bm-view"
    >
      <bm-view class="map" v-if="!position.lng"></bm-view>
      <bm-marker :dragging="false" :position="mapConfig.position" @dragend="getPoint">
        <bm-info-window :show="mapConfig.showMark" style="font-size: 14px" v-on:close="infoWindowClose">
          <p>地址：{{ mapConfig.markAddress }}</p>
        </bm-info-window>
      </bm-marker>
      <bm-local-search :auto-viewport="true" :keyword="mapConfig.keyword" @infohtmlset="handelSearch" class="searchMap" v-if="!position.lng"></bm-local-search>
    </baidu-map>
  </div>
</template>
<script>
export default {
  data() {
    return {
      addressData: {}, //选中地图信息
      //地图弹框
      mapDia: false,
      searchValue: '',
      //地图配置
      mapConfig: {
        zoom: 15,
        dragging: false,
        center: {}, //地图中心
        position: {}, //定位
        showMark: false,
        markAddress: '', //点击地图获得的地址
        loaction: '', //搜索的城市
        keyword: '', //详细地址
        chooseAddress: '' //详细地址
      }
    }
  },
  props: {
    position: {
      type: Object,
      default: function() {
        return {}
      }
    },
    needCode: {
      type: Boolean,
      default: false
    },
    address: {
      type: String,
      default: ''
    }
  },
  methods: {
    //打开地图弹窗
    showMap() {
      this.mapDia = !this.mapDia
    },
    //触摸移动时触发此事件
    mapTouchmove(e) {
      this.mapConfig.dragging = true
    },
    //触摸结束时触发此事件
    mapTouchend(e) {
      this.mapConfig.dragging = false
    },
    //得到区域code
    async getAreaCode(lat, lng) {
      let resp = await this.$http.get(
        `/baiduApi/reverse_geocoding/v3/?ak=${this.$dictionaries.ak}&output=json&extensions_town=true&coordtype=wgs84ll&location=${lat},${lng}`
      )
      if (resp.status == 0) {
        this.addressData.areaCodeMsg = resp.result
      } else {
        this.$dialog.alert({
          message: '获取区域代码失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //点击地图
    async getPoint(e) {
      this.mapConfig.dragging = false
      let geocoder = new BMap.Geocoder() //创建地址解析器的实例
      geocoder.getLocation(e.point, rs => {
        //地址描述
        this.mapConfig.position = e.point
        this.mapConfig.chooseAddress = rs.address
        this.mapConfig.markAddress = rs.address
        rs.chooseAddress = rs.address
        this.addressData = rs
      })
      this.mapConfig.showMark = true
    },
    //关闭mark层
    infoWindowClose() {
      this.mapConfig.showMark = false
    },
    //点击搜索的地区
    handelSearch(e) {
      this.mapConfig.chooseAddress = e.address
      e.chooseAddress = e.address
      this.addressData = e
    },
    //地图初始化时,定位当前位置
    onBaiduMapReady(e) {
      const that = this
      this.BMap = e.BMap
      if (this.BMap) {
        const geolocation = new this.BMap.Geolocation()
        geolocation.getCurrentPosition(res => {
          this.addressData = res
          const { lng, lat } = res.point
          const { province, city, district, street, street_number } = res.address
          if (JSON.stringify(this.position) == '{}') {
            this.mapConfig.center = res.point
            this.mapConfig.position = res.point
          } else {
            this.mapConfig.center = this.position
            this.mapConfig.position = this.position
            this.mapConfig.showMark = true
            this.mapConfig.markAddress = this.address
          }
          if (!this.address) {
            this.mapConfig.keyword = province + city
            this.searchValue = province + city
          } else {
            this.mapConfig.keyword = this.address
            this.searchValue = this.address
          }
        })
      }
    },
    //确认地址
    async handelAddressYes() {
      this.addressData.bool = false
      if (this.needCode && this.addressData.point) {
        await this.getAreaCode(this.addressData.point.lat, this.addressData.point.lng)
      }
      this.$emit('chooseAddress', this.mapConfig.chooseAddress, false, this.addressData)
    }
  }
}
</script>

<style lang="less" scoped>
.MyMap {
  .map {
    height: 200px;
  }
  .searchMap {
    max-height: 200px;
    overflow: auto;
  }
  .bm-view {
    width: 100%;
    .searchMap {
      margin-top: 4px;
      .van-cell {
        padding: 2px 0;
      }
    }
  }
}
</style>
