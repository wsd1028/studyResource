<template>
  <div>
    <router-view class="Router"></router-view>
    <van-tabbar v-model="$store.state.user.activeTab">
      <van-tabbar-item :to="$store.state.user.homeUrl" icon="wap-home">首页</van-tabbar-item>
      <van-tabbar-item :to="work" icon="cluster ">工作台</van-tabbar-item>
      <van-tabbar-item icon="map-marked" to="/main/mine">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>
<script>
export default {
  data() {
    return {
      active: 0,
      home: '',
      work: ''
    }
  },
  mounted() {
    if (this.$store.state.user.user.accountTypeDto.type == 50) {
      this.work = '/main/government/work'
    } else {
      this.work = '/main/company/work'
    }
  }
}
</script>
<style lang="less" scoped>
.Router {
  position: absolute;
  width: 100%;
  transition: all 0.8s ease;
  padding-bottom: 50px;
}

#app {
  text-align: -webkit-auto;
}
</style>
