<template>
  <div class="demo">
    <p class="test">9999999999999999999999999999999999999999999999999999999999999999999999999999999999</p>
    <baidu-map
      :center="mapConfig.position"
      :dragging="mapConfig.dragging"
      :scroll-wheel-zoom="true"
      :zoom="mapConfig.zoom"
      @ready="onBaiduMapReady"
      @touchend="mapTouchend"
      @touchmove="mapTouchmove"
      @zoomend="handelZoom"
      class="bm-view"
    >
      <!-- 区域点 -->
      <bm-marker
        :icon="{
          url: require('../../assets/city.svg'),
          size: { width: 80, height: 80 }
        }"
        :key="index"
        :position="item.position"
        v-for="(item, index) in cityList"
      >
        <bm-label :content="item.name + item.value" :labelStyle="cityLabel" :offset="{ width: 24, height: 20 }" />
      </bm-marker>
      <!-- <bm-boundary :fillOpacity="0" :strokeWeight="2" name="宜宾市叙州区" strokeColor="blue"></bm-boundary> -->
      <!-- <bm-boundary :fillOpacity="0" :strokeWeight="2" name="宜宾市翠屏区" strokeColor="red"></bm-boundary> -->
      <!-- <bm-marker
        :icon="{
          url: require('../../assets/location.svg'),
          size: { width: 80, height: 80 }
        }"
        :zIndex="100"
        :position="mapConfig.position"
      ></bm-marker>
      <bm-marker :icon="item.active ? activeIcon : normalIcon" :key="index" :position="item.position" @click="handelIcon" v-for="(item, index) in projectList">
        <bm-label :content="item.name" :labelStyle="item.active ? activeLable : normalLabel" :offset="{ width: 54, height: 30 }" />
      </bm-marker>-->
    </baidu-map>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mapConfig: {
        zoom: 9,
        dragging: true,
        center: {}, //地图中心
        position: {}, //定位
        showMark: false,
        loaction: '' //搜索的城市
      },
      activeIcon: {
        url: require('../../assets/activeProject.svg'),
        size: { width: 80, height: 80 }
      },
      normalIcon: {
        url: require('../../assets/normalProject.svg'),
        size: { width: 80, height: 80 }
      },
      normalLabel: {
        color: '#666',
        fontSize: '13px',
        fontWeight: 900,
        border: 0,
        '-webkit-text-stroke': '0.4px #fff',
        backgroundColor: 'transparent'
      },
      cityLabel: {
        color: '#fff',
        fontSize: '13px',
        border: 0,
        zIndex: 1,
        width: '20px',
        overflow: 'hidden',
        'text-overflow': 'ellipsis',
        height: '60px',
        display: 'block',
        'word-break': ' break-all',
        'white-space': 'wrap',
        '-webkit-line-clamp': 2,
        backgroundColor: 'transparent'
      },
      activeLable: {
        color: 'rgb(42, 130, 254)',
        fontSize: '13px',
        fontWeight: 900,
        border: 0,
        '-webkit-text-stroke': '0.4px #fff',
        backgroundColor: 'transparent'
      },
      cityList: [
        {
          name: '翠屏区',
          value: 0.75,
          position: {
            lng: 104.62,
            lat: 28.77
          }
        },
        {
          name: '屏山县',
          value: 0.75,
          position: {
            lng: 104.33,
            lat: 28.83
          }
        },
        {
          name: '珙县',
          value: 0.75,
          position: {
            lng: 104.72,
            lat: 28.45
          }
        }
      ],
      projectList: [
        {
          position: {
            lng: 104.63351906,
            lat: 28.7706748
          },
          name: '宜宾扬尘项目',
          active: true
        },
        {
          position: {
            lng: 104.63351906,
            lat: 28.7746748
          },
          name: '宜宾扬尘项目1',
          active: false
        },
        {
          position: {
            lng: 104.63351906,
            lat: 28.7796748
          },
          name: '宜宾扬尘项目2',
          active: false
        }
      ]
    }
  },
  components: {},

  mounted() {},
  methods: {
    //点击图标
    handelIcon(type, target) {
      console.log('type', type)
      console.log('target', target)
    },
    handelZoom(e) {
      // const { lng, lat } = e.target.getCenter()
      // this.center.lng = lng
      // this.center.lat = lat
      let zoom = e.target.getZoom()
      if (zoom == 19) {
        console.log('zoo19')
        this.mapConfig.zoom = 15
      }
    },
    //触摸移动时触发此事件
    mapTouchmove(e) {
      this.mapConfig.dragging = true
    },
    //触摸结束时触发此事件
    mapTouchend(e) {
      this.mapConfig.dragging = false
    },
    //关闭mark层
    infoWindowClose() {
      this.mapConfig.showMark = false
    },
    //地图初始化时,定位当前位置
    onBaiduMapReady(e) {
      const that = this
      this.BMap = e.BMap
      if (this.BMap) {
        const geolocation = new this.BMap.Geolocation()
        geolocation.getCurrentPosition(res => {
          const { lng, lat } = res.point
          this.mapConfig.center = res.point
          this.mapConfig.position = res.point
          const { province, city, district, street, street_number } = res.address
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.demo {
  height: 100%;
  width: 100%;
  .bm-view {
    height: 100%;
    width: 100%;
  }
}
</style>
