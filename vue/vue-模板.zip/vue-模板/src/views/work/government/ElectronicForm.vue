<template>
  <div class="workGov-electronicForm">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="电子联单">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
        <template #right>
          <van-icon @click="handelSearch" color="#333" name="search" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="msgBox">
      <div style="width:33%;text-align:center">
        <p class="label">全部固定源</p>
        <p class="titleOne" v-text="number.projectNum"></p>
      </div>
      <div style="width:33%;text-align:center">
        <p class="label">电子联单</p>
        <p class="titleOne blue" v-text="number.electronicNum"></p>
      </div>
      <div style="width:33%;text-align:center">
        <p class="label">车辆登记</p>
        <p class="titleOne red" v-text="number.carNum"></p>
      </div>
    </div>
    <van-tabs @change="select(1)" color="#4683f1" swipeable v-model="searchData.areaCode">
      <van-tab :key="index" :name="item.code" :title="item.name" v-for="(item, index) in areaList"></van-tab>
    </van-tabs>
    <section class="all">
      <v-touch @swipeleft="onSwipe('left')" @swiperight="onSwipe('right')">
        <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
          <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
            <van-swipe-cell :key="index" v-for="(item, index) in list">
              <van-row @click="handelDetail(item)" class="item">
                <van-col span="6" style="height:85px;position:relative">
                  <MyImage :imgUrl="$dictionaries.imgBaseUrl + item.carPhoto" fit="cover" height="100%" style="width:100%;height:100%" width="100%" />
                </van-col>
                <van-col span="1"></van-col>
                <van-col span="17">
                  <div class="top">
                    <p>
                      <span v-text="item.licenseNumber"></span>
                      <span class="carTag0" v-if="item.carState">名录车</span>
                      <span class="carTag1" v-if="!item.carState">非名录车</span>
                    </p>
                  </div>
                  <div class="bottom">
                    <p>
                      项目名称:
                      <span v-text="item.projectName"></span>
                    </p>
                    <div class="dfsb">
                      <p>
                        所属区县:
                        <span v-text="item.projectAreaName"></span>
                      </p>
                    </div>
                    <p>
                      创建时间:
                      <span v-text="item.createDate"></span>
                    </p>
                  </div>
                </van-col>
              </van-row>
            </van-swipe-cell>
          </van-list>
        </van-pull-refresh>
      </v-touch>
    </section>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      areaList: [],
      list: [],
      loading: false,
      refreshloading: false,
      finished: false,
      number: {},
      searchData: {
        plateNo: '',
        limit: 10,
        page: 1,
        areaCode: ''
      }
    }
  },
  mounted() {
    this.getArea()
    this.getNumber()
  },
  methods: {
    //滑动
    onSwipe(type) {
      let length = this.areaList.length
      let index = 0
      for (let i = 0; i < length; i++) {
        if (this.areaList[i].code == this.searchData.areaCode) {
          index = i
        }
      }
      if (type == 'left') {
        if (index != length - 1) {
          this.searchData.areaCode = this.areaList[index + 1].code
        }
      }
      if (type == 'right') {
        if (index != 0) {
          this.searchData.areaCode = this.areaList[index - 1].code
        }
      }
    },
    async getNumber() {
      let resp = await this.$http.get('/carp/business/a/q/electronic/num/statistics')
      if (resp.code == 0) {
        this.number = resp.data
      } else {
        this.$dialog.alert({
          message: '获取信息失败',
          confirmButtonColor: 'red'
        })
      }
    },
    //得到区域
    async getArea() {
      let resp = await this.$http.get('/carp/business/a/q/area/leading?limit=9999&page=1&fullName=宜宾市&level=3')
      if (resp.code == 0) {
        this.areaList = resp.data.records
        this.areaList.unshift({
          name: '全部',
          code: ''
        })
      } else {
        this.$dialog.alert({
          message: '获取区域失败',
          confirmButtonColor: 'red'
        })
      }
    },
    //跳转联单详情
    handelDetail(params) {
      this.$router.push({
        name: 'workGov-electronicFormDetail',
        params
      })
    },
    // 点击搜索
    handelSearch() {
      this.$router.push({
        name: 'workGov-electronicFormSearch'
      })
    },
    //点击查看详情
    handelItem() {
      this.$router.push({
        name: 'workGov-electronicFormDetail'
      })
    },
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
      }
      let resp = await this.$http.get('/carp/business/a/q/electronic/workflow/government', {
        params: this.searchData
      })
      if (resp.code == 0) {
        if (page) {
          this.list = []
        }
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.refreshloading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取电子联单失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.workGov-electronicForm {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 30px;
  .red {
    color: #fa302b;
  }
  .blue {
    color: #3882ea;
  }
  .green {
    color: #0cc15d;
  }
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .msgBox {
    padding: 20px 10px;
    background-color: #fff;
    display: flex;
    .label {
      color: #c5c5c5;
      font-size: 16px;
    }
  }
  .all {
    background-color: #fff;
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 10px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
        }
      }
    }
  }
}
</style>
