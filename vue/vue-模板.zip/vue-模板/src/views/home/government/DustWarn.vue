<template>
  <div class="government-dustwarn">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="扬尘告警">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <van-tabs @change="select(1)" color="#4683f1" swipeable v-model="searchData.areaCode">
      <van-tab :key="index" :name="item.code" :title="item.name" v-for="(item, index) in areaList"></van-tab>
    </van-tabs>
    <section class="all">
      <v-touch @swipeleft="onSwipe('left')" @swiperight="onSwipe('right')">
        <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
          <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
            <div :key="index" class="item" v-for="(item, index) in list">
              <div class="left">
                <div>
                  <span class="projectName" v-text="item.projectName"></span>
                </div>
                <p>
                  项目地址:
                  <span v-text="item.address"></span>
                </p>
              </div>
              <div @click="handelItem(item)" class="rightIcon">
                <van-icon color="#d2d2d2" name="arrow" size="30" />
              </div>
            </div>
          </van-list>
        </van-pull-refresh>
      </v-touch>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [],
      areaList: [],
      loading: false,
      refreshloading: false,
      finished: false,
      searchData: {
        limit: 10,
        page: 1,
        name: '',
        areaCode: ''
      }
    }
  },
  mounted() {
    this.getArea()
  },
  components: {},
  methods: {
    async getArea() {
      let resp = await this.$http.get('/carp/business/a/q/area/leading?limit=9999&page=1&fullName=宜宾市&level=3')
      if (resp.code == 0) {
        this.areaList = resp.data.records
        this.areaList.unshift({
          name: '全部',
          code: ''
        })
      } else {
        this.$dialog.alert({
          message: '获取区域失败',
          confirmButtonColor: 'red'
        })
      }
    },
    //滑动
    onSwipe(type) {
      let length = this.tabList.length
      let index = 0
      for (let i = 0; i < length; i++) {
        if (this.areaList[i].id == this.searchData.areaId) {
          index = i
        }
      }
      if (type == 'left') {
        if (index != length - 1) {
          this.searchData.areaId = this.areaList[index + 1].id
        }
      }
      if (type == 'right') {
        if (index != 0) {
          this.searchData.areaId = this.areaList[index - 1].id
        }
      }
    },
    //点击查看详情
    handelItem(data) {
      this.$router.push({
        name: 'government-dustDevice',
        params: data
      })
    },
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
      }
      let resp = await this.$http.get('/carp/business/a/q/project/area/name', {
        params: this.searchData
      })
      if (resp.code == 0) {
        if (page) {
          this.list = []
        }
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.refreshloading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取项目失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less">
.government-dustwarn {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 40px;
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }

  .van-info {
    top: 12px;
    right: -11px;
  }
  .all {
    padding: 10px;
    .item {
      background-color: #fff;
      margin-top: 10px;
      padding: 10px;
      justify-content: space-between;
      align-items: center;
      display: flex;
      .rightIcon {
        text-align: center;
        height: 100%;
        width: 50px;
      }
      .projectName {
        color: #333;
        font-weight: bold;
        font-size: 18px;
      }
    }
  }
}
</style>
