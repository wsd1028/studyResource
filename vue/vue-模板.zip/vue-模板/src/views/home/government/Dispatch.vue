<template>
  <div class="dispatch">
    <header>
      <van-nav-bar @click-left="goBack" class="nav" title="督办派单">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <section>
      <van-tabs @change="select(1)" color="#4683f1" swipeable v-model="searchData.state">
        <van-tab :key="index" :name="item.name" :title="item.title" v-for="(item, index) in tabList"></van-tab>
      </van-tabs>
      <div class="box lincenseBox">
        <v-touch @swipeleft="onSwipe('left')" @swiperight="onSwipe('right')">
          <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
            <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
              <van-swipe-cell :key="index" v-for="(item, index) in list">
                <van-row @click="handelItem(item)" class="item">
                  <van-col span="24">
                    <div class="top">
                      <p class="textFlowP">
                        <span class="textFlow" v-text="item.id"></span>
                      </p>
                      <p class="carCreat">
                        <span class="state-span updateState" v-if="item.state == $dictionaries.dispatch.wait">待处理</span>
                        <span class="state-span waitState" v-if="item.state == $dictionaries.dispatch.waitCheck">待审核</span>
                        <span class="state-span delState" v-if="item.state == $dictionaries.dispatch.reject">已驳回</span>
                        <span class="state-span finishState" v-if="item.state == $dictionaries.dispatch.finish">已结案</span>
                        <span class="state-span cancelState" v-if="item.state == $dictionaries.dispatch.cancel">已作废</span>
                      </p>
                    </div>
                    <div class="bottom">
                      <p>
                        督办地址:
                        <span v-text="item.address"></span>
                      </p>
                      <p>
                        处理人员:
                        <span v-text="item.manager"></span>
                      </p>
                      <p>
                        创建时间:
                        <span v-text="item.createDate"></span>
                      </p>
                    </div>
                  </van-col>
                </van-row>
              </van-swipe-cell>
            </van-list>
          </van-pull-refresh>
        </v-touch>
      </div>
    </section>
    <div @click="handelCreat" class="iconBox">
      <van-icon name="plus" />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mainData: {},
      list: [],
      tabList: [
        {
          name: '',
          title: '全部'
        },
        {
          name: this.$dictionaries.dispatch.wait,
          title: '待处理'
        },
        {
          name: this.$dictionaries.dispatch.waitCheck,
          title: '待审核'
        },
        {
          name: this.$dictionaries.dispatch.reject,
          title: '已驳回'
        },
        {
          name: this.$dictionaries.dispatch.finish,
          title: '已结案'
        },
        {
          name: this.$dictionaries.dispatch.cancel,
          title: '已作废'
        }
      ],
      loading: false,
      refreshloading: false,
      finished: false,
      searchData: {
        limit: 10,
        page: 1,
        accountId: '',
        state: this.$dictionaries.dispatch.waitCheck
      }
    }
  },
  mounted() {},
  components: {},
  methods: {
    //滑动
    onSwipe(type) {
      let length = this.tabList.length
      let index = 0
      for (let i = 0; i < length; i++) {
        if (this.tabList[i].name == this.searchData.state) {
          index = i
        }
      }
      if (type == 'left') {
        if (index != length - 1) {
          this.searchData.state = this.tabList[index + 1].name
        }
      }
      if (type == 'right') {
        if (index != 0) {
          this.searchData.state = this.tabList[index - 1].name
        }
      }
    },
    goBack() {
      this.$router.go(-1)
    },
    //新建督办派单
    handelCreat() {
      this.$router.push({
        name: 'dispatchCreate'
      })
    },
    //跳转到督办派单详情
    handelItem(params) {
      this.$router.push({
        name: 'dispatchDetail',
        params
      })
    },
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
      }
      let user = this.$store.state.user.user
      let resp = await this.$http.get('/carp/business/a/q/task/accountId', {
        params: this.searchData
      })
      if (resp.code == 0) {
        if (page) {
          this.list = []
        }
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.refreshloading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取督办派单失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.dispatch {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 40px;
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  section {
    .item {
      background-color: #fff;
      padding: 10px;
      margin: 10px 10px 0;
    }
  }
  .lincenseBox {
    background-color: #f9f9f9;
    padding: 0;
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 15px;
      padding-left: 20px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
        }
      }
    }
  }
  .iconBox {
    position: fixed;
    right: 40px;
    bottom: 40px;
    i {
      background-color: #4186fc;
      color: #fff;
      font-weight: 800;
      font-size: 24px;
      width: 50px;
      height: 50px;
      border-radius: 100%;
      line-height: 50px;
      text-align: center;
      display: inline-block;
    }
  }
}
</style>
