<template>
  <div class="Home">
    <div class="head">
      <HomeTitle titleName="扬尘治理"></HomeTitle>
      <div>
        <div class="cell-box">
          <div class="top">
            <div class="msgItem">
              <span>
                <van-image :src="require('@/assets/image/man_icon.png')" height="20" width="20" />
              </span>
              <span class="text" style="fontSize:20px;fontWeight:800;color:#333" v-text="user.name"></span>
              <span style="color:#333;marginLeft:10px;fontSize:14px;fontWeight:800" v-text="user.work"></span>
            </div>
            <div class="msgItem">
              <van-image :src="require('@/assets/image/index_government_icon1.png')" height="18" width="18" />
              <span class="text" v-text="user.organizationDto"></span>
            </div>
            <div class="msgItem">
              <van-icon class="myIcon" color="#6c6c6c" name="location" size="18" />
              <span class="text" v-text="user.areaName"></span>
            </div>
            <div style="display:flex;width:100%;marginTop:30px">
              <div class="chartItems" style="marginRight:10px">
                <span style="color:#fc7403">AQI:{{ polluteData.AQI }}</span>
              </div>
              <div class="chartItems" style="marginLeft:10px">
                <span style="color:#f42037">PM10:{{ polluteData.pm10 }}μg/m3</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style="height:60px"></div>
      <van-notice-bar :text="noticeText" @replay="exposureReplay" color="#538dc3" speed="50">
        <template #right-icon>
          <div @click="goSkip('government-exposure')" class="exposureIcon">
            <span class="text">更多</span>
            <van-icon name="arrow" />
          </div>
        </template>
        <template #left-icon>
          <div>
            <span class="exposureText">曝光台</span>
          </div>
        </template>
      </van-notice-bar>
    </div>
    <div class="box">
      <div style="textAlign:left;lineHeight:40px">
        <span class="title2">待办</span>
        <van-divider></van-divider>
      </div>
      <div class="allIconBox">
        <div @click="goSkip('government-dustWarn')" class="tac">
          <div class="iconBox" style="color:#ee4634" v-text="dustWarnNum"></div>
          <span class="text">扬尘告警</span>
        </div>
        <div @click="goSkip('government-directoriesWarn')" class="tac">
          <div class="iconBox" style="color:#ee4634" v-text="todayWait.carNumber"></div>
          <span class="text">非名录车告警</span>
        </div>
        <div @click="goSkip('government-todayCheck')" class="tac">
          <div class="iconBox" style="color:#333" v-text="todayWait.todayCheckNumber"></div>
          <span class="text">每日巡检</span>
        </div>
        <div @click="goSkip('government-appointCheck')" class="tac">
          <div class="iconBox" v-text="todayWait.assignCheckNumber"></div>
          <span class="text">指派点检</span>
        </div>
        <div @click="goSkip('government-problemReport')" class="tac">
          <div class="iconBox" v-text="todayWait.questionReportNumber"></div>
          <span class="text">问题上报</span>
        </div>
        <div class="tac"></div>
      </div>
    </div>
    <div class="box" style="paddingTop:0">
      <van-cell is-link style="textAlign:left" to="/home/government/dispatch" value="更多">
        <template #title>
          <span class="title2">督办派单</span>
        </template>
      </van-cell>
      <van-divider></van-divider>
      <div class="activeBtn">
        <span :class="searchData.state === '' ? 'active' : ''" @click="handelActive('')">全部</span>
        <span :class="searchData.state === $dictionaries.dispatch.waitcheck ? 'active' : ''" @click="handelActive($dictionaries.dispatch.waitcheck)">
          <!-- eslint -->
          待处理
        </span>
        <span :class="searchData.state === $dictionaries.dispatch.finish ? 'active' : ''" @click="handelActive($dictionaries.dispatch.finish)">已结案</span>
      </div>
    </div>
    <div class="box lincenseBox">
      <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
        <van-swipe-cell :key="index" v-for="(item, index) in list">
          <van-row @click="goSkip('dispatchDetail', item)" class="item">
            <van-col span="24">
              <div class="top">
                <p class="textFlowP">
                  <span class="textFlow">派单号:{{ item.id }}</span>
                </p>
                <p class="carCreat">
                  <span class="state-span updateState" v-if="item.state == $dictionaries.dispatch.wait">待处理</span>
                  <span class="state-span waitState" v-if="item.state == $dictionaries.dispatch.waitCheck">待审核</span>
                  <span class="state-span delState" v-if="item.state == $dictionaries.dispatch.reject">已驳回</span>
                  <span class="state-span finishState" v-if="item.state == $dictionaries.dispatch.finish">已结案</span>
                  <span class="state-span cancelState" v-if="item.state == $dictionaries.dispatch.cancel">已作废</span>
                </p>
              </div>
              <div class="bottom">
                <p>
                  督办地址:
                  <span v-text="item.address"></span>
                </p>
                <p>
                  处理人员:
                  <span v-text="item.manager"></span>
                </p>
                <p>
                  创建时间:
                  <span v-text="item.createDate"></span>
                </p>
              </div>
            </van-col>
          </van-row>
        </van-swipe-cell>
      </van-list>
    </div>
  </div>
</template>

<script>
import HomeTitle from '@/components/HomeTitle.vue'
import { Bus } from '@/bus'
export default {
  data() {
    return {
      exposureList: [], //曝光台列表
      exposureIndex: 0, //曝光台下标
      noticeText: '', //当前曝光台文字
      user: {
        name: '',
        work: '',
        organizationDto: '',
        areaName: ''
      },
      dustWarnNum: 0,
      todayWait: {
        assignCheckNumber: 0,
        carNumber: 0,
        questionReportNumber: 0,
        taskNumber: 0,
        todayCheckNumber: 0
      },
      list: [], //督办派单列表
      loading: false, //加载
      finished: false, //完成
      polluteData: {
        AQI: 0,
        pm10: 0,
        pm25: 0
      },
      searchData: {
        limit: 10,
        page: 1,
        accountId: '',
        state: ''
      }
    }
  },
  mounted() {
    this.user.name = this.$store.state.user.user.accountBaseDto.name
    try {
      this.user.organizationDto = this.$store.state.user.user.organizationDto.name
      this.user.areaName = this.$store.state.user.user.organizationDto.areaName
    } catch {}
    try {
      this.user.work = this.$store.state.user.user.jobTitleDtoList[0].name
    } catch {}
    this.getExposure()
    this.getTodayWait()
    this.getDustWarnNum()
    const geolocation = new BMap.Geolocation()
    geolocation.getCurrentPosition(res => {
      const { lng, lat } = res.point
      this.getPollute(lng, lat)
    })
  },
  components: {
    HomeTitle
  },
  methods: {
    //得到扬尘告警数量
    async getDustWarnNum() {
      var fd = new FormData()
      fd.append('beginTimeEnd', this.$moment().format('YYYY-MM-DD HH:mm:ss'))
      fd.append(
        'beginTimeStart',
        this.$moment()
          .startOf('day')
          .format('YYYY-MM-DD HH:mm:ss')
      )
      fd.append('projectIdList', [])
      let resp = await this.$http.post('/carp/device/k/q/dust/alarm/total', fd)
      if (resp.code == 0) {
        this.dustWarnNum = resp.data
      } else {
        this.$dialog.alert({
          message: '获取扬尘告警数量:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //得到AQI,pm10
    async getPollute(longitude, latitude) {
      let resp = await this.$http.get(`/carp/device/a/q/dust/info/recent/monitor/data?longitude=${longitude}&latitude=${latitude}`)
      if (resp.code == 0) {
        this.polluteData = resp.data
      } else {
        this.$dialog.alert({
          message: '获取AQI/PM10失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //得到今日待办
    async getTodayWait() {
      let resp = await this.$http.get(`/carp/business/a/q/data/num/statistics`, {
        params: {
          receiverId: this.$store.state.user.user.id, //收单人id
          carState: 0, //非名录车状态
          todayState: this.$dictionaries.todayCheck.waitCheck, //今日巡检状态
          questionState: this.$dictionaries.problem.report, //问题上报状态
          assignState: this.$dictionaries.appointCheck.waitCheck, //指派点检状态
          taskState: this.$dictionaries.dispatch.waitCheck //督办派单状态
        }
      })
      if (resp.code == 0) {
        this.todayWait = resp.data
      } else {
        this.$dialog.alert({
          message: '获取今日待办:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //曝光台重新滚动
    exposureReplay() {
      this.exposureIndex++
      if (this.exposureIndex > this.exposureList.length) this.exposureIndex = 0
      this.noticeText = this.exposureList[this.exposureIndex].title
    },
    //得到曝光台信息
    async getExposure() {
      let resp = await this.$http.get('/carp/business/a/q/exposure/table/page?Page=1&Limit=9999')
      if (resp.code == 0) {
        this.exposureList = resp.data.records
        if (this.exposureList.length > 0) this.noticeText = this.exposureList[0].title
      }
    },
    //跳转路由
    goSkip(name, params) {
      this.$router.push({
        name,
        params
      })
    },
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
      }
      let resp = await this.$http.get('/carp/business/a/q/task/accountId', {
        params: this.searchData
      })
      if (resp.code == 0) {
        if (page) {
          this.list = []
        }
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取督办派单失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //点击按钮
    handelActive(val) {
      if (this.searchData.state !== val) {
        this.searchData.state = val
        this.select(1)
      }
    }
  }
}
</script>
<style lang="less" scoped>
.Home {
  padding-bottom: 50px;
  height: auto;
  background-color: #f9f9f9;
  .van-divider {
    margin: 0;
  }
  .head {
    height: 200px;
    margin-bottom: 100px;
  }
  .van-notice-bar {
    background-color: #fff;
  }
  .main {
    background: #f9f9f9;
  }
  .exposureIcon {
    padding-left: 10px;
  }
  .exposureText {
    font-style: italic;
    color: #3d87f0;
    font-weight: 800;
    padding-right: 10px;
  }
  .project-name {
    font-weight: 800;
  }
  .cell-box {
    padding: 20px;
    padding-bottom: 0;
    background-color: #4284f3;
    position: relative;
    height: 140px;
    .top {
      border-radius: 8px;
      background-color: #fff;
      padding: 20px;
      padding-top: 4px;
      position: absolute;
      width: 93%;
      margin: auto;
      top: 30px;
      left: 0;
      bottom: -50px;
      right: 0;
      box-shadow: 0 0 7px #e5e5e5;
      .msgItem {
        font-size: 18px;
        color: #656565;
        margin-top: 6px;
        text-align: left;
        .text {
          margin-left: 10px;
        }
      }

      .myIcon {
        font-weight: 800;
      }
    }
  }
  .chartItems {
    width: 50%;
    color: #5c5c5c;
    font-size: 16px;
    text-align: left;
  }
  .box {
    padding: 20px;
    margin-bottom: 20px;
    background-color: #fff;
    .van-cell {
      padding: 10px 0;
    }
    .title2 {
      font-weight: 800;
      color: #333;
      font-size: 16px;
    }
    .allIconBox {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      .tac {
        width: 33%;
        flex-shrink: 0;
        margin-top: 20px;
        .iconBox {
          font-size: 24px;
          color: #3a84f2;
        }
      }
      .text {
        color: #999;
        font-size: 16px;
        margin-top: 10px;
        display: inline-block;
        width: 100%;
      }
    }
    .dateBox {
      display: flex;
      justify-content: center;
      align-items: center;
      #chartPie,
      #chartPie1 {
        width: 80px;
        height: 80px;
        flex-shrink: 0;
        div {
          width: 100%;
        }
      }
      .item {
        flex-shrink: 0;
        .date {
          width: 100%;
          color: #999;
          font-weight: 800;
        }
        .text,
        sup {
          color: #9a9a9a;
        }
      }
    }
  }
  .activeBtn {
    text-align: left;
    margin-top: 20px;
    span {
      padding: 0 20px;
      border-radius: 14px;
      color: #999;
      line-height: 28px;
      text-align: center;
    }
    .active {
      background-color: #4186f4;
      color: #fff;
    }
  }
  .lincenseBox {
    background-color: #f9f9f9;
    padding: 0;
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 15px;
      padding-left: 20px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          flex-shrink: 0;
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
        }
      }
    }
  }
}
</style>
