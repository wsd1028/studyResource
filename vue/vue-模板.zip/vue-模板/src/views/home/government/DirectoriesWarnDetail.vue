<template>
  <div class="government-directoriesWarnDetail">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="非名录车告警">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="projectName">
      <span class="box"></span>
      <span class="name textFlow">项目名称:{{ paramsData.name }}</span>
    </div>
    <div class="all">
      <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
        <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
          <van-row :key="index" class="item" v-for="(item, index) in list">
            <van-col span="6" style="height:85px;position:relative">
              <div class="jin" v-if="item.direction == $dictionaries.direction.jin">进</div>
              <div class="chu" v-if="item.direction == $dictionaries.direction.chu">出</div>
              <MyImage :imgUrl="$dictionaries.imgBaseUrl + item.photo" height="100%" style="width:100%;height:100%" width="100%" />
            </van-col>
            <van-col span="1"></van-col>
            <van-col span="17">
              <div class="top">
                <p>
                  <van-image :src="require('@/assets/image/index_icon7.png')" height="16" style="margin-right:5px" width="25" />
                  <span v-text="item.license"></span>
                  <span class="carTag1">非名录车</span>
                </p>
              </div>
              <div class="bottom">
                <p>
                  当前项目:
                  <span v-text="item.workplaceName"></span>
                </p>
                <p>
                  创建时间:
                  <span v-text="item.violationDate"></span>
                </p>
              </div>
            </van-col>
          </van-row>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      paramsData: {},
      list: [],
      loading: false,
      refreshloading: false,
      finished: false,
      searchData: {
        limit: 10,
        page: 1,
        workplaceId: '',
        type: this.$dictionaries.machineType.company
      }
    }
  },
  mounted() {
    this.paramsData = this.$route.params
    this.searchData.workplaceId = this.$route.params.id
  },
  components: {},
  methods: {
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
        this.list = []
      }
      let resp = await this.$http.get(
        `/carp/business/a/q/warning/list/page?disposeState=0&code=${this.$dictionaries.warnType.car}&limit=${this.searchData.limit}&page=${this.searchData.page}&workplaceId=${this.searchData.workplaceId}`
      )
      if (resp.code == 0) {
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.refreshloading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取非目录车告警失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.government-directoriesWarnDetail {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 40px;
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .projectName {
    background-color: #fff;
    padding: 20px;
    line-height: 20px;
    font-weight: 700;
    font-size: 18px;
    display: flex;
    align-items: center;
    .box {
      height: 18px;
      width: 5px;
      background-color: #4186f6;
      flex-shrink: 0;
    }
    .name {
      flex-grow: 1;
      color: #4186f6;
      margin: 0 5px;
    }
  }
  .all {
    padding: 10px;
    background-color: #f9f9f9;
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 10px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        i {
          display: inline-block;
          margin-right: 5px;
        }
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          span {
            padding: 0 10px;
            border-radius: 14px;
            color: #fff;
            line-height: 28px;
            text-align: center;
          }
          .carCreat0 {
            background-color: #4186f4;
          }
          .carCreat1 {
            background-color: #ccc;
          }
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
          margin-top: 10px;
        }
      }
    }
  }
}
</style>
