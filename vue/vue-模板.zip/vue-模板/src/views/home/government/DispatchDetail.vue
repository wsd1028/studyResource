<template>
  <div class="dispatchDetail">
    <van-dialog :showConfirmButton="false" class="tips" title v-model="finishDia">
      <div style="padding:30px">
        <p style="textAlign:center">
          <van-icon color="#19c363" name="checked" size="20" />
          <span class="tipsMsg">确认该案件已经处理完成?</span>
        </p>
        <div class="tipsbtns">
          <van-button @click="finishDia = false" block class="myBtn2" color="#ddd" round size="small">取消</van-button>
          <van-button @click="checkYes" block class="myBtn" round size="small" type="info">确认</van-button>
        </div>
      </div>
    </van-dialog>
    <van-dialog :showConfirmButton="false" class="tips" title v-model="cancelDia">
      <div style="padding:30px">
        <p style="textAlign:center">
          <van-icon color="#19c363" name="checked" size="20" />
          <span class="tipsMsg">确认作废该督办派单?</span>
        </p>
        <div style="marginTop:20px">
          <van-field autosize clearable label="作废理由" placeholder="请输入作废理由" rows="1" type="textarea" v-model="mainData.remark" />
        </div>
        <div class="tipsbtns">
          <van-button @click="cancelDia = false" block class="myBtn2" color="#ddd" round size="small">取消</van-button>
          <van-button @click="handelCancel" block class="myBtn" round size="small" type="info">确认</van-button>
        </div>
      </div>
    </van-dialog>
    <van-dialog :showConfirmButton="false" class="tips" title v-model="rejectDia">
      <div style="padding:30px">
        <p style="textAlign:center">
          <van-icon color="#f6404f" name="clear" size="20" />
          <span class="tipsMsg">确认该案件需要驳回处理?</span>
        </p>
        <div style="marginTop:20px">
          <van-field autosize clearable label="驳回理由" placeholder="请输入驳回理由" rows="1" type="textarea" v-model="mainData.remark" />
        </div>
        <div class="tipsbtns">
          <van-button @click="rejectDia = false" block class="myBtn2" color="#ddd" round size="small">取消</van-button>
          <van-button @click="handelReject" block class="myBtn" round size="small" type="info">确认</van-button>
        </div>
      </div>
    </van-dialog>
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="督办派单详情">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="top">
      <div class="project">
        <span class="projectName textFlow" v-text="mainData.id"></span>
        <p class="carCreat">
          <span class="state-span updateState" v-if="mainData.state == $dictionaries.dispatch.wait">待处理</span>
          <span class="state-span waitState" v-if="mainData.state == $dictionaries.dispatch.waitCheck">待审核</span>
          <span class="state-span delState" v-if="mainData.state == $dictionaries.dispatch.reject">已驳回</span>
          <span class="state-span finishState" v-if="mainData.state == $dictionaries.dispatch.finish">已结案</span>
          <span class="state-span cancelState" v-if="mainData.state == $dictionaries.dispatch.cancel">已作废</span>
        </p>
      </div>
      <p class="address">
        地址:
        <span v-text="mainData.projectAddress"></span>
      </p>
    </div>
    <section>
      <van-tabs color="#4683f1" swipeable>
        <van-tab title="督办详情">
          <div class="item">
            <van-field disabled label="创建时间" v-model="mainData.createDate" />
            <van-field disabled label="市区县" v-model="mainData.areaName" />
            <van-field disabled label="部门" v-model="mainData.dept" />
            <van-field disabled label="处理人" v-model="mainData.processor" />
            <van-field disabled label="电话" v-model="mainData.phone" />
          </div>
          <div class="item">
            <div>
              <p class="title">图片</p>
              <div class="imgList">
                <MyImage
                  :imgUrl="$dictionaries.imgBaseUrl + item"
                  :key="index"
                  style="margin:5px;flexShrink:0"
                  v-for="(item, index) in mainData.startImageList"
                />
              </div>
            </div>
            <div style="marginTop:20px">
              <p class="title">描述</p>
              <p class="msg" v-text="mainData.startDescription"></p>
            </div>
          </div>
          <!-- 处理完成才有 -->
          <p class="title2" v-if="mainData.state != $dictionaries.dispatch.wait">督办处理结果</p>
          <div class="item" v-if="mainData.state != $dictionaries.dispatch.wait">
            <div>
              <p class="title">图片</p>
              <div class="imgList">
                <MyImage
                  :imgUrl="$dictionaries.imgBaseUrl + item"
                  :key="index"
                  style="margin:5px;flexShrink:0"
                  v-for="(item, index) in mainData.resultImageList"
                />
              </div>
            </div>
            <div style="marginTop:20px">
              <p class="title">描述</p>
              <p class="msg" v-text="mainData.resDescription"></p>
            </div>
          </div>
        </van-tab>
        <van-tab title="督办经过">
          <div class="pass">
            <van-steps :active="processList.length - 1" direction="vertical">
              <van-step :key="index" v-for="(item, index) in processList">
                <h3>
                  <span v-text="item.sort"></span>.
                  <span v-text="stateObj[item.nowState]"></span>
                </h3>
                <p class="passMsg">
                  创建时间:
                  <span v-text="item.createDate"></span>
                </p>
                <p class="passMsg">
                  市区县:
                  <span v-text="item.areaName"></span>
                </p>
                <p class="passMsg">
                  部门:
                  <span v-text="item.dept"></span>
                </p>
                <p class="passMsg">
                  处理人:
                  <span v-text="item.procesor"></span>
                </p>
                <p class="passMsg">
                  电话:
                  <span v-text="item.phone"></span>
                </p>
              </van-step>
            </van-steps>
          </div>
        </van-tab>
      </van-tabs>
      <div class="btns">
        <van-button
          @click="cancelDia = true"
          block
          class="mybtn"
          type="danger"
          v-if="mainData.state != $dictionaries.dispatch.finish && mainData.state != $dictionaries.dispatch.cancel && mainData.sponsorId == userMsg.id"
        >
          <!-- eslint -->
          作废
        </van-button>
        <van-button @click="finishDia = true" block class="mybtn" type="info" v-if="mainData.state == $dictionaries.dispatch.waitCheck">已完成</van-button>
        <van-button @click="rejectDia = true" block class="mybtn" type="info" v-if="mainData.state == $dictionaries.dispatch.waitCheck">驳回</van-button>
        <van-button
          @click="handelFix(mainData)"
          block
          class="mybtn"
          type="info"
          v-if="mainData.state == $dictionaries.dispatch.wait || mainData.state == $dictionaries.dispatch.reject"
        >
          <!-- eslint -->
          立即处理
        </van-button>
        <van-button
          @click="handelForward(mainData)"
          block
          class="mybtn"
          type="primary"
          v-if="mainData.state == $dictionaries.dispatch.wait || mainData.state == $dictionaries.dispatch.reject"
        >
          <!-- eslint -->
          转发
        </van-button>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mainData: {},
      //完成
      finishDia: false,
      //驳回
      rejectDia: false,
      //作废
      cancelDia: false,
      paramsData: {},
      processList: [],
      stateObj: {
        '5020': '已派单',
        '5050': '待审核',
        '5060': '已驳回',
        '5070': '已结案',
        '5080': '已作废'
      },
      userMsg: {}
    }
  },
  async mounted() {
    this.userMsg = this.$store.state.user.user
    if (JSON.stringify(this.$route.params) == '{}') {
      this.paramsData = this.$store.state.user.paramsData
    } else {
      this.paramsData = this.$route.params
      this.$store.commit('setParamsData', this.paramsData)
    }
    this.getMainData()
    this.getProcess()
    this.handelRead()
  },
  components: {},
  methods: {
    //已读
    async handelRead() {
      let res = await this.$http.post('/carp/business/a/q/task/readHistory', {
        taskId: this.paramsData.id,
        accountId: this.userMsg.id
      })
    },
    //作废
    async handelCancel() {
      let resp = await this.$http.post(`/carp/business/a/q/task/invaild?id=${this.mainData.id}&remark=${this.mainData.remark}`)
      if (resp.code == 0) {
        this.$dialog.alert({
          message: '作废成功',
          confirmButtonColor: 'green'
        })
        this.cancelDia = false
        this.getMainData()
        this.getProcess()
      } else {
        this.$dialog.alert({
          message: '作废失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //驳回
    async handelReject() {
      let resp = await this.$http.post(`/carp/business/a/q/task/reject?taskId=${this.mainData.id}&remark=${this.mainData.remark}`)
      if (resp.code == 0) {
        this.$dialog.alert({
          message: '驳回成功',
          confirmButtonColor: 'green'
        })
        this.rejectDia = false
        this.getMainData()
        this.getProcess()
      } else {
        this.$dialog.alert({
          message: '驳回失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //审核完成
    async checkYes() {
      let resp = await this.$http.post('/carp/business/a/q/task/taskId?taskId=' + this.mainData.id)
      if (resp.code == 0) {
        this.$dialog.alert({
          message: '审核成功',
          confirmButtonColor: 'green'
        })
        this.finishDia = false
        this.getMainData()
        this.getProcess()
      } else {
        this.$dialog.alert({
          message: '审核失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //立即处理
    handelFix(params) {
      this.$router.push({
        name: 'dispatchFix',
        params
      })
    },
    //转发
    handelForward(params) {
      this.$router.push({
        name: 'dispatchForward',
        params
      })
    },
    //获取详细信息
    async getMainData() {
      let resp = await this.$http.get('/carp/business/a/q/task/pass/' + this.paramsData.id)
      if (resp.code == 0) {
        this.mainData = resp.data
      } else {
        this.$dialog.alert({
          message: '获取信息失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //获取经过
    async getProcess() {
      let resp = await this.$http.get('/carp/business/a/q/task/process/' + this.paramsData.id)
      if (resp.code == 0) {
        this.processList = resp.data.taskVOList
      } else {
        this.$dialog.alert({
          message: '获取督办经过失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.dispatchDetail {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  .title {
    font-weight: 800;
    color: #333;
    margin-bottom: 10px;
  }
  .title2 {
    font-weight: 800;
    color: #333;
    margin: 10px;
  }
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .top {
    background-color: #fff;
    padding: 10px;
    .project {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      .projectName {
        color: #333;
        font-weight: 800;
        font-size: 18px;
      }
      .carCreat {
        flex-shrink: 0;
      }
    }
    .address {
      color: #949494;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      font-size: 14px;
      line-height: 23px;
      margin-top: 10px;
    }
  }
  .item {
    margin-top: 10px;
    background-color: #fff;
    padding: 10px;
    .imgList {
      display: flex;
      flex-wrap: wrap;
    }
    .msg {
      color: #949494;
      font-size: 14px;
      line-height: 23px;
      text-indent: 40px;
    }
  }
  .btns {
    display: flex;
    margin-top: 30px;
    .mybtn {
      flex-grow: 1;
      font-weight: 800;
    }
    .mybtn2 {
      flex-grow: 1;
      color: #3e89f1 !important;
      font-weight: 800;
    }
  }
  .pass {
    padding: 10px 20px;
    background-color: #fff;
    .passMsg {
      color: #949494;
      font-size: 14px;
      line-height: 23px;
      margin-top: 5px;
    }
  }
}
</style>
