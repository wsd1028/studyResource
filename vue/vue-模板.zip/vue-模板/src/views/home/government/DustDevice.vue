<template>
  <div class="government-dustDevice">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="扬尘告警">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="all">
      <van-pull-refresh @refresh="getDustList(1)" v-model="refreshloading">
        <van-list :finished="dustFinish" @load="getDustList" finished-text="没有更多了" v-model="dustLoading">
          <div :key="index" class="deviceItem" v-for="(item, index) in list">
            <div class="left">
              <p class="titleOne" v-text="paramsData.projectName"></p>
              <p class="titleThree">项目地址:{{ paramsData.address }}</p>
              <p class="titleThree">设备号:{{ item.sn }}</p>
            </div>
            <div @click="handelDevice(item)" class="rightIcon">
              <van-icon color="#d2d2d2" name="arrow" size="30" />
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [],
      refreshloading: false,
      finished: false,
      dustLoading: false,
      dustFinish: false,
      paramsData: {},
      searchData: {
        limit: 10,
        page: 1,
        projectId: ''
      }
    }
  },
  mounted() {
    if (JSON.stringify(this.$route.params) == '{}') {
      this.paramsData = this.$store.state.user.paramsData
    } else {
      this.paramsData = this.$route.params
      this.$store.commit('setParamsData', this.paramsData)
    }
    this.searchData.projectId = this.paramsData.projectId
  },
  components: {},
  methods: {
    //点击设备
    handelDevice(data) {
      this.$router.push({
        name: 'government-deviceDustWarn',
        params: data
      })
    },
    //查询数据
    async getDustList(page) {
      if (page) {
        this.searchData.page = 1
      }
      let resp = await this.$http('/carp/device/a/q/dust/info/projectId/' + this.searchData.projectId)
      if (resp.code == 0) {
        if (page) {
          this.list = []
        }
        this.list = resp.data
        // 加载状态结束
        this.dustLoading = false
        this.refreshloading = false
        this.dustFinish = true
      } else {
        this.$dialog.alert({
          message: '获取项目设备失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less">
.government-dustDevice {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 40px;
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .all {
    padding: 10px;
    .deviceItem {
      background-color: #fff;
      padding: 5px 10px;
      margin-bottom: 10px;
      justify-content: space-between;
      align-items: center;
      display: flex;
      .rightIcon {
        text-align: center;
        height: 100%;
        width: 50px;
      }
    }
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 5px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        i {
          display: inline-block;
          margin-right: 5px;
        }
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          span {
            padding: 0 10px;
            border-radius: 14px;
            color: #fff;
            line-height: 28px;
            text-align: center;
          }
          .carCreat0 {
            background-color: #4186f4;
          }
          .carCreat1 {
            background-color: #ccc;
          }
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
          margin-top: 10px;
        }
      }
    }
  }
}
</style>
