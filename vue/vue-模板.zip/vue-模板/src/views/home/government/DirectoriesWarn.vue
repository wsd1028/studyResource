<template>
  <div class="government-directoriesWarn">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="非名录车告警">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <!-- <van-tabs @change="select(1)" color="#4683f1" swipeable v-model="searchData.areaId">
      <van-tab :key="index" :name="item.id" :title="item.name" v-for="(item, index) in areaList"></van-tab>
    </van-tabs>-->
    <div class="all">
      <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
        <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
          <div :key="index" @click="handelItem(item)" class="item" v-for="(item, index) in list">
            <div class="top">
              <div>
                <span class="projectName" v-text="item.name"></span>
              </div>
              <p class="warn">
                <van-icon class-prefix="iconfont" name="note" size="18" />报警：
                <span v-text="item.num"></span>
                次
              </p>
            </div>
            <div class="bottom">
              <van-row>
                <van-col class="left" span="24">
                  <p>
                    负责人:
                    <span v-text="item.manager"></span>
                  </p>
                  <p>
                    项目地址:
                    <span v-text="item.address"></span>
                  </p>
                </van-col>
              </van-row>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [],
      areaList: [],
      loading: false,
      refreshloading: false,
      finished: false,
      searchData: {
        limit: 10,
        page: 1,
        areaId: ''
      }
    }
  },
  async created() {
    if (this.$store.state.user.user.accountTypeDto.code == '5115') {
      this.searchData.areaId = '511500000000'
    }
  },
  components: {},
  methods: {
    async getArea() {
      let resp = await this.$http.get('/carp/business/a/q/area/leading?limit=9999&page=1&fullName=宜宾市&level=3')
      if (resp.code == 0) {
        this.areaList = resp.data.records
        for (let i = 0; i < this.areaList.length; i++) {
          if (this.areaList[i].code == this.$store.state.user.user.accountTypeDto.code) {
            this.searchData.areaId = this.areaList[i].id
          }
        }
      } else {
        this.$dialog.alert({
          message: '获取区域失败',
          confirmButtonColor: 'red'
        })
      }
    },
    //点击查看详情
    handelItem(params) {
      this.$router.push({
        name: 'government-directoriesWarnDetail',
        params
      })
    },
    //查询数据
    async select(page) {
      if (!this.searchData.areaId) await this.getArea()
      if (page) {
        this.searchData.page = 1
      }
      let resp = await this.$http.get(
        `/carp/business/a/q/warning/list/select/area?areaId=${this.searchData.areaId}&limit=${this.searchData.limit}&page=${
          this.searchData.page
        }&r=${Math.random()}`
      )
      if (resp.code == 0) {
        if (page) {
          this.list = []
        }
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.refreshloading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取车辆识别失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less">
.government-directoriesWarn {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 40px;
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .van-info {
    top: 12px;
    right: -11px;
  }
  .all {
    padding: 0 10px;
    background-color: #f9f9f9;
    .item {
      background-color: #fff;
      margin-top: 10px;
      padding: 10px;
      border-radius: 4px;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .projectName {
          color: #333;
          font-weight: bold;
          font-size: 18px;
        }
        .warn {
          color: #d7484a;
          font-weight: 700;
          flex-shrink: 0;
        }
      }
      .bottom {
        .left {
          color: #949494;
          p {
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
            font-size: 14px;
            line-height: 23px;
            margin-top: 5px;
          }
        }
      }
    }
  }
}
</style>
