<template>
  <div class="company-dispatchDetail">
    <header>
      <van-nav-bar @click-left="goBack" class="nav" title="督办派单详情">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="top">
      <div class="project">
        <span class="projectName textFlow">派单号:{{ mainData.id }}</span>
        <p class="carCreat">
          <span class="state-span waitState" v-if="mainData.state == $dictionaries.dispatch.wait">待处理</span>
          <span class="state-span waitState" v-if="mainData.state == $dictionaries.dispatch.waitCheck">待审核</span>
          <span class="state-span delState" v-if="mainData.state == $dictionaries.dispatch.reject">已驳回</span>
          <span class="state-span finishState" v-if="mainData.state == $dictionaries.dispatch.finish">已结案</span>
          <span class="state-span cancelState" v-if="mainData.state == $dictionaries.dispatch.cancel">已作废</span>
        </p>
      </div>
      <p class="address">
        地址:
        <span v-text="mainData.projectAddress"></span>
      </p>
    </div>
    <section>
      <van-tabs color="#4683f1" swipeable>
        <van-tab title="督办详情">
          <div class="item">
            <van-field disabled label="创建时间" v-model="mainData.createDate" />
            <van-field disabled label="市区县" v-model="mainData.areaName" />
            <van-field disabled label="部门" v-model="mainData.dept" />
            <van-field disabled label="处理人" v-model="mainData.processor" />
            <van-field disabled label="电话" v-model="mainData.phone" />
          </div>
          <div class="item">
            <div>
              <p class="title">图片</p>
              <div class="imgList">
                <MyImage
                  :imgUrl="$dictionaries.imgBaseUrl + item"
                  :key="index"
                  height="80"
                  style="margin:5px;flexShrink:0"
                  v-for="(item, index) in mainData.startImageList"
                  width="80"
                />
              </div>
            </div>
            <div style="marginTop:20px">
              <p class="title">描述</p>
              <p class="msg" v-text="mainData.startDescription"></p>
            </div>
          </div>
          <!-- 处理完成才有 -->
          <p class="title2" v-if="mainData.state != $dictionaries.dispatch.wait">督办处理结果</p>
          <div class="item" v-if="mainData.state != $dictionaries.dispatch.wait">
            <div>
              <p class="title">图片</p>
              <div class="imgList">
                <MyImage
                  :imgUrl="$dictionaries.imgBaseUrl + item"
                  :key="index"
                  height="80"
                  style="margin:5px;flexShrink:0"
                  v-for="(item, index) in mainData.resultImageList"
                  width="80"
                />
              </div>
            </div>
            <div style="marginTop:20px">
              <p class="title">描述</p>
              <p class="msg" v-text="mainData.resDescription"></p>
            </div>
          </div>
        </van-tab>
        <van-tab title="督办经过">
          <div class="pass">
            <van-steps :active="processList.length - 1" direction="vertical">
              <van-step :key="index" v-for="(item, index) in processList">
                <h3>
                  <span v-text="item.sort"></span>.
                  <span v-text="stateObj[item.nowState]"></span>
                </h3>
                <p class="passMsg">
                  创建时间:
                  <span v-text="item.createDate"></span>
                </p>
                <p class="passMsg">
                  市区县:
                  <span v-text="item.areaName"></span>
                </p>
                <p class="passMsg">
                  部门:
                  <span v-text="item.dept"></span>
                </p>
                <p class="passMsg">
                  处理人:
                  <span v-text="item.procesor"></span>
                </p>
                <p class="passMsg">
                  电话:
                  <span v-text="item.phone"></span>
                </p>
              </van-step>
            </van-steps>
          </div>
        </van-tab>
      </van-tabs>
      <div class="btns" v-if="mainData.state == $dictionaries.dispatch.wait || mainData.state == $dictionaries.dispatch.reject">
        <van-button @click="handelFix(mainData)" block class="mybtn" type="info">立即处理</van-button>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mainData: {},
      text: 'wsd',
      paramsData: {},
      processList: [],
      stateObj: {
        '5020': '已派单',
        '5050': '待审核',
        '5060': '已驳回',
        '5070': '已结案',
        '5080': '已作废'
      }
    }
  },
  mounted() {
    //获取路由参数
    if (JSON.stringify(this.$route.params) == '{}') {
      this.paramsData = this.$store.state.user.paramsData
    } else {
      this.paramsData = this.$route.params
      this.$store.commit('setParamsData', this.paramsData)
    }
    this.getMainData()
    this.getProcess()
    this.handelRead()
  },
  components: {},
  methods: {
    //已读
    async handelRead() {
      let res = await this.$http.post('/carp/business/a/q/task/readHistory', {
        taskId: this.paramsData.id,
        accountId: this.$store.state.user.user.id
      })
    },
    //返回督办派单
    goBack() {
      this.$router.go(-1)
    },
    //立即处理
    handelFix(params) {
      this.$router.push({
        name: 'company-dispatchFix',
        params
      })
    },
    //获取信息
    async getMainData() {
      let resp = await this.$http.get('/carp/business/a/q/task/pass/' + this.paramsData.id)
      if (resp.code == 0) {
        this.mainData = resp.data
      } else {
        this.$dialog.alert({
          message: '获取信息失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //获取经过
    async getProcess() {
      let resp = await this.$http.get('/carp/business/a/q/task/process/' + this.paramsData.id)
      if (resp.code == 0) {
        this.processList = resp.data.taskVOList
      } else {
        this.$dialog.alert({
          message: '获取督办经过失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    }
  }
}
</script>

<style lang="less" scoped>
.company-dispatchDetail {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  .title {
    font-weight: 800;
    color: #333;
    margin-bottom: 10px;
  }
  .title2 {
    font-weight: 800;
    color: #333;
    margin: 10px;
  }
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .top {
    background-color: #fff;
    padding: 10px;
    .project {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      .projectName {
        color: #333;
        font-weight: 800;
        font-size: 18px;
      }
      .carCreat {
        flex-shrink: 0;
      }
    }
    .address {
      color: #949494;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      font-size: 14px;
      line-height: 23px;
      margin-top: 10px;
    }
  }
  .item {
    margin-top: 10px;
    background-color: #fff;
    padding: 10px;
    .imgList {
      display: flex;
      flex-wrap: wrap;
    }
    .msg {
      color: #949494;
      font-size: 14px;
      line-height: 23px;
      text-indent: 40px;
    }
  }
  .btns {
    display: flex;
    margin-top: 30px;
    .mybtn {
      flex-grow: 1;
      font-weight: 800;
    }
    .mybtn2 {
      flex-grow: 1;
      color: #3e89f1 !important;
      font-weight: 800;
    }
  }
  .tips {
    .tipsMsg {
      color: #000;
      margin-left: 10px;
      vertical-align: top;
    }
    .tipsbtns {
      display: flex;
      justify-content: space-between;
      width: 100%;
      margin-top: 20px;
      .myBtn,
      .myBtn2 {
        width: 100px;
        font-size: 20px;
      }
      .myBtn2 {
        .van-button__text {
          color: #000;
        }
      }
    }
  }
  .pass {
    padding: 10px 20px;
    background-color: #fff;
    .passMsg {
      color: #949494;
      font-size: 14px;
      line-height: 23px;
      margin-top: 5px;
    }
  }
}
</style>
