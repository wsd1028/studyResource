<template>
  <div class="company-home">
    <div class="head">
      <HomeTitle titleName="扬尘治理"></HomeTitle>
      <div>
        <div class="cell-box">
          <div class="top">
            <div class="msgItem">
              <span>
                <van-image :src="require('@/assets/image/index_icon3.png')" height="18" width="18" />
              </span>
              <span @click="goSkip('company-projectDetail')" class="text" style="fontWeight:800;color:#333" v-text="project.name"></span>
            </div>
            <div class="msgItem dfsb">
              <van-icon class="myIcon" color="#6c6c6c" name="location" size="18" />
              <p class="textFlowP">
                <span class="text textFlow" v-text="project.address"></span>
              </p>
            </div>
            <div style="display:flex;width:100%;marginTop:30px">
              <div class="chartItems" style="marginRight:10px">
                <span style="color:#fc7403">AQI:{{ polluteData.AQI }}</span>
              </div>
              <div class="chartItems" style="marginLeft:10px">
                <span style="color:#f42037">PM10:{{ polluteData.pm10 }}μg/m3</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style="height:60px"></div>
      <van-notice-bar :text="noticeText" @replay="exposureReplay" color="#538dc3" speed="50">
        <template #right-icon>
          <div @click="goSkip('company-exposure')" class="exposureIcon">
            <span class="text">更多</span>
            <van-icon name="arrow" />
          </div>
        </template>
        <template #left-icon>
          <div>
            <span class="exposureText">曝光台</span>
          </div>
        </template>
      </van-notice-bar>
    </div>
    <div class="box">
      <div style="textAlign:left;lineHeight:40px">
        <span class="title2">今日待办</span>
        <van-divider></van-divider>
      </div>
      <div class="allIconBox">
        <div @click="goSkip('company-todayWarn', { active: 'dust' })" class="tac">
          <div class="iconBox" style="color:#ee4634" v-text="dustWarnNum"></div>
          <span class="text">扬尘告警</span>
        </div>
        <div @click="goSkip('company-todayWarn', { active: 'directories' })" class="tac">
          <div class="iconBox" style="color:#ee4634" v-text="todayWait.carNumber"></div>
          <span class="text">非名录车告警</span>
        </div>
        <div @click="goSkip('company-todayCheck')" class="tac">
          <div class="iconBox" style="color:#333" v-text="todayWait.todayCheckNumber"></div>
          <span class="text">每日巡检</span>
        </div>
        <div @click="goSkip('company-appointCheck')" class="tac">
          <div class="iconBox" v-text="todayWait.assignCheckNumber"></div>
          <span class="text">指派点检</span>
        </div>
        <div @click="goSkip('company-problemReport')" class="tac">
          <div class="iconBox" v-text="todayWait.questionReportNumber"></div>
          <span class="text">问题上报</span>
        </div>
        <div @click="goSkip('company-dispatch')" class="tac">
          <div class="iconBox" v-text="todayWait.taskNumber"></div>
          <span class="text">督办派单</span>
        </div>
        <div class="tac"></div>
      </div>
    </div>
    <div class="box" style="paddingTop:0">
      <van-cell is-link style="textAlign:left" to="/main/licensePlate" value="更多">
        <template #title>
          <span class="title2">车辆识别</span>
        </template>
      </van-cell>
      <van-divider></van-divider>
      <div class="activeBtn">
        <span :class="activeBtn === 3 ? 'active' : ''" @click="handelActive(3)">全部</span>
        <span :class="activeBtn === 1 ? 'active' : ''" @click="handelActive(1)">已占用</span>
        <span :class="activeBtn === 2 ? 'active' : ''" @click="handelActive(2)">未占用</span>
      </div>
    </div>
    <div class="box lincenseBox">
      <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
        <van-swipe-cell :key="index" v-for="(item, index) in list">
          <van-row class="item">
            <van-col span="6" style="height:85px;position:relative">
              <div class="jin" v-if="item.direction == $dictionaries.direction.jin">进</div>
              <div class="chu" v-if="item.direction == $dictionaries.direction.chu">出</div>
              <MyImage :imgUrl="$dictionaries.imgBaseUrl + item.carPhoto" :isPreviewShow="true" height="100%" style="width:100%;height:100%" width="100%" />
            </van-col>
            <van-col span="1"></van-col>
            <van-col span="17">
              <div class="top">
                <p>
                  <span class="textFlow" style="width:80px;vertical-align: middle;" v-text="item.license"></span>
                  <span class="carTag0" v-if="item.carState">名录车</span>
                  <span class="carTag1" v-if="!item.carState">非名录车</span>
                </p>
                <p class="carCreat">
                  <span @click="handelCreate(item)" class="carCreat0" v-if="!item.occupancy && item.direction == $dictionaries.direction.chu">新建</span>
                  <span class="carCreat1" v-if="item.occupancy && item.direction == $dictionaries.direction.chu">已建</span>
                </p>
              </div>
              <div class="bottom">
                <p>运输企业:{{ item.transportCompanyName }}</p>
                <p>排放企业:{{ item.projectCompanyName }}</p>
                <p>创建时间:{{ item.createDate }}</p>
              </div>
            </van-col>
          </van-row>
        </van-swipe-cell>
      </van-list>
    </div>
  </div>
</template>

<script>
import HomeTitle from '@/components/HomeTitle.vue'
import { Bus } from '@/bus'
export default {
  data() {
    return {
      exposureList: [], //曝光台列表
      exposureIndex: 0, //曝光台下标
      noticeText: '', //当前曝光台文字
      project: {
        //项目详细
        name: '',
        address: ''
      },
      userMsg: {},
      dustWarnNum: 0,
      todayWait: {
        carNumber: 0,
        todayCheckNumber: 0,
        questionReportNumber: 0,
        assignCheckNumber: 0,
        taskNumber: 0
      },
      activeBtn: 3, //车辆识别当前tab
      list: [], //车辆识别列表
      loading: false, //加载
      finished: false, //完成
      searchData: {
        //车辆识别查询条件
        license: '',
        limit: 10,
        page: 1,
        workplaceId: '',
        workplaceType: this.$dictionaries.machineType.company,
        occupancy: ''
      },
      polluteData: {
        AQI: 0,
        pm10: 0,
        pm25: 0
      }
    }
  },
  mounted() {
    this.searchData.workplaceId = this.$store.state.user.user.accountTypeDto.ancillaryId
    if (this.$store.state.user.user.accountTypeDto.type == this.$dictionaries.userType.garbage) {
      this.searchData.workplaceType = this.$dictionaries.machineType.garbage
    }
    this.userMsg = this.$store.state.user.user
    this.getProject()
    this.getExposure()
    this.getTodayWait()
    this.getDustNum()
    Bus.$on('searchValue', value => {
      this.searchData.license = value
      this.list = []
      this.searchData.page = 1
      this.select()
    })
  },
  components: {
    HomeTitle
  },
  methods: {
    async getPollute(longitude, latitude) {
      let resp = await this.$http.get(`/carp/device/a/q/dust/info/recent/monitor/data?longitude=${longitude}&latitude=${latitude}`)
      if (resp.code == 0) {
        this.polluteData = resp.data
      } else {
        this.$dialog.alert({
          message: '获取AQI/PM10失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //获取扬尘告警数量
    async getDustNum() {
      var fd = new FormData()
      fd.append('beginTimeEnd', this.$moment().format('YYYY-MM-DD HH:mm:ss'))
      fd.append(
        'beginTimeStart',
        this.$moment()
          .startOf('day')
          .format('YYYY-MM-DD HH:mm:ss')
      )
      fd.append('projectIdList', [this.searchData.workplaceId])
      let resp = await this.$http.post('/carp/device/k/q/dust/alarm/total', fd)
      if (resp.code == 0) {
        this.dustWarnNum = resp.data
      } else {
        this.$dialog.alert({
          message: '获取扬尘告警数量:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //得到今日待办
    async getTodayWait() {
      let resp = await this.$http.get(`/carp/business/a/q/data/num/statistics`, {
        params: {
          projectId: this.searchData.workplaceId, //项目id
          receiverId: this.userMsg.id, //收单人id
          carState: 0, //非名录车状态
          todayState: this.$dictionaries.todayCheck.update, //今日巡检状态
          questionState: this.$dictionaries.problem.report, //问题上报状态
          assignState: this.$dictionaries.appointCheck.update, //指派点检状态
          taskState: this.$dictionaries.dispatch.wait //督办派单状态
        }
      })
      if (resp.code == 0) {
        this.todayWait = resp.data
      } else {
        this.$dialog.alert({
          message: '获取今日待办:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //曝光台重新滚动
    exposureReplay() {
      this.exposureIndex++
      if (this.exposureIndex > this.exposureList.length - 1) this.exposureIndex = 0
      this.noticeText = this.exposureList[this.exposureIndex].title
    },
    //得到曝光台信息
    async getExposure() {
      let resp = await this.$http.get('/carp/business/a/q/exposure/table/page?Page=1&Limit=9999')
      if (resp.code == 0) {
        this.exposureList = resp.data.records
        if (this.exposureList.length > 0) this.noticeText = this.exposureList[0].title
      }
    },
    //跳转路由
    goSkip(name, params) {
      this.$router.push({
        name,
        params
      })
    },
    //跳转联单点检界面
    handelCreate(item) {
      this.$router.push({
        name: 'formDetail',
        params: {
          createDate: item.createDate,
          id: item.id,
          projectId: this.searchData.workplaceId
        }
      })
    },
    //查询数据
    async select() {
      if (this.searchData.page == 1) {
        this.list = []
      }
      let resp = await this.$http.get('/carp/business/a/q/license/record/current/page', {
        params: this.searchData
      })
      if (resp.code == 0) {
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取车辆识别失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //点击按钮
    handelActive(val) {
      if (this.activeBtn !== val) {
        this.activeBtn = val
        if (this.activeBtn == 3) {
          this.searchData.occupancy = ''
        }
        if (this.activeBtn == 1) {
          this.searchData.occupancy = 1
        }
        if (this.activeBtn == 2) {
          this.searchData.occupancy = 0
        }
        this.searchData.page = 1
        this.select()
      }
    },
    //得到项目详情
    getProject() {
      if (this.userMsg.accountTypeDto.type == this.$dictionaries.userType.project) {
        this.$http.get('/carp/business/k/s/project/' + this.searchData.workplaceId).then(resp => {
          if (resp.code == 0) {
            this.project = resp.data
            this.getPollute(parseFloat(resp.data.longitude), parseFloat(resp.data.latitude))
          } else {
            this.$dialog.alert({
              message: '获取项目信息失败:' + resp.message,
              confirmButtonColor: 'red'
            })
          }
        })
      }
      if (this.userMsg.accountTypeDto.type == this.$dictionaries.userType.garbage) {
        this.$http.get('/carp/business/a/q/garbage/station/' + this.userMsg.accountTypeDto.ancillaryId).then(resp => {
          if (resp.code == 0) {
            this.project = resp.data
            this.getPollute(parseFloat(resp.data.longitude), parseFloat(resp.data.latitude))
          } else {
            this.$dialog.alert({
              message: '获取消纳站信息:' + resp.message,
              confirmButtonColor: 'red'
            })
          }
        })
      }
    }
  }
}
</script>
<style lang="less" scoped>
.company-home {
  padding-bottom: 50px;
  background-color: #f9f9f9;
  min-height: 100%;
  .van-divider {
    margin: 0;
  }
  .head {
    height: 200px;
    margin-bottom: 100px;
  }
  .van-notice-bar {
    background-color: #fff;
  }
  .main {
    background: #f9f9f9;
  }
  .exposureIcon {
    padding-left: 10px;
  }
  .exposureText {
    font-style: italic;
    color: #3d87f0;
    font-weight: 800;
    padding-right: 10px;
    font-size: 18px;
  }
  .project-name {
    font-weight: 800;
  }
  .cell-box {
    padding: 20px;
    padding-bottom: 0;
    background-color: #4284f3;
    position: relative;
    height: 140px;
    .top {
      border-radius: 8px;
      background-color: #fff;
      padding: 20px;
      padding-top: 4px;
      position: absolute;
      width: 93%;
      margin: auto;
      top: 30px;
      left: 0;
      bottom: -50px;
      right: 0;
      box-shadow: 0 0 7px #e5e5e5;
      .msgItem {
        font-size: 18px;
        color: #656565;
        display: flex;
        margin-top: 16px;
        align-items: flex-start;
        text-align: left;
        .text {
          margin-left: 10px;
        }
      }

      .myIcon {
        font-weight: 800;
      }
    }
  }
  .chartItems {
    width: 50%;
    color: #5c5c5c;
    font-size: 16px;
    text-align: left;
  }
  .box {
    padding: 20px;
    margin-bottom: 20px;
    background-color: #fff;
    .van-cell {
      padding: 10px 0;
    }
    .title2 {
      font-weight: 800;
      color: #333;
      font-size: 16px;
    }
    .allIconBox {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      .tac {
        width: 33%;
        flex-shrink: 0;
        margin-top: 20px;
        .iconBox {
          font-size: 24px;
          color: #3a84f2;
        }
      }
      .text {
        color: #999;
        font-size: 16px;
        margin-top: 10px;
        display: inline-block;
        width: 100%;
      }
    }
    .dateBox {
      display: flex;
      justify-content: center;
      align-items: center;
      #chartPie,
      #chartPie1 {
        width: 80px;
        height: 80px;
        flex-shrink: 0;
        div {
          width: 100%;
        }
      }
      .item {
        flex-shrink: 0;
        .date {
          width: 100%;
          color: #999;
          font-weight: 800;
        }
        .text,
        sup {
          color: #9a9a9a;
        }
      }
    }
  }
  .activeBtn {
    text-align: left;
    margin-top: 20px;
    span {
      padding: 0 20px;
      border-radius: 14px;
      color: #999;
      line-height: 28px;
      text-align: center;
    }
    .active {
      background-color: #4186f4;
      color: #fff;
    }
  }
  .lincenseBox {
    background-color: #f9f9f9;
    padding: 0;
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 10px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 4px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 4px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          span {
            padding: 0 10px;
            border-radius: 14px;
            color: #fff;
            line-height: 28px;
            text-align: center;
          }
          .carCreat0 {
            background-color: #4186f4;
          }
          .carCreat1 {
            background-color: #ccc;
          }
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
        }
      }
    }
  }
}
</style>
