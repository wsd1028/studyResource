<template>
  <div class="company-PM10Warn">
    <header>
      <van-nav-bar @click-left="$router.go(-1)" class="nav" title="扬尘告警">
        <template #left>
          <van-icon class-prefix="iconfont" color="#333" name="fanhui" size="22" />
        </template>
      </van-nav-bar>
    </header>
    <div class="all">
      <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
        <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
          <div class="dustItem">
            <div class="top">
              <van-image :src="require('@/assets/image/index_icon8.png')" height="20" style="margin-right:5px" width="20" />
              <span>PM10浓度：</span>
              <span style="color:#ff0c15">95.31</span>
              <span>ug/m³</span>
            </div>
            <p style="margin:10px 0">PM10国控值:24ug/m³</p>
            <p>告警时间:2020-04-25 10:25:36</p>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [],
      loading: false,
      refreshloading: false,
      finished: false,
      searchData: {
        limit: 10,
        page: 1,
        projectId: ''
      }
    }
  },
  mounted() {
    this.active = this.$route.params.active
    this.searchData.projectId = this.$store.state.user.project.id
  },
  components: {},
  methods: {
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
        this.list = []
      }
    }
  }
}
</script>

<style lang="less">
.company-PM10Warn {
  text-align: left;
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 40px;
  header {
    background-color: #fff;
    .nav {
      text-align: left;
      line-height: 42px;
      i {
        color: #666;
      }
      .van-nav-bar__title {
        font-weight: 800;
        font-size: 18px !important;
      }
    }
  }
  .all {
    padding: 10px;
    .dustItem {
      background-color: #fff;
      padding: 5px 10px;
      border-radius: 4px;
      .top {
        line-height: 24px;
        display: flex;
        align-items: center;
        i {
          display: inline-block;
          margin-right: 5px;
          vertical-align: middle;
        }
        span {
          color: #333;
          font-weight: bold;
        }
      }
      p {
        color: #9c9c9c;
      }
    }
    .item {
      background-color: #fff;
      margin-bottom: 10px;
      padding: 5px;
      text-align: left;
      .top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        i {
          display: inline-block;
          margin-right: 5px;
        }
        .carTag0 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          border: 1px solid #00ce5e;
          color: #00ce5e;
          margin-left: 5px;
        }
        .carTag1 {
          border-radius: 4px;
          line-height: 24px;
          padding: 0 10px;
          margin-left: 5px;
          border: 1px solid #ff2c37;
          color: #ff2c37;
        }
        .carCreat {
          span {
            padding: 0 10px;
            border-radius: 14px;
            color: #fff;
            line-height: 28px;
            text-align: center;
          }
          .carCreat0 {
            background-color: #4186f4;
          }
          .carCreat1 {
            background-color: #ccc;
          }
        }
      }
      .bottom {
        color: #949494;
        p {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          font-size: 12px;
          line-height: 20px;
          margin-top: 10px;
        }
      }
    }
  }
}
</style>
