<template>
  <div class="Mine">
    <van-dialog :showConfirmButton="false" class="QRcode" closeOnClickOverlay v-model="showQRcode">
      <div class="top">
        <p>扫码下载惠工云App</p>
        <img alt src="../../assets/image/yibin_logo.png" />
      </div>
      <van-divider />
      <div class="bottom">
        <div class="iconBox">
          <van-icon class-prefix="iconfont" class="myIcon" name="weixin" />
          <p class="iconText">分享到微信</p>
        </div>
        <div class="iconBox">
          <van-icon class-prefix="iconfont" class="myIcon" name="pengyouquan" />
          <p class="iconText">分享到朋友圈</p>
        </div>
      </div>
    </van-dialog>

    <van-dialog :showConfirmButton="false" class="service" closeOnClickOverlay v-model="showService" width="80%">
      <div class="top">
        <img alt src="../../assets/image/yibin_service.jpg" />
        <div class="tel">
          <p class="text">客服热线</p>
          <p>400-1288-586</p>
        </div>
        <div class="bottom">
          <p style="color:#888">我们将会全心全意为您提供满意周到的咨询服务,也希望您能支持和监督我们的服务</p>
          <van-button block icon="phone" style="borderRadius:4px;margin:20px 0" type="info">立即呼叫</van-button>
          <p style="color:#888;textAlign:center">
            <span @click="showService = false">取消</span>
          </p>
        </div>
      </div>
    </van-dialog>

    <header>
      <h2 class="title">我的</h2>
      <van-icon @click="showQRcode = !showQRcode" class-prefix="iconfont" color="#373737" name="ico" size="26" style="fontWeight:600" />
    </header>
    <van-cell is-link style="padding:40px 20px" to="/mine/mineMsg">
      <template #title>
        <div>
          <p style="fontSize:14px;marginBottom:20px">
            <span class="title" v-text="user.name"></span>
            <span style="marginLeft:10px;fontWeight:800" v-text="user.work"></span>
          </p>
          <span v-if="isCompany" v-text="user.project"></span>
          <span v-else v-text="user.organizationDto"></span>
        </div>
      </template>
    </van-cell>
    <div class="bottom">
      <van-cell @click="showService = !showService" class="item" is-link>
        <template #title>
          <div>
            <van-icon class-prefix="iconfont" class="red myIcon" name="kefu" />
            <span class="text">我的客服</span>
          </div>
        </template>
      </van-cell>
      <van-divider />
      <van-cell class="item" is-link to="/mine/password">
        <template #title>
          <div>
            <van-icon class-prefix="iconfont" class="orange myIcon" name="mima" />
            <span class="text">修改密码</span>
          </div>
        </template>
      </van-cell>
      <van-divider />
      <van-cell class="item" is-link to="/mine/feedback">
        <template #title>
          <div>
            <van-icon class-prefix="iconfont" class="yellow myIcon" name="xinxi" />
            <span class="text">用户反馈</span>
          </div>
        </template>
      </van-cell>
      <van-divider />
      <van-cell class="item" is-link to="/mine/aboutUs">
        <template #title>
          <div>
            <van-icon class-prefix="iconfont" class="green myIcon" name="wode-guanyuwomen" />
            <span class="text">关于我们</span>
          </div>
        </template>
      </van-cell>
      <van-divider />
    </div>
    <div class="bottom">
      <van-cell class="item" is-link to="/mine/setting">
        <template #title>
          <div>
            <van-icon class-prefix="iconfont" class="blue myIcon" name="shezhi" />
            <span class="text">设置</span>
          </div>
        </template>
      </van-cell>
      <van-cell class="item" is-link to="/demo">
        <template #title>
          <div>
            <van-icon class-prefix="iconfont" class="blue myIcon" name="shezhi" />
            <span class="text">demo</span>
          </div>
        </template>
      </van-cell>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      //二维码弹窗
      showQRcode: false,
      //客服弹窗
      showService: false,
      user: {
        name: '',
        work: '',
        project: '',
        organizationDto: ''
      },
      isCompany: false
    }
  },
  async mounted() {
    if (this.$store.state.user.user.accountTypeDto.type == 30 || this.$store.state.user.user.accountTypeDto.type == 60) {
      this.isCompany = true
    }
    this.user.name = this.$store.state.user.user.username
    this.user.project = this.$store.state.user.project.name
    try {
      this.user.organizationDto = this.$store.state.user.user.organizationDto.name
    } catch {}
    try {
      this.user.work = this.$store.state.user.user.jobTitleDtoList[0].name
    } catch {}
  },
  components: {},
  methods: {}
}
</script>

<style lang="less" scoped>
.Mine {
  text-align: left;
  background-color: #f9f9f9;
  height: auto;
  .van-dialog {
    width: auto;
  }
  .QRcode {
    .top {
      padding: 60px;
      padding-bottom: 0px;
      text-align: center;
      p {
        margin-bottom: 20px;
        color: #323232;
      }
      img {
        display: inline-block;
        width: 150px;
        height: 150px;
      }
    }
    .bottom {
      padding: 20px;
      padding-top: 0px;
      display: flex;
      justify-content: space-between;
      margin-top: 0;
      .iconBox {
        text-align: center;
        .myIcon {
          border: 1px solid #c6c6c6;
          color: #c6c6c6;
          display: inline-block;
          width: 50px;
          height: 50px;
          line-height: 50px;
          border-radius: 100%;
          font-size: 25px;
        }
        .iconText {
          color: #373737;
          margin-top: 10px;
        }
      }
    }
  }
  .service {
    .top {
      position: relative;
      img {
        width: 100%;
        height: 150px;
      }
      .tel {
        position: absolute;
        top: 50px;
        left: 30px;
        color: #fff;
        font-size: 20px;
        .text {
          font-weight: 800;
          margin-bottom: 20px;
        }
      }
    }
    .bottom {
      padding: 20px 30px;
      margin-top: 0;
    }
  }
  .blue {
    background-color: #349cfa;
  }
  .orange {
    background-color: #ff7201;
  }
  .green {
    background-color: #19c363;
  }
  .yellow {
    background-color: #fc9900;
  }
  .red {
    background-color: #fe0100;
  }
  .title {
    font-weight: 800;
    color: #333;
    font-size: 20px;
    padding: 0;
    margin: 0;
  }
  header {
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #fff;
    margin-bottom: 20px;
  }
  .bottom {
    margin-top: 20px;
    padding: 0 20px;
    background-color: #fff;
    .van-divider {
      margin: 0;
      border-color: #f4f4f4;
    }
    .van-cell {
      padding: 20px 0;
    }
    .item {
      .myIcon {
        color: #fff;
        font-size: 16px;
        width: 30px;
        height: 30px;
        border-radius: 100%;
        line-height: 30px;
        text-align: center;
        display: inline-block;
      }
      .text {
        display: inline-block;
        margin-left: 20px;
        font-size: 18px;
        color: #3d3d3d;
      }
    }
  }
}
</style>
