<template>
  <div class="licensePlate">
    <div class="head">
      <Title titleName="车牌识别"></Title>
      <van-icon @click="goCreatForm" class="plusIcon" name="plus" />
    </div>
    <van-search @search="select(1)" input-align="center" placeholder="请输入搜索关键词" show-action v-model="searchData.license">
      <template #action>
        <div @click="select(1)">搜索</div>
      </template>
    </van-search>
    <van-pull-refresh @refresh="select(1)" v-model="refreshloading">
      <van-list :finished="finished" @load="select" finished-text="没有更多了" v-model="loading">
        <van-swipe-cell :key="index" v-for="(item, index) in list">
          <van-cell-group>
            <van-row class="lincense-box">
              <van-col span="17">
                <van-row>
                  <van-col class="l1" span="16" v-text="item.license"></van-col>
                  <van-col class="l2" span="8">
                    <van-tag :type="item.occupancy ? 'danger' : 'success'" mark size="medium">{{ item.occupancy | tagFilter }}</van-tag>
                  </van-col>
                </van-row>
                <van-row>
                  <van-col class="l3" span="21" v-text="item.createDate"></van-col>
                </van-row>
                <van-row v-if="item.direction == $dictionaries.direction.chu">
                  <van-col class="l4" offset="2" span="18">
                    <van-button @click="create(item)" block round size="mini" type="info" v-if="!item.occupancy">
                      <!-- 解决eslint -->
                      新建联单
                    </van-button>
                    <van-button @click="create(item)" block disabled round size="mini" type="info" v-if="item.occupancy">
                      <!-- 解决eslint -->
                      新建联单
                    </van-button>
                  </van-col>
                </van-row>
              </van-col>
              <van-col span="6" style="height:85px;position:relative">
                <div class="jin" v-if="item.direction == $dictionaries.direction.jin">进</div>
                <div class="chu" v-if="item.direction == $dictionaries.direction.chu">出</div>
                <MyImage :imgUrl="$dictionaries.imgBaseUrl + item.carPhoto" height="100%" style="width:100%;height:100%" width="100%" />
              </van-col>
            </van-row>
          </van-cell-group>
        </van-swipe-cell>
      </van-list>
    </van-pull-refresh>
  </div>
</template>

<script>
import Title from '@/components/Title'
import { Dialog } from 'vant'
export default {
  components: {
    Title
  },
  data() {
    return {
      list: [],
      loading: false,
      refreshloading: false,
      finished: false,
      searchData: {
        license: '',
        limit: 10,
        page: 1,
        workplaceId: '',
        workplaceType: this.$dictionaries.machineType.company
      }
    }
  },
  methods: {
    //查询数据
    async select(page) {
      if (page) {
        this.searchData.page = 1
        this.list = []
      }
      let resp = await this.$http.get('/carp/business/a/q/license/record/current/page', {
        params: this.searchData
      })
      if (resp.code == 0) {
        this.list = this.list.concat(resp.data.records)
        // 加载状态结束
        this.loading = false
        this.refreshloading = false
        this.searchData.page = this.searchData.page + 1
        if (this.list.length == resp.data.total) {
          // 数据全部加载完成
          this.finished = true
        }
      } else {
        this.$dialog.alert({
          message: '获取信息失败:' + resp.message,
          confirmButtonColor: 'red'
        })
      }
    },
    //跳转联单点检界面
    create(item) {
      this.$router.push({
        name: 'formDetail',
        params: {
          createDate: item.createDate,
          id: item.id,
          projectId: this.searchData.projectId
        }
      })
    },
    //跳转创建联单界面
    goCreatForm() {
      this.$router.push({
        name: 'createForm',
        params: {
          license: ''
        }
      })
    }
  },
  filters: {
    // 是否可用
    tagFilter(flag) {
      if (flag) {
        return '不可用'
      } else {
        return '可用'
      }
    }
  },
  mounted() {
    this.searchData.workplaceId = this.$store.state.user.user.accountTypeDto.ancillaryId
    if (this.$store.state.user.user.accountTypeDto.type == 60) {
      this.searchData.type = this.$dictionaries.machineType.garbage
    }
  }
}
</script>

<style lang="less" scoped>
.licensePlate {
  background-color: #f9f9f9;
  min-height: 100%;
  padding-bottom: 30px;
  .head {
    position: relative;
    .plusIcon {
      position: absolute;
      right: 20px;
      z-index: 999;
      top: 6px;
      font-size: 29px;
      color: #fff;
    }
  }
  .van-row {
    margin-top: 20px;
  }
  .lincense-box {
    background-color: #fff;
    padding: 10px 0;
    .van-col {
      height: 100%;
      padding-left: 5px;
    }
    text-align: left;
    .van-tag {
      text-align: center;
      text-indent: 0px;
    }
    .l1 {
      font-weight: 800;
    }
    .l3 {
      color: #9a9898;
    }
  }
}
</style>
