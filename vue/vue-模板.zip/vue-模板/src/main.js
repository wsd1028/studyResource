import Vue from 'vue'
import App from './App.vue'
import store from './store'
import router from './router'
import Vant from 'vant'
import 'vant/lib/index.css'
import axios from '@/axios'
import qs from 'qs'
import moment from 'moment'
import echarts from 'echarts'
import { Dialog } from 'vant'
import VueTouch from 'vue-touch'
import { until } from './assets/js/until'
import { dictionaries } from './assets/js/dictionaries'
import BaiduMap from 'vue-baidu-map'
import './assets/iconfont/iconfont.css'
import VideoPlayer from 'vue-video-player'
import 'video.js/dist/video-js.css'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import MyImage from '@/components/MyImage.vue'
import vueEsign from 'vue-esign'
Vue.use(vueEsign)
Vue.component('MyImage', MyImage)
Vue.use(VideoPlayer)
Vue.use(BaiduMap, {
  ak: dictionaries.ak
})
Vue.use(Vant)
Vue.use(ElementUI)

Vue.use(VueTouch, { name: 'v-touch' })

Dialog.setDefaultOptions({
  closeOnPopstate: true
})
Vue.prototype.$dialog = Dialog
Vue.prototype.$http = axios
Vue.prototype.$moment = moment
Vue.prototype.$echarts = echarts
Vue.prototype.$until = until
Vue.prototype.$dictionaries = dictionaries
Vue.prototype.$debounce = until.debounce
Vue.prototype.$qs = qs
Vue.config.productionTip = false

require('./mock/mock.js')

router.beforeEach((to, from, next) => {
  //根据路由处理底部tab的激活状态
  let activeTab = store.state.user.activeTab
  switch (to.name) {
    case 'company-home':
      activeTab = 0
      break
    case 'government-home':
      activeTab = 0
      break
    case 'company-work':
      activeTab = 1
      break
    case 'government-work':
      activeTab = 1
      break
    case 'mine':
      activeTab = 2
      break
  }
  store.commit('setActiveTab', activeTab)
  store.commit('fulshHomeUrl')
  //  防止刷新后vuex里丢失user
  if (JSON.stringify(store.state.user.user) == '{}') {
    store.commit('getUser')
  }
  //  防止刷新后vuex里丢失project
  if (JSON.stringify(store.state.user.project) == '{}') {
    store.commit('setCookProject')
  }
  //  防止刷新后vuex里丢失token
  let token = store.state.user.token
  if (!token) {
    store.commit('getToken')
    token = store.state.user.token
  }
  //  过滤登录页，防止死循环
  if (!token && to.name !== 'login') {
    next({ name: 'login' })
  } else {
    next()
  }
  // next()
})
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
