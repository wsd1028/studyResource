//分页
function getPageData(rule) {
  let data = rule.data //总数据
  let pageData = [] //分页返回数据
  let pageIndex = rule.pageIndex - 1
  let pageSize = rule.pageSize
  let count = 0
  for (let i = 0; i < data.length; i++) {
    if (data[i + pageIndex * pageSize]) {
      pageData.push(data[i + pageIndex * pageSize])
      count++
    } else {
      break
    }
    if (count > pageSize - 1) {
      break
    }
  }
  return pageData
}

//验证必填项
function checkUpdateData(data, ignore = []) {
  let bool = true
  for (let key in data) {
    if (ignore.indexOf(key) == -1) {
      if (Array.prototype.isPrototypeOf(data[key])) {
        if (data[key].length == 0) bool = false
      }
      if (typeof data[key] == 'string') {
        if (!data[key]) {
          bool = false
        }
      }
    }
  }
  return bool
}
//判断是不是图片
function checkImage(str) {
  let bool = str.split('-')[2] == 'image' ? true : false
  return bool
}

//防抖
function debounce(callback, wait) {
  var timeout = null
  return function() {
    if (timeout !== null) clearTimeout(timeout)
    timeout = setTimeout(callback, wait)
  }
}

// 将base64转换为file
function dataURLtoFile(dataurl, filename = 'file') {
  let arr = dataurl.split(',')
  let mime = arr[0].match(/:(.*?);/)[1]
  let suffix = mime.split('/')[1]
  let bstr = atob(arr[1])
  let n = bstr.length
  let u8arr = new Uint8Array(n)
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n)
  }
  return new File([u8arr], `${filename}.${suffix}`, {
    type: mime
  })
}
let until = {
  checkUpdateData,
  debounce,
  getPageData,
  checkImage,
  dataURLtoFile
}
export { until }
