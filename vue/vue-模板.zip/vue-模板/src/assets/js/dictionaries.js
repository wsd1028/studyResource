const dictionaries = {
  ak: 'ZKXP8ba3d1w3UeB6Takh1bFGMEcF6q6L',
  imgBaseUrl: '/carp/file/k/q/open/image/',
  videoBaseUrl: '/carp/file/k/q/open/video/play/',
  userType: {
    system: 0, //系统管理员
    company: 10, //公司内部
    maintenance: 20, //安装运维
    project: 30, //项目人员(排放员)
    bank: 40, //银行
    government: 50, //安监站(政府)
    garbage: 60, //消纳站(消纳员)
    transport: 70 //运输公司
  },
  imgType: {
    //图片类型
    appoint: 'command_module', //指派点检
    video: 'video_module', //视频巡检
    electronic: 'electronic_image', //电子联单
    base: 'base_image', //基础项
    dispatch: 'task_image', //督办派单
    car: 'plate_number_image', //车辆识别
    today: 'today_module', //每日巡检
    problem: 'question_image' //问题上报
  },
  visible: {
    //数据库数据是否删除
    del: 0, //删除
    save: 1 //存在
  },
  online: {
    //设备是否在线
    yes: 2, //在线
    no: 3 //离线
  },
  direction: {
    //设备进出标识
    jin: 6, //进
    chu: 7 //出
  },
  machineType: {
    company: 8, //项目
    garbage: 9, //消纳站
    government: 6000 //政府
  },
  electronic: {
    //电子联单流程状态
    yunshu: 10, //运输中
    xiaona: 20 //已消纳
  },
  warnType: {
    car: 60, //非名录车告警
    fast: 61, //超速告警
    noCard: 62, //无证进工地告警
    noClean: 64, //车身不洁告警
    hyperline: 65, //超线路行驶告警
    AQI: 66 //AQI指标连续两小时持续走高
  },
  problem: {
    //问题上报
    report: 550, //已上报
    processing: 551, //处理中
    finish: 552, //已结案
    cancel: 553, //已作废
    level: {
      //等级
      ordinary: 5500, //普通,游客
      company: 5501, //优先,企业
      government: 5502 //紧急,政府
    },
    type: {
      //类型
      pollution: 350, //污染源
      noRegister: 351, //项目未注册
      company: 352, //企业问题上报类型
      other: 353 //其他
    }
  },
  dispatch: {
    //督办派单
    wait: 5020, //待处理/已派单
    waitCheck: 5050, //待审核
    reject: 5060, //已驳回
    finish: 5070, //已结案
    cancel: 5080 //已作废
  },
  todayCheck: {
    //今日巡检状态
    update: 5120, //整改
    waitCheck: 5130, //待审核
    finish: 5140 //已结案
  },
  appointCheck: {
    //指派点检状态
    update: 5210, //整改
    waitCheck: 5220, //待审核
    finish: 5230, //已结案
    cancel: 5240 //已作废
  }
}
export { dictionaries }
