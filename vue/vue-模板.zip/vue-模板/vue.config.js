module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/carp-web/' : '/',
  configureWebpack: {
    devServer: {
      port: 8855,
      proxy: {
        //中心
        '/business': {
          target: 'http://192.168.31.8:9101',
          ws: true,
          changeOrigin: true,
          pathRewrite: {
            '^/carp': ''
          }
        },
        '/carp': {
          target: 'http://192.168.31.53:80',
          ws: true,
          changeOrigin: true,
          pathRewrite: {
            '^/carp': ''
          }
        },
        '/baiduApi': {
          target: 'http://api.map.baidu.com', //访问地址
          changeOrigin: true,
          secure: false, //只有代理https 地址需要次选项
          pathRewrite: {
            '^/baiduApi': ''
          }
        }
      }
    }
  }
}
