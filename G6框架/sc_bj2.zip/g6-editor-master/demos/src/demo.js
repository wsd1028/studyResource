import React from 'react';
import ReactDOM from 'react-dom';
import ModelFlowEditor from '../rc-components/ModelFlowEditor.jsx';

ReactDOM.render(<ModelFlowEditor />, document.getElementById('mountNode'));
