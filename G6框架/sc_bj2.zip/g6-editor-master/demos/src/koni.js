
import React from 'react';
import ReactDOM from 'react-dom';
import Koni from '../rc-components/Koni.jsx';

ReactDOM.render(<Koni />, document.getElementById('mountNode'));
