
import React from 'react';
import ReactDOM from 'react-dom';
import BaseFlowEditor from '../rc-components/BaseFlowEditor.jsx';

ReactDOM.render(<BaseFlowEditor />, document.getElementById('mountNode'));
