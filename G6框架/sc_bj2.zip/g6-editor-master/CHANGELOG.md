
# ChangeLog

---

#### v1.3.0

`2018.11.30`

- fix: pan empty canvas error closes github.#41.#28
- fix: ungroup child item disapear closes github.#7.#31

#### v1.2.0

`2018.11.22`

- feat: add koni

#### v1.1.1

`2018.11.02`

- fix: minimap first render

#### v1.1.0

`2018.10.12`

- feat: update G6 to v2.1.x
- fix: fix many bug

#### v1.0.6

`2018.08.23`

- feat:   delegate itempanel mousedown event 

#### v1.0.5

`2018.07.23`

- fix:    Page should not emitselected event when item after draw. 

#### v1.0.4

`2018.07.03`

- fix     节点或边多选之后右键经常变成单选状态
- fix     html 拖拽时抖动
- fix     节点或边多选之后右键变成单选状态 
- feature 元素确保在可视区域
- feature 支持滚轮放大缩小画布

#### v1.0.3

`2018.06.08`

- fix 两项时拖拽交互热区有勿
- fix 输入完，输入框选择样式丢失
