<!--
 * @Author: caojing
 * @Date: 2017-11-27 14:05:00
 * @LastEditors: caojing
 * @LastEditTime: 2018-11-22 14:37:33
 -->

<template>
  <header id="header">
  	<span>Vue2.0 拓扑组件</span>
  </header>
</template>

<script>

export default {
  name: 'footer',
  data () {
    return {
     
    }
  }
}
</script>

<style lang="less" scoped>
 #header{height:40px;background-color: @theme-color;color:@theme-font-color;padding:0 20px;display: flex;align-items: center;font-size:14px;}
</style>
