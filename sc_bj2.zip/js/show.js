function renderLayer04Left() {
   
}
